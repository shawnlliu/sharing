%m_conv is an extension to MATLAB's conv, where more
%arguments are allowed, which means that under such 
%the convolution of more than two vectors can be
%obtained at the same time.

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%------------------------------------------------------------------------
function a=m_conv(varargin)
a=varargin{1};
for i=2:length(varargin)
   eval(['a=conv(a,varargin{' int2str(i) '});']);
end
