
%----------------------------------------------
%set_contxtmenu
%----------------------------------------------
function set_contxtmenu(key)
[v,d]=version; v1=eval(v(1)); v2=eval(v(3));
if v2>=2,  
   if nargin==1
      switch key
      case 0 %the context menu system for the main window.
         cmenu=uicontextmenu;
         set(gcf,'UIContextMenu',cmenu);
         h_cm(1)=uimenu(cmenu,'Label','Help on CtrlLAB','CallBack','clab_help(0);');
         h_cm(2)=uimenu(cmenu,'Label','Help: Starting with CtrlLAB','CallBack','clab_help(-1);');
         h_cm(3)=uimenu(cmenu,'Label','Step Response','Separator','on',...
            'CallBack','extra_funs(4,4,''Checked'',7,8); sys_analysis(6);');
         h_cm(4)=uimenu(cmenu,'Label','Bode Diagram','CallBack','sys_analysis(1);');
         h_cm(5)=uimenu(cmenu,'Label','Nyquist Plot','CallBack','sys_analysis(2);');
         h_cm(6)=uimenu(cmenu,'Label','Ziegler-Nichols PID controller',...
            'Separator','on','CallBack','pid_design(1);');
         h_cm(7)=uimenu(cmenu,'Label','Model Reduction',...
            'Separator','on','CallBack','mod_reduction(1);');
         h_cm(8)=uimenu(cmenu,'Label','Display Transfer Function',...
            'Callback','extra_funs(4,3,''Checked'',20,[21:23]); proc_model(1);');
         h_cm(9)=uimenu(cmenu,'Label','Display Factorized TF',...
            'Callback','extra_funs(4,3,''Checked'',23,[20:22]); proc_model(1);');
         h_cm(10)=uimenu(cmenu,'Label','Display State Space',...
            'Callback','extra_funs(4,3,''Checked'',21,[20,22,23]); proc_model(1);');
         h_cm(11)=uimenu(cmenu,'Label','Matrix Processor',...
            'Separator','on','CallBack','matx_proc;');
      
      case 5
         cmenu=uicontextmenu;
         set(gcf,'UIContextMenu',cmenu);
         h_cm(1)=uimenu(cmenu,'Label','Add a New Legend','CallBack','legd_proc(1);');
         h_cm(2)=uimenu(cmenu,'Label','Add an Arrow','CallBack','legd_proc(8);');
         h_cm(3)=uimenu(cmenu,'Label','Add a Line','CallBack','legd_proc(5);');
         h_cm(4)=uimenu(cmenu,'Label','Cursor Positioning','CallBack','legd_proc(18);');
         h_cm(5)=uimenu(cmenu,'Label','Legend Properties...','CallBack','legd_proc(13);');
         h_cm(6)=uimenu(cmenu,'Label','Zooming on',...
            'Separator','on','CallBack','plot_proc(1,0,0);');
         h_cm(7)=uimenu(cmenu,'Label','Full Axis','CallBack','plot_proc(4,0,0);');
         h_cm(8)=uimenu(cmenu,'Label','Line Properties...',...
            'Separator','on','CallBack','legd_proc(22);');
         
      end
   elseif nargin==2
      switch b_obj
      case 1
            
      end   
   end
end
