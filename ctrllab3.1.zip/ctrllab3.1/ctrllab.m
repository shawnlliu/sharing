%CtrlLAB is the main module of CtrlLAB.  The function syntax is as follows:
%   
%   ctrllab(key,arg1,agr2)
%
%if no argument is specified, then the command executes the main interface.  
%If there are extra arguments, then
%
%   key=0, for program initialization if arg1 not existing,
%         or menu enabling, if arg1 exists
%   key=1, displays and executes the tutorials
%   key=2, perform and display realization of plant model
%   key=3, add extra block to the plant model not 
%          implemented yet.
%
%The functions available in the module are
%
%  ctrllab_blocks -- draw the system blocks
%  ctrllab_toolbar -- creates a toolbar (for MATLAB 5.2+ only)
%  ctrllab_menu -- creates the main menu system
%  arrow_shw -- draw arrows in current window
%  ctrllab_init -- perform initialization in CtrlLAB
%  shw_tutorial -- activate the toturial program in CtrlLAB
%  plant_realiz -- displays the realization of plant model
%  add_sys_blocks -- adds the extra system properties to the plant
%  file_proc -- process the file open/save and quiting tasks
%  select_sigs -- allows one to select signals from the block diagram
%

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%-------------------------------------------------------------------------

function ctrllab(key,arg1,agr2)

%get the handle of the main window
h_main=findobj('Tag','CtrlLABMain');

if nargin==0
   %start the program
   if length(h_main)==0
      %if no such a window exists, then open a new main window
      h_main=figure('Units','normalized','Position',[0.1575 0.34 0.56125 0.448333], ...
         'NumberTitle','off','Name','CtrlLAB Feedback Control Systems Laboratory', ...
         'MenuBar','none','Color',0.8*[1,1,1],'CloseRequestFcn','ctrllab(5,4);',...
         'Tag','CtrlLABMain','Resize','off');
      ctrllab_blocks;
      [v,d]=version; v1=eval(v(1)); v2=eval(v(3));
      if v1>=5 & v2>=2, 
         ctrllab_toolbar; 
         set_contxtmenu(0); set_contxtmenu(1); set_contxtmenu(2); 
         set_contxtmenu(3); set_contxtmenu(4); 
      end 
      ctrllab_menu;
      ctrllab_init(0); 
   else, 
      %if the main window exists, bring it to front
      figure(h_main); 
   end
else
   %perform extra actions
   switch key
   case 0, %initialization of the program
      if nargin==1, ctrllab_init(0); 
      else, ctrllab_init(arg1); end 
   case 1, shw_tutorial(arg1); %perform tutorials 
   case 2, plant_realiz(arg1); %perform and display the realization of the plant model
   case 3, add_sys_blocks(arg1); %add extra blocks to the plant model
   case 5, file_proc(arg1); %call file_proc to process the File menu
   case 6, select_sigs(arg1); %select output signals
   case 7, set_openloop; %setting open-loop selections
   case 8, 
      uu0=get(h_main,'UserData'); g1=get(uu0{1}(1),'UserData');
      if length(g1)>0, matx_proc;
      else, 
         warndlg('Plant model dose not exist, please enter it first!','Matrix Processor Warning:'); 
      end   
   end      
end   

%---------------------------------------------------------------------------------
%ctrllab_blocks is used to create all the block buttons and draw the block diagram
%of typical feedback control structure on the main window.
%---------------------------------------------------------------------------------
function ctrllab_blocks()

extra_funs(1,[0.05,0.05,0.9,0.6]);
fill([0 1 1 0 0],[0 0 1 1 0],[0.502, 1, 1])
set(gca,'visible','off'); 

arrow_shw([0.87 0.60],[0.97,0.60],0.5,[0 0 0]);
arrow_shw([0.615 0.60],[0.715,0.60],0.5,[0 0 0]);
arrow_shw([0.395 0.60],[0.495,0.60],0.5,[0 0 0]);
arrow_shw([0.14 0.60],[0.24,0.60],0.5,[0 0 0]);
arrow_shw([0.01 0.60],[0.10,0.60],0.5,[0 0 0]);
hc(1)=line([0.92,0.92 0.70],[0.60,0.175 0.175]);  
t=0:.1:2*pi+0.1; x1=0.12+0.02*cos(t); y1=0.60+0.05*sin(t);
hc(2)=line(x1,y1); 
arrow_shw([0.70 0.175],[0.60,0.175],0.5,[0 0 0]);
arrow_shw([0.12 0.175],[0.12,0.55],0.05,[0 0 0]);
hc(3)=line([0.12,0.50],[0.175,0.175]); set(hc,'Color','k');

%display the title and its shading
display_str(0.116,0.83,'Typical Continuous Linear Feedback Structure',[1,1,0],'on',16,'Brush Script MT');
display_str(0.11,0.85,'Typical Continuous Linear Feedback Structure',[1,0,0],'on',16,'Brush Script MT');

hc=extra_funs(10,[0.4824,0.3224],[0.8969,0.7450]);
set(hc,'LineStyle',':','Color',[0,0,1]);
display_str(0.64,0.39,'Plant Model',[0,0,1],'on',9,'Times New Roman','normal','italic');

%labelling signal legends
[xL,h_Sig(1)]=display_str(0.17,0.67,'e(t)',[0.6,0.6,0],'on',9);
[xL,h_Sig(2)]=display_str(0.42,0.67,'u(t)',[0.6,0.6,0],'on',9);
[xL,h_Sig(3)]=display_str(0.92,0.67,'y(t)',[1,0,0],'on',9);
[xL,h_Sig(4)]=display_str(0.03,0.67,'\gamma(t)',[0,0,0],'on',9);
display_str(0.09,0.53,'\_',[0,0,0],'on',9);
set(h_Sig(1),'ButtonDownFcn','ctrllab(6,1);');
set(h_Sig(2),'ButtonDownFcn','ctrllab(6,2);');
set(h_Sig(3),'ButtonDownFcn','ctrllab(6,3);');

bSys(1) = uicontrol('Style','PushButton','String','G(s)',...
   'Units','normalized','Position',[0.50 0.35 0.14 0.115],'Callback','proc_model(0,1);');
bSys(2) = uicontrol('Style','PushButton','String','Gc(s)',...
   'Units','normalized','Position',[0.269 0.35 0.14 0.115],'Callback','proc_model(0,2);');
bSys(3) = uicontrol('Style','PushButton','String','H(s)',...
   'Units','normalized','Position',[0.45 0.10 0.14 0.115],'Callback','proc_model(0,3);');
bSys(4) = uicontrol('Style','PushButton','String','Exp(-Ts)',...
   'Units','normalized','Position',[0.695 0.35 0.14 0.112],'Callback','proc_model(0,4);');
   
%set the information to window's UserData.  The first four elements are the handles
%of the four blocks.  The fifth, 
%the sixth if 1 if there is unsaved model
%the seventh is the handle of the main window. The eighth is the signal selection.
set(gcf,'UserData',{[bSys,0,0,0,h_Sig]});

%----------------------------------------------------------------------
%ctrllab_menus is used to create all the menu items in the main window.
%----------------------------------------------------------------------
function ctrllab_toolbar()
load ctrllab_cdata; load clab_disp_cdata; 
yy=get(gcf,'Position'); screen=get(0,'ScreenSize'); ymax=yy(4)*screen(4)-20;
uicontrol('Style','PushButton','Units','pixels','Position',[2,ymax,20,20],...
   'CData',fnew_dat,'CallBack','ctrllab(0);','TooltipString','CtrlLAB initialization');
uicontrol('Style','PushButton','Units','pixels','Position',[22,ymax,20,20],...
   'CData',fopen_dat,'CallBack','ctrllab(5,1);','TooltipString','Load models');
uicontrol('Style','PushButton','Units','pixels','Position',[42,ymax,20,20],...
   'CData',fsave_dat,'CallBack','ctrllab(5,2);','TooltipString','Save models');
uicontrol('Style','PushButton','Units','pixels','Position',[65,ymax,20,20],...
   'CData',help_dat,'CallBack','clab_help(0);','TooltipString','Introduction');
uicontrol('Style','PushButton','Units','pixels','Position',[88,ymax,20,20],...
   'CData',tf_dat,'CallBack','extra_funs(4,3,''Checked'',20,[21:23]); proc_model(1);',...
   'TooltipString','Transfer Function');
uicontrol('Style','PushButton','Units','pixels','Position',[108,ymax,20,20],...
   'CData',ss_dat,'CallBack','extra_funs(4,3,''Checked'',21,[20,22,23]); proc_model(1);',...
   'TooltipString','State Space');
uicontrol('Style','PushButton','Units','pixels','Position',[128,ymax,20,20],...
   'CData',ftf_dat,'CallBack','extra_funs(4,3,''Checked'',23,[20:22]); proc_model(1);',...
   'TooltipString','Factorized Transfer Function');
uicontrol('Style','PushButton','Units','pixels','Position',[148,ymax,20,20],...
   'CData',matx_dat,'CallBack','ctrllab(8);','TooltipString','Matrix Processor');
uicontrol('Style','PushButton','Units','pixels','Position',[168,ymax,20,20],...
   'CData',red_dat,'CallBack','mod_reduction(1);','TooltipString','Model Reduction');
uicontrol('Style','PushButton','Units','pixels','Position',[188,ymax,20,20],...
   'CData',simu_dat,'CallBack','simu_modlib;','TooltipString','Model Library');

uicontrol('Style','PushButton','Units','pixels','Position',[211,ymax,20,20],...
   'String','Bo','CallBack','sys_analysis(1);','TooltipString','Bode Diagram');
uicontrol('Style','PushButton','Units','pixels','Position',[231,ymax,20,20],...
   'String','Ny','CallBack','sys_analysis(2);','TooltipString','Nyquist Plot');
uicontrol('Style','PushButton','Units','pixels','Position',[251,ymax,20,20],...
   'String','Nic','CallBack','sys_analysis(3);','TooltipString','Nichols Chart');
uicontrol('Style','PushButton','Units','pixels','Position',[271,ymax,20,20],...
   'String','Inv','CallBack','sys_analysis(4);','TooltipString','Inverse Nyquist Plot');
uicontrol('Style','PushButton','Units','pixels','Position',[291,ymax,20,20],...
   'String','RL','CallBack','sys_analysis(5);','TooltipString','Inverse Nyquist Plot');
uicontrol('Style','PushButton','Units','pixels','Position',[311,ymax,20,20],...
   'String','St','CallBack','sys_analysis(6);','TooltipString','Step Response');
uicontrol('Style','PushButton','Units','pixels','Position',[331,ymax,20,20],...
   'String','Im','CallBack','sys_analysis(7);','TooltipString','Impulse Response');
uicontrol('Style','PushButton','Units','pixels','Position',[354,ymax,20,20],...
   'CData',openl_dat,'CallBack','ctrllab(6,5);','TooltipString','Open Loop');
uicontrol('Style','PushButton','Units','pixels','Position',[374,ymax,20,20],...
   'CData',closel_dat,'CallBack','ctrllab(6,6);','TooltipString','Closed Loop');
uu0=get(gcf,'UserData');
set(uu0{1}(1),'TooltipString','Plant Model'); set(uu0{1}(2),'TooltipString','Controller Model');
set(uu0{1}(3),'TooltipString','Feedback Model Model'); set(uu0{1}(4),'TooltipString','Time Delay Model');

%----------------------------------------------------------------------
%ctrllab_menus is used to create all the menu items in the main window.
%----------------------------------------------------------------------
function ctrllab_menu()
% Defining menu systems
%
% (1) The File menu system definitions
hMFile(1)=uimenu(gcf,'Label','&File');
hMFile(2)=uimenu(hMFile(1),'Label','&New','CallBack','ctrllab(0);');
hMFile(3)=uimenu(hMFile(1),'Label','&Open ...','CallBack','ctrllab(5,1);');
hMFile(4)=uimenu(hMFile(1),'Label','&Save','CallBack','ctrllab(5,2);');
hMFile(5)=uimenu(hMFile(1),'Label','Save &As ...','CallBack','ctrllab(5,3);');
hMFile(6)=uimenu(hMFile(1),'Label','E&xit','Separator','on','CallBack','ctrllab(5,4);');
 
%
% (2) The Model menu system definitions
%(2.1), the model selection sub-menu
hMModel(1)=uimenu(gcf,'Label','&Model');
hMModel(2)=uimenu(hMModel(1),'Label','Model &Select');
hMModel(10)=uimenu(hMModel(2),'Label','G(s)','Checked','on',...
   'CallBack','extra_funs(4,3,''Checked'',10,[11:13]); proc_model(0,1,0);');
hMModel(11)=uimenu(hMModel(2),'Label','Gc(s)','Checked','off',...
   'CallBack','extra_funs(4,3,''Checked'',11,[10,12,13]); proc_model(0,2,0);');
hMModel(12)=uimenu(hMModel(2),'Label','H(s)','Checked','off',...
   'CallBack','extra_funs(4,3,''Checked'',12,[10,11,13]); proc_model(0,3,0);');
hMModel(13)=uimenu(hMModel(2),'Label','Exp(-Ts)','Checked','off',...
   'CallBack','extra_funs(4,3,''Checked'',13,[10:12]); proc_model(0,4,0);');
   
hMModel(3)=uimenu(hMModel(1),'Label','Model &Type');

% the next two sub menu items are currently redundant
hMModel(14)=uimenu(hMModel(3),'Label','&Open loop','Visible','off','Checked','on');
hMModel(15)=uimenu(hMModel(3),'Label','&Closed loop','Visible','off','Checked','off');
   
hMModel(16)=uimenu(hMModel(3),'Label','&Transfer Function',...
   'Checked','on','Callback','extra_funs(4,3,''Checked'',16,[17:19]); ');
hMModel(17)=uimenu(hMModel(3),'Label','&Zero-Pole',...
   'Checked','off','Callback','extra_funs(4,3,''Checked'',17,[16,18:19]); ');
hMModel(18)=uimenu(hMModel(3),'Label','&State Space',...
   'Checked','off','Callback','extra_funs(4,3,''Checked'',18,[16:17,19]); ');
hMModel(19)=uimenu(hMModel(3),'Label','Simulink &Model','Checked','off',...
   'Enable',extra_funs(6,exist('simulink.mdl')==4),...
   'Callback','extra_funs(4,3,''Checked'',19,[16:18]); ');
   
hMModel(4)=uimenu(hMModel(1),'Label','Model &Display');
hMModel(20)=uimenu(hMModel(4),'Label','Transfer Function','Checked','on',...
   'Callback','extra_funs(4,3,''Checked'',20,[21:23]); proc_model(1);');
hMModel(21)=uimenu(hMModel(4),'Label','State Space','Checked','off',...
   'Callback','extra_funs(4,3,''Checked'',21,[20,22,23]); proc_model(1);');
hMModel(22)=uimenu(hMModel(4),'Label','Pole-Zero','Checked','off',...
   'Callback','extra_funs(4,3,''Checked'',22,[20,21,23]); proc_model(1);');
hMModel(23)=uimenu(hMModel(4),'Label','Factorized TF','Checked','off',...
   'Callback','extra_funs(4,3,''Checked'',23,[20:22]); proc_model(1);');
   
hMModel(5)=uimenu(hMModel(1),'Label','&Realisation','Enable','off');
hMModel(24)=uimenu(hMModel(5),'Label','&Controllable Form','Checked','on', ...
   'CallBack','extra_funs(4,3,''Checked'',24,[25:28]); ctrllab(2,1);');
hMModel(25)=uimenu(hMModel(5),'Label','&Observable Form','Checked','off', ...
   'CallBack','extra_funs(4,3,''Checked'',25,[24,26:28]); ctrllab(2,2);');
hMModel(26)=uimenu(hMModel(5),'Label','&Jordan Form','Checked','off', ...
   'CallBack','extra_funs(4,3,''Checked'',26,[24:25,27:28]); ctrllab(2,3);');
hMModel(27)=uimenu(hMModel(5),'Label','&Minimal Realisation','Checked','off', ...
   'CallBack','extra_funs(4,3,''Checked'',27,[24:26,28]); ctrllab(2,4);');
hMModel(28)=uimenu(hMModel(5),'Label','&Balanced Realisation','Checked','off', ...
   'CallBack','extra_funs(4,3,''Checked'',28,[24:27]); ctrllab(2,5);');
   
hMModel(6)=uimenu(hMModel(1),'Label','&Reduction...','Enable','off','CallBack','mod_reduction(1);');

hMModel(7)=uimenu(hMModel(1),'Label','&Show','Separator','on',...
   'Enable','off','CallBack','proc_model(1);');
hMModel(8)=uimenu(hMModel(1),'Label','&Enter/Modify','CallBack','proc_model(2);');
hMModel(9)=uimenu(hMModel(1),'Label','&Show Model Library','Checked','off',...
   'Enable',extra_funs(6,exist('simulink.mdl')==4),'CallBack','simu_modlib;');

%29-36 moved and now empty
hMModel(29)=uimenu(hMModel(1),'Label','&Add More Blocks','Separator','on');
hMModel(30)=uimenu(hMModel(29),'Label','&ZOH for Gc','Checked','off','CallBack','ctrllab(3,1);');
hMModel(31)=uimenu(hMModel(29),'Label','&Actuator Saturation','Checked','off','CallBack','ctrllab(3,2);');
hMModel(32)=uimenu(hMModel(29),'Label','&Time Delay','Checked','off','CallBack','ctrllab(3,3);');
hMModel(33)=uimenu(hMModel(29),'Label','&Measurement Noise','Checked','off','CallBack','ctrllab(3,4);');

hMAnalysis(1)=uimenu(gcf,'Label','&Analysis','Enable','off');
hMAnalysis(21)=uimenu(hMAnalysis(1),'Label','&Frequency Domain Analysis');
hMAnalysis(2)=uimenu(hMAnalysis(21),'Label','&Bode Diagram','CallBack','sys_analysis(1);');
hMAnalysis(3)=uimenu(hMAnalysis(21),'Label','&Nyquist Plot','CallBack','sys_analysis(2);');
hMAnalysis(4)=uimenu(hMAnalysis(21),'Label','&Nichols Chart','CallBack','sys_analysis(3);');
hMAnalysis(5)=uimenu(hMAnalysis(21),'Label','&Inverse Nyquist Plot','CallBack','sys_analysis(4);');
hMAnalysis(6)=uimenu(hMAnalysis(1),'Label','&Root Locus','CallBack','sys_analysis(5);');
hMAnalysis(22)=uimenu(hMAnalysis(1),'Label','&Time Domain Analysis');
hMAnalysis(7)=uimenu(hMAnalysis(22),'Label','&Step Response','Checked','off',...
   'CallBack','extra_funs(4,4,''Checked'',7,8); sys_analysis(6);');
hMAnalysis(8)=uimenu(hMAnalysis(22),'Label','&Impulse Response','Checked','on',...
   'CallBack','extra_funs(4,4,''Checked'',8,7); sys_analysis(7);');
hMAnalysis(34)=uimenu(hMAnalysis(1),'Label','&Parametric Analysis','Separator','on');
hMAnalysis(14)=uimenu(hMAnalysis(34),'Label','&Gain/Phase Margins','CallBack','sys_analysis(8);');
hMAnalysis(15)=uimenu(hMAnalysis(34),'Label','&Analytical Solutions','CallBack','sys_analysis(12);');
hMAnalysis(9)=uimenu(hMAnalysis(34),'Label','&Guaranteed Stability Margins','CallBack','sys_analysis(13);');
%hMAnalysis(35)=uimenu(hMAnalysis(9),'Label','&Additative uncertainty');
%hMAnalysis(36)=uimenu(hMAnalysis(9),'Label','&Multiplicative uncertainty');
%hMAnalysis(37)=uimenu(hMAnalysis(34),'Label','&System measures');
hMAnalysis(38)=uimenu(hMAnalysis(34),'Label','H_&2 and H_inf Norms','CallBack','sys_analysis(9);');
hMAnalysis(40)=uimenu(hMAnalysis(34),'Label','&Time Moments','CallBack','sys_analysis(10);');
hMAnalysis(41)=uimenu(hMAnalysis(34),'Label','&Markov Parameters','CallBack','sys_analysis(11);');

hMAnalysis(20)=uimenu(hMAnalysis(1),'Label','&Call Matrix Processor','CallBack','matx_proc;');
   
hMAnalysis(23)=uimenu(hMAnalysis(1),'Label','&Loop Specs and Signals','Separator','on');
hMAnalysis(24)=uimenu(hMAnalysis(23),'Label','&Open Loop ','Checked','off','CallBack','ctrllab(6,5);');
hMAnalysis(25)=uimenu(hMAnalysis(23),'Label','&Closed Loop','Checked','on','CallBack','ctrllab(6,6);');
hMAnalysis(26)=uimenu(hMAnalysis(23),'Label','Compensated System','Checked','off',...
   'Separator','on','Enable','off','CallBack','ctrllab(3,5);');
hMAnalysis(27)=uimenu(hMAnalysis(23),'Label','Un-compensated System',...
   'Checked','on','CallBack','ctrllab(3,6);');
hMAnalysis(28)=uimenu(hMAnalysis(23),'Label','Error Signal e(t)',...
   'Separator','on','Checked','off','CallBack','ctrllab(6,1);');
hMAnalysis(29)=uimenu(hMAnalysis(23),'Label','Actuating Signal u(t)',...
   'Checked','off','CallBack','ctrllab(6,2);');
hMAnalysis(30)=uimenu(hMAnalysis(23),'Label','Output Signal y(t)',...
   'Checked','on','CallBack','ctrllab(6,3);');
hMAnalysis(31)=uimenu(hMAnalysis(23),'Label','Input/Output Relationship',...
   'Separator','on','Checked','on','CallBack','ctrllab(6,3);');
hMAnalysis(32)=uimenu(hMAnalysis(23),'Label','Sensitivity Function',...
   'Checked','off','CallBack','ctrllab(6,1);');
hMAnalysis(33)=uimenu(hMAnalysis(23),'Label','Complementary Sensitivity Function',...
   'Checked','off','CallBack','ctrllab(6,4);');
   
hMDesign(1)=uimenu(gcf,'Label','&Design','Enable','off');
hMDesign(2)=uimenu(hMDesign(1),'Label','&Classical Compensation','Enable','on');
hMDesign(3)=uimenu(hMDesign(2),'Label','&Lead/Lag Compensation','CallBack','sys_design(1);');
hMDesign(4)=uimenu(hMDesign(2),'Label','L&Q optimal Control','CallBack','sys_design(2);');
hMDesign(5)=uimenu(hMDesign(2),'Label','&Pole Placement','CallBack','sys_design(3);');
hMDesign(6)=uimenu(hMDesign(2),'Label','&Model Following','CallBack','sys_design(4);');
 
hMDesign(7)=uimenu(hMDesign(1),'Label','&PID Controller');
hMDesign(8)=uimenu(hMDesign(7),'Label','&One-shot Design');
hMDesign(9)=uimenu(hMDesign(8),'Label','&Ziegler-Nichols Tuning','CallBack','pid_design(1);');
hMDesign(10)=uimenu(hMDesign(8),'Label','&Cohen-Coon Tuning','CallBack','pid_design(8);');
hMDesign(11)=uimenu(hMDesign(8),'Label','&Refined Ziegler-Nichols','CallBack','pid_design(7);');
hMDesign(12)=uimenu(hMDesign(7),'Label','&Specified Parameters');
hMDesign(13)=uimenu(hMDesign(12),'Label','Chien (C&HR) Tuning','CallBack','pid_design(9);');
hMDesign(14)=uimenu(hMDesign(12),'Label','Modified Ziegler-Nichols Tuning','CallBack','pid_design(10);');
hMDesign(15)=uimenu(hMDesign(12),'Label','Internal Model Control','CallBack','pid_design(11);');
hMDesign(16)=uimenu(hMDesign(7),'Label','&Optimum Tuning');
hMDesign(17)=uimenu(hMDesign(16),'Label','&ISE Setting','Checked','on', ...
   'CallBack','extra_funs(4,5,''Checked'',17,18:20); pid_design(2);');
hMDesign(18)=uimenu(hMDesign(16),'Label','I&STE Setting','Checked','off', ...
   'CallBack','extra_funs(4,5,''Checked'',18,[17,19:20]); pid_design(3);');
hMDesign(19)=uimenu(hMDesign(16),'Label','IS&T2E Setting','Checked','off', ...
   'CallBack','extra_funs(4,5,''Checked'',19,[17:18,20]); pid_design(4);');
hMDesign(20)=uimenu(hMDesign(16),'Label','&Gain Phase Tuning','Checked','off', ...
   'CallBack','extra_funs(4,5,''Checked'',20,17:19); pid_design(5);');
hMDesign(21)=uimenu(hMDesign(7),'Label','&User Define...','CallBack','pid_design;');
hMDesign(22)=uimenu(hMDesign(7),'Label','&Controller Type','Separator','on');
hMDesign(23)=uimenu(hMDesign(22),'Label','&P Control', ...
   'CallBack','extra_funs(4,5,''Checked'',23,24:26); ');
hMDesign(24)=uimenu(hMDesign(22),'Label','P&I Control', ...
   'CallBack','extra_funs(4,5,''Checked'',24,[23,25:26]); ');
hMDesign(25)=uimenu(hMDesign(22),'Label','&Normal PID','Checked','on',...
   'CallBack','extra_funs(4,5,''Checked'',25,[23:24,26]); ');
hMDesign(26)=uimenu(hMDesign(22),'Label','PID with &D in Feedback','Checked','off',...
   'CallBack','extra_funs(4,5,''Checked'',26,23:25); ');
hMDesign(28)=uimenu(hMDesign(7),'Label','&First-order Model Identification');
hMDesign(29)=uimenu(hMDesign(28),'Label','&Optimal Reduction','Checked','off', ...
   'CallBack','extra_funs(4,5,''Checked'',29,30:31); ');
hMDesign(30)=uimenu(hMDesign(28),'Label','&Frequency Response-based','Checked','on', ...
   'CallBack','extra_funs(4,5,''Checked'',30,[29,31]); ');
hMDesign(31)=uimenu(hMDesign(28),'Label','&Transfer Function-based','Checked','off', ...
   'CallBack','extra_funs(4,5,''Checked'',31,29:30); ');

hMDesign(32)=uimenu(hMDesign(1),'Label','&Robust Control');
hMDesign(33)=uimenu(hMDesign(32),'Label','&QFT Control','Visible','off');
hMDesign(34)=uimenu(hMDesign(32),'Label','&LQG Control','CallBack','sys_design(5);');
hMDesign(35)=uimenu(hMDesign(32),'Label','&LQG/LTR Control','CallBack','sys_design(6);');
hMDesign(36)=uimenu(hMDesign(32),'Label','&H_2 Control','CallBack','sys_design(7);');
hMDesign(37)=uimenu(hMDesign(32),'Label','&H_inf Control','CallBack','sys_design(8);');
hMDesign(38)=uimenu(hMDesign(32),'Label','&H_inf Optimal Control','CallBack','sys_design(9);');
hMDesign(39)=uimenu(hMDesign(32),'Label','LM&I Control','Visible','off');
hMDesign(40)=uimenu(hMDesign(32),'Label','&Mu-synthesis','Visible','off','CallBack','sys_design(10);');

hMHelp(1)=uimenu(gcf,'Label','&Help');
hMHelp(2)=uimenu(hMHelp(1),'Label','&Tutorial');
hMHelp(3)=uimenu(hMHelp(2),'Label','&Step 1: Model Entering','CallBack','ctrllab(1,1);');
hMHelp(4)=uimenu(hMHelp(2),'Label','&Step 2: Bode Diagram','CallBack','ctrllab(1,2);');
hMHelp(5)=uimenu(hMHelp(2),'Label','&Step 3: Nichols Chart','CallBack','ctrllab(1,3);');
hMHelp(6)=uimenu(hMHelp(2),'Label','&Step 4: PID Controller Design','CallBack','ctrllab(1,4);');
hMHelp(7)=uimenu(hMHelp(1),'Label','&Introduction','CallBack','clab_help(0);');
hMHelp(16)=uimenu(hMHelp(1),'Label','Starting with CtrlLAB','CallBack','clab_help(-1);');
hMHelp(8)=uimenu(hMHelp(1),'Label','&Help on Interface');
hMHelp(9)=uimenu(hMHelp(8),'Label','&File Menu','CallBack','clab_help(5);');
hMHelp(10)=uimenu(hMHelp(8),'Label','&Model Menu','CallBack','clab_help(6);');
hMHelp(11)=uimenu(hMHelp(8),'Label','&Analysis Menu','CallBack','clab_help(7);');
hMHelp(12)=uimenu(hMHelp(8),'Label','&Design Menu','CallBack','clab_help(8);');
hMHelp(13)=uimenu(hMHelp(8),'Label','&Graphics Window','CallBack','clab_help(9);');
hMHelp(14)=uimenu(hMHelp(8),'Label','&PID Controller Design','CallBack','clab_help(13);');
hMHelp(15)=uimenu(hMHelp(1),'Label','&About...','Separator','on','CallBack','clab_help(23);');

uu=get(gcf,'UserData'); 
uu={uu{1},hMFile,hMModel,hMAnalysis,hMDesign,hMHelp,[1,0.1,0.1,10]}; set(gcf,'UserData',uu);   
   
%----------------------------------------------
%arrow_shw draw arrows in current window
%
%   h=arrow_shw(p1,p2,w,col)
%where 
%   h is the handle of the arrow to be drawn
%   p1,p2 are the starting and ending points
%   w is the width of the arrow
%   col is the color of the arrow
%----------------------------------------------
function h=arrow_shw(p1,p2,w,col)
n=length(p1); c=(p2(1)-p1(1))/2; d=(p2(2)-p1(2))/2; f=(p2(1)+p1(1))/2;  
g=(p2(2)+p1(2))/2; x=[-1 1 0.5 1 0.5]; y=[0 0 0.5*w 0 -0.5*w];
xx=c*x-d*y+f; yy=d*x+c*y+g; h=line(xx,yy);
if nargin==4, set(h,'Color',col); end

%---------------------------------------------------------------------------------
%ctrllab_init perform initialization in CtrlLAB
%
%   ctrllab_init(key)  
%where key=0 for absolute initialization and 1 for only enabling of relevant menus
%---------------------------------------------------------------------------------
function ctrllab_init(key,arg1)
figure(findobj('Tag','CtrlLABMain')); uu0=get(gcf,'UserData'); kk='on'; 
if key==2, set(uu0{4}(26),'Enable','on'); %set properties with Gc(s)
else
   if key==0, 
      kk='off'; set(uu0{1}(1:3),'UserData',[]); set(uu0{1}(4),'UserData',{0,3,[],[]});
      uu0{1}(6)=0; set(gcf,'UserData',uu0);
   end
   set([uu0{3}([5:8,13,15]),uu0{4}(1),uu0{5}(1)],'Enable',kk);
   g4=get(uu0{1}(4),'UserData'); g4{3}=[]; set(uu0{1}(4),'UserData',g4)
end

%----------------------------------------------------------------
%shw_tutorial activate the toturial program in CtrlLAB
%
%   shw_tutorial(key)  
%
%where key=1,2,3,4 for the four cases in the help menu of CtrlLAB
%----------------------------------------------------------------
function shw_tutorial(nTask)
uu0=get(gcf,'UserData');
set(uu0{1}(1),'UserData',{1,tf(1,[1,3,3,1]),'1','(s+1)3'});
set(uu0{1}([2,3]),'UserData',[]); set(uu0{1}(4),'UserData',{0,3,[],[]});
ctrllab_init(1);

switch nTask
case 1, proc_model(1);
case 2, sys_analysis(1);   
case 3, sys_analysis(3);
case 4, pid_design(1); sys_analysis(6);
end

clab_help(2), 

%-----------------------------------------------------
%plant_realiz is used to display the realization of the
%plant model
%
%   plant_realiz(key)  
%where key=1,2,3,4,5 controllable, observable, Jordan,
%minimal realization and balanced realization, 
%respectively.  This function is part of CtrlLAB
%-----------------------------------------------------
function plant_realiz(nTask)
uu0=get(gcf,'UserData'); uu0=uu0{1};  g_0=get(uu0(1),'UserData'); 
g_sys=g_0{2}; G1=ss(g_sys); D=G1.d; 

switch nTask
case 1, [A,B,C,T,K]=ctrbf(G1.a,G1.b,G1.c);
case 2, [A,B,C,T,K]=obsvf(G1.a,G1.b,G1.c);
case 3, [A,B,C,D]=canon(G1.a,G1.b,G1.c,G1.d,'modal');
   n=length(C);
   for i=1:n, for j=1:n
      if i~=j, 
         if abs(A(i,j))<1e-11, A(i,j)=0; end
   end,end,end
case 4, [A,B,C,D]=minreal(G1.a,G1.b,G1.c,G1.d);
case 5
   if any(real(eig(G1.a))>=0)
      warndlg('System not is not positive definite!','Warning: Realization failed');
      return;
   else, [A,B,C]=balreal(G1.a,G1.b,G1.c); end
end   

%display the converted realization model
display_str; proc_model(1,A,B,C,D,nTask);

%-------------------------------------------------------------------------------
%add_sys_blocks adds the extra system properties to the plant model, such as the 
%ZOH, Actuator saturation, and measurement noise.
%
%   add_sys_blocks(nTask)
%where nTask=1 for adding ZOH, nTask=2,3,4 for saturation actuator, time delay 
%and measurement noise, respectively.
%-------------------------------------------------------------------------------
function add_sys_blocks(nTask)
figure(findobj('Tag','CtrlLABMain')); uu=get(gcf,'UserData');
if nTask<=4, set(uu{3}(29+nTask),'Checked','on'); end
switch nTask
case 1
case {5,6},
   hh=uu{4}(21+nTask); extra_funs(3,hh,'Checked');
   ii=extra_funs(5,4,'Checked',26:27);
   if length(ii)==0, 
      %to ensure at least one item is checked
      set(uu{4}(27),'Checked','on'); 
   end
end   

%------------------------------------------------------------------------
%file_proc is the function to administrate the file management in CrtlLAB.
%
%   file_proc(nTask)
%where
%  nTask=1 for file load, 2 for save, 3 for save as
%        4 for confirm quit, 5 for absolute quit.
%------------------------------------------------------------------------
function yesno=file_proc(nTask)
g_main=findobj('Tag','CtrlLABMain'); uu=get(g_main,'UserData');
switch nTask
case 1 %Open
   [filename,filepath]=uigetfile('*.ctr','Please Specify the File Name');
   if ~isa(filename,'double')
      uu{8}=[filepath,filename]; eval(['load(uu{8}, ''-mat'');'])
      set(uu{1}(1),'UserData',Mod_Dat{1}); set(uu{1}(2),'UserData',Mod_Dat{2});
      set(uu{1}(3),'UserData',Mod_Dat{3});
      if length(Mod_Dat{1})>0, ctrllab(0,1); end
      uu{1}(6)=0; set(g_main,'UserData',uu);
   end   
case 2 %Save
   if length(uu)==8
      Md1=get(uu{1}(1),'UserData'); Md2=get(uu{1}(2),'UserData');
      Md3=get(uu{1}(3),'UserData'); Mod_Dat={Md1,Md2,Md3};
      eval(['save(uu{8},''Mod_Dat'')']);
      uu{1}(6)=0; set(g_main,'UserData',uu);
      if nargout==1, yesno=1; end
   else
      if nargout==1, yesno=file_proc(3); 
      else, file_proc(3); end   
   end   
case 3 %Save As
   if nargout==1, yesno=1; end
   [filename,filepath]=uiputfile('*.ctr','Please Specify the File Name');
   if ~isa(filename,'double')
      uu{8}=[filepath,filename]; set(gcf,'UserData',uu); file_proc(2); 
   else, 
      if nargout==1, yesno=0; end
   end   
case 4, %display a confirm quit box
   if uu{1}(6)==1
      ButtonName=questdlg('The models have not been save.  Save them?', ...
        'Quit CtrlLAB Confirm','Yes','No','Cancel','Cancel');
      switch ButtonName,
      case 'Yes', file_proc(6);
      case 'No',  file_proc(5);
      end
   else, file_proc(5); end            
case 5, %closing all associated windows
   delete(g_main); 
   close(findobj('Tag','CtrlLABInfo'));         
   close(findobj('Tag','CtrlLABHelp'));         
   close(findobj('Tag','CtrlLABFigs'));         
   close(findobj('Tag','CtrlLABLegends'));         
   close(findobj('Tag','CtrlLABExtras'));         
   close(findobj('Tag','CtrlLABPltPref'));         
   close(findobj('Tag','MatxProcMain'));         
   close(findobj('Tag','MatxProcNew'));         
   close(findobj('Tag','MatxProcExtras'));   
case 6, %save the system and then quit
   k=file_proc(2); pause(0.0001); 
   if k, file_proc(5); end   
end

%-------------------------------------------------------------------------------
%select_sigs is the function which allows the user to select output signals from 
%the block diagram of the feedback system
%
%   select_sigs(nTask)
%where
%  nTask=1 for e(t), 2 for u(t) and 3 for y(t)
%-------------------------------------------------------------------------------
function select_sigs(nTask);
figure(findobj('Tag','CtrlLABMain')); uu=get(gcf,'UserData'); h_Sig=uu{1}(8:10);
switch nTask
case 1 %signal e(t)/Sensitivity TF selected
   extra_funs(4,4,'Checked',[28,32],[29:31,33])
case 2 %signal u(t) selected
   extra_funs(4,4,'Checked',[29,31],[28,30,32:33])
case 3 %signal y(t)/IO TF selected
   extra_funs(4,4,'Checked',[30,31],[28:29,32:33]);
case 4 %complementary sensitivity function selected
   extra_funs(4,4,'Checked',[30,33],[28:29,31:32]);
case 5 %open-loop selected
   extra_funs(4,4,'Checked',[24,30,31],[25,28:29,32:33]);
case 6 %closed-loop selected
   extra_funs(4,4,'Checked',25,24);
end      

if nTask<=3 %for signals selected, set color of signal label
   uu=get(gcf,'UserData'); h_Sig=uu{1}(8:10); ii=find(1:3~=nTask);
   set(h_Sig(nTask),'Color',[1,0,0]); set(h_Sig(ii),'Color',[0.6,0.6,0]);
end

%if there was analysis performed, then perform it again for new setting
if uu{1}(7)~=0, sys_analysis(uu{1}(7)); end

