%sys_analysis is the function used in CtrlLAB for administrating system analysis tasks.
%
%Available Analysis Tasks are:
%
%   1 for Bode diagrams
%   2 for Nyquist plots
%   3 for Nichols charts
%   4 for inverse Nyquist plots
%   5 for root loci
%   6 for step responses
%   7 for impulse responses
%   8 for stability margins
%   9 for H2 and Hinf norms evaluation
%   10 for time moments 
%   11 for Markov parameters
%   12 for analytical solutions
%
%Available lists of functions under this module
%
%  make_model -- prepares models to be analysed.
%  plt_range_dat -- updates the plot range parameters
%  refine_plot -- refines the plots according to the preset format
%  dly_freq -- evaluates the frequency response of systems with delay
%  time_resp -- evaluates the time domain response of the given system
%  plt_common -- extracts common setting in system analysis
%  make_model -- prepares models for further analysis tasks
%  tim_moments -- evaluates the time moments of the system
%  markov_paras -- evaluates the Markov parameters of the system
%  asol_disp -- displays the analytical solutions of the LTI systems
%  p_frac -- performs trianglar manipulations on the residue() function
%  sim_pars -- 
%  bode_asymp --
%  rloc_asymp --
%

%Designed by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%This module is for CtrllAB 3.0, (c) 1996-1999
%Last modified 5 October, 1999
%---------------------------------------------------------------------------------

function sys_analysis(nTask,arg1,arg2)
switch nargin
case 0
   %call simulation parameters dialog box 
   sim_pars;
case 1   
   %bring the main window to front
   figure(findobj('Tag','CtrlLABMain')); 
   uu=get(gcf,'UserData'); g1=get(uu{1}(1),'UserData');
   if length(g1)==0, 
      warndlg('Plant model dose not exist, please enter it first!','Matrix Processor Warning:'); 
   else
      uu{1}(7)=nTask; set(gcf,'UserData',uu);
      g_comp=extra_funs(5,4,'Checked',26:27,[]);
      if any([1:7,14:16]==nTask), [x1,x2,n_points,k_extra]=plt_range_dat(nTask); end
      switch nTask
      case {1,2,3,4,14,15}
         if length(x1)==0, [x,y,w,arg4]=dly_freq(k_extra(2),g_comp(1),nTask);
         else,
            w=logspace(log10(x1),log10(x2),n_points);
            [x,y,w0,arg4]=dly_freq(k_extra(2),g_comp(1),nTask,w);
         end
         if length(g_comp)>1, [x1,y1,w0,arg5]=dly_freq(k_extra(2),g_comp(2),nTask,w); end
         switch nTask
         case {1,14}, graf_tool(1);
            if length(g_comp)>1,
               subplot(211), semilogx(w,20*log10(x),w,20*log10(x1)); 
               if nTask==14, line(arg5(1,:),arg5(2,:)); end
               ylabel('Magnitude (dB)'), title('Bode Diagram')
               subplot(212), semilogx(w,y,w,y1); ylabel('Phase (degrees)')
            else   
               subplot(211), semilogx(w,20*log10(x)); 
               if nTask==14, line(arg4(1,:),arg4(2,:)); end
               ylabel('Magnitude (dB)'), title('Bode Diagram')
               subplot(212), semilogx(w,y); ylabel('Phase (degrees)')
            end
            title('Frequenct \omega (Radian)')
         case {2,4,15}, 
            if nTask<=7, graf_tool(nTask); else, graf_tool(2); end
            p_tmp=pi/180*y; H=x.*(cos(p_tmp)+sqrt(-1)*sin(p_tmp)); H=[H,conj(H)];
            if length(g_comp)>1,
               p_tmp=pi/180*y1; H1=x1.*(cos(p_tmp)+sqrt(-1)*sin(p_tmp)); H1=[H1,conj(H1)];
               if any([2,15]==nTask), h=plot(real(H),imag(H),real(H1),imag(H1));
               else, h=plot(real(1./H),imag(1./H),real(1./H1),imag(1./H1)); end   
            else   
               if any([2,15]==nTask), h=plot(real(H),imag(H));
               else, h=plot(real(1./H),imag(1./H)); end   
            end
            set(h,'UserData',w); xlabel('Real Axis'); ylabel('Imaginary Axis'), 
            switch nTask
            case 2, title('Nyquist Plot')
            case 4, title('Inverse Nyquist Plot'); 
            case 15, title('ATAN Nyquist Plot')
            end   
         case 3, graf_tool(3);
            bHold=ishold;
            if ~bHold, delete(extra_funs(2)); ngrid('new'); end
            if length(g_comp)>1, h=plot(y,20*log10(x),y1,20*log10(x1)); 
            else, h=plot(y,20*log10(x)); end
            set(h,'UserData',w); xlabel('Phase (degree)')
            ylabel('Magnitude (dB)'), title('Nichols Chart')
            if ~bHold, hold off; end
         end         
      case {5,16}, 
         %for root locus analysis, only the open-loop model is meaningful.
         [G_forward,G_Sys,Gc_Sys,H_Sys,Td,nPade,GP,g_loop,g_reltn]=plt_common(1,g_comp(1));
         graf_tool(5);
         if length(x1)==0, [r,k]=rlocus(G_forward);
         else, 
            if ~isfinite(x2), x2=1000; end
            if abs(x1)<eps, x1=0.001; end
            k=logspace(log10(x1),log10(x2),n_points); r=rlocus(G_forward,k);
         end
         if length(g_comp)>1,
            r1=rlocus(G_Sys,k); h=plot(real(r'),imag(r'),real(r1'),imag(r1')); 
            [z,p,k]=zpkdata(G_Sys,'v');
            if length(z)>0, h=line(real(z),imag(z),'Marker','o','LineStyle','none'); end
            if length(p)>0, h=line(real(p),imag(p),'Marker','x','LineStyle','none'); end
         else, h=plot(real(r'),imag(r')); end
         [z,p,k]=zpkdata(G_forward,'v');
         if length(z)>0, h=line(real(z),imag(z),'Marker','o','LineStyle','none'); end
         if length(p)>0, h=line(real(p),imag(p),'Marker','x','LineStyle','none'); end
         set(h,'UserData',k); xlabel('Real Axis'); ylabel('Imaginary Axis'), title('Root Locus')
         if nTask==16, rloc_asymp(G_forward); if length(g_comp)>1, rloc_asymp(G_Sys); end, end
      case {6,7}, 
         if length(x1)==0
            [y,t]=time_resp(k_extra,g_comp(1),nTask); 
            if length(y)==0; return; end
         else
            t=x1:(x2-x1)/n_points:x2; y=time_resp(k_extra,g_comp(1),nTask,t);
         end   
         if length(g_comp)>1, y1=time_resp(k_extra,g_comp(2),nTask,t); end   
         graf_tool(nTask);
         if length(g_comp)>1, plot(t,y,t,y1); else, plot(t,y); end
         xlabel('Time (Sec)'); ylabel('Response Magnitude');
         if nTask==6, title('Step Response');
         else, title('Impulse Response'); end
      case 8, %gain phase margins
         figure(findobj('Tag','CtrlLABMain')); uu0=get(gcf,'UserData');
         g1=get(uu0{1}(1),'UserData'); G_Sys=g1{2}; 
         g2=get(uu0{1}(2),'UserData'); if length(g2)>0, Gc_Sys=g2{2}; else, Gc_Sys=1; end
         g3=get(uu0{1}(3),'UserData'); if length(g3)>0, H_Sys=g3{2}; else, H_Sys=1; end
         g4=get(uu0{1}(4),'UserData'); Td=g4{1}; nPade=g4{2};
         if Td>0, [nP,dP]=pade(Td,nPade); GP=tf(nP,dP); else, GP=1; end
         G1=G_Sys*H_Sys*GP; [Gm,Pm,Wcg,Wcp]=margin(G1);
         if length(g_comp)>1, G2=G1*Gc_Sys; [Gm1,Pm1,Wcg1,Wcp1]=margin(G2); end
         display_str; 
         display_str(0.1,0.8,['Gain Margin: ',display_str(Gm),' at \omega=' display_str(Wcg)],[1,0,0]);
         display_str(0.1,0.6,['Phase Margin: ',display_str(Pm) '^o at \omega=' display_str(Wcp)],[1,0,0]);
         if length(g_comp)>1, 
            display_str(0.1,0.4,['Gain Margin: ',display_str(Gm1),' at \omega=' display_str(Wcg1)],[0,0,1]);
            display_str(0.1,0.2,['Phase Margin: ',display_str(Pm1) '^o at \omega=' display_str(Wcp1)],[0,0,1]);
         end   
      case {9,10,11,12}
         [G_Sys1,g1]=make_model(g_comp(1)); 
         if length(g_comp)>1, [G_Sys2,g2]=make_model(g_comp(2)); end
         switch nTask
         case 9, %H_2 & H_inf norm evaluation
            H2=norm(g1,2); Hinf=norm(g1,inf); display_str; 
            display_str(0.1,0.8,['H_2 Norm=',display_str(H2),', H_\infty Norm=' display_str(Hinf)],[1,0,0]);
            if length(g_comp)>1, 
               H2=norm(g2,2); Hinf=norm(g2,inf);
               display_str(0.1,0.5,['H_2 Norm=',display_str(H2),', H_\infty Norm=' display_str(Hinf)],[0,0,1]);
            end
         case 10, % time moments   
            M1=tim_moments(g1,7); display_str;
            display_str(0.1,0.8,'Time Moments:',[1,0,0]); display_str(0.1,0.65,M1,[1,0,0]);
            if length(g_comp)>1, 
               M2=tim_moments(g2,7); 
               display_str(0.1,0.4,'Time Moments:',[0,0,1]); display_str(0.1,0.25,M2,[0,0,1]);
            end
         case 11, %Markov parameters   
            M1=markov_paras(g1,7); display_str;
            display_str(0.1,0.8,'Markov Parameters:',[1,0,0]); display_str(0.1,0.65,M1,[1,0,0]);
            if length(g_comp)>1, 
               M2=markov_paras(g2,7); 
               display_str(0.1,0.4,'Markov Parameters:',[0,0,1]); display_str(0.1,0.25,M2,[0,0,1]);
            end
         case 12, %analytic solutions
            key=get(uu{4}(7),'Checked'); display_str;
            xL(1)=asol_disp(g1,key,0.1,0.8,[1,0,0]); 
            if length(g_comp)>1, xL(2)=asol_disp(g2,key,0.1,0.3,[0,0,1]); end
         end   
      case 13
         [G_Sys1,g1]=make_model(g_comp(1),[]);  
         if length(g_comp)>1, [G_Sys2,g2]=make_model(g_comp(2),[]); end
         inv_T=1/norm(g1,inf); t1=1-inv_T; t2=1+inv_T; t3=-2*asin(0.5*inv_T)*180/pi; display_str;
         display_str(0.1,0.8,['Guaranteed Gain Margin: [' num2str(t1) ',' num2str(t2) ']'],[1,0,0]); 
         display_str(0.1,0.6,['Guaranteed Phase Margin: [' num2str(t3) '^o,' num2str(-t3) '^o]'],[1,0,0]); 
         if length(g_comp)>1, 
            inv_T=1/norm(g2,inf); t1=1-inv_T; t2=1+inv_T; t3=-2*asin(0.5*inv_T)*180/pi;
            display_str(0.1,0.4,['Guaranteed Gain Margin: [' num2str(t1) ',' num2str(t2) ']'],[0,0,1]); 
            display_str(0.1,0.2,['Guaranteed Phase Margin: [' num2str(t3) '^o,' num2str(-t3) '^o]'],[0,0,1]); 
         end
      end      
      if nTask<=7, refine_plot(nTask); end
   end
case 2
   uu=get(gcf,'UserData'); g_graf=gcf;
   switch arg1
   case 1
      kk=get(uu{3}(1),'Value'); set(uu{3}(2),'Value',~kk);
      set(uu{1}(1:6),'Visible',extra_funs(6,~kk)); set(uu{1}(7:8),'Visible',extra_funs(6,kk));
   case 2   
      kk=get(uu{3}(2),'Value'); set(uu{3}(1),'Value',~kk);
      set(uu{1}(1:6),'Visible',extra_funs(6,kk)); set(uu{1}(7:8),'Visible',extra_funs(6,~kk));
   case 4
      keyAlg=get(uu{4},'Value'); ww(6)=num2str(get(uu{1}(9),'String'));
      bFixedStep=get(uu{3}(1),'Value');
      if bFixedStep==0,
         ww(2)=get(uu{1}(2),'String'); eval(['tmin=',ww(2),';']);
         ww(3)=get(uu{1}(4),'String'); eval(['tmax=',ww(3),';']);
         ww(4)=get(uu{1}(6),'String'); eval(['terr=',ww(4),';']);
      else, 
         ww(5)=get(uu{1}(8),'String'); eval(['tmin=',ww(5),';']);
      end
      ww(7)=get(uu{1}(10),'String'); ww(8)=get(uu{1}(11),'String');
      ww(9)=get(uu{1}(12),'String'); ww(1)=get(uu{1}(13),'String');
      uu{6}=ww; set(g_graf,'UserData',uu);
   end   
case 3
   [mag,pha,w]=bode(arg1);
   subplot(211), semilogx(w,20*log10(mag(:)));
   ylabel('Magnitude (dB)'), title('Bode Diagram')
   subplot(212), semilogx(w,pha(:)); ylabel('Phase (degrees)')
   title('Frequenct \omega (Radian)')
end

%-------------------------------------------------------
%plt_range_dat is used to set the plot range parameters.
%-------------------------------------------------------
function [x1,x2,n_points,k_extra]=plt_range_dat(nTask)
%output argument initialization
key=0;
x1=[]; x2=[]; n_points=[]; k_extra=zeros(1,2); k_match=0;
figure(findobj('Tag','CtrlLABMain')); uu=get(gcf,'UserData');
if length(uu)>=10, 
   u_data=uu{10}; if length(u_data)>0, k_match=u_data(5); end
end

switch k_match
case {1,2,3,4}
   %set frequency response data
   if any([1:4]==nTask), key=1; end
case 5,
   %set root locus data
   if nTask==5, key=1; end
case {6,7}   
   %set time-domain response data
   if any([6:7]==nTask), key=1; end
end
if key==1
   x1=u_data(1); x2=u_data(2); n_points=u_data(3); k_extra=u_data([4,6]);
end

%-----------------------------------------------------------------------
%refine_plot is used to refine the plots according to the preset format.
%-----------------------------------------------------------------------
function refine_plot(nTask)
it=get(gca,'Title'); pp=get(it,'Position'); xL=get(gca,'XLim'); yL=get(gca,'YLim');
set(it,'Position',[pp(1), 1.006*yL(2)-0.006*yL(1),pp(3)])
if nTask==1
   ii=extra_funs(2); axes(ii(2)); it=get(gca,'Title'); pp=get(it,'Position');
   yL=get(gca,'YLim'); set(it,'Position',[pp(1), 1.006*yL(2)-0.006*yL(1),pp(3)])
else, 
   ix=get(gca,'xLabel'); x0=0.85*xL(2)+0.15*xL(1);
   y0=0.08*yL(2)+0.92*yL(1); set(ix,'Position',[x0,y0,0]);
end

%update plot properties according to the settings
graf_tool(2,1); graf_tool(2,2); graf_tool(2,4); 

%-------------------------------------------------------------------------------------
%dly_freq is a function used to evaluate the frequency response of a system containing 
%a pure time delay element exp(-tdly*s) over the frequency range of W.       
%
%     [mag,pha,w,arg4]=dly_freq(k_Pade,nCtrl,nTask,w)
%
%where
%  mag,pha -- the magnitude and phase over w
%  w -- the frequency vector
%  nCtrl -- whether the compensated system are required
%  nTask -- the system analysis task code
%  k_Pade -- whether Pade approximation is used for delay
%-------------------------------------------------------------------------------------
function [mag,pha,w,arg4]=dly_freq(k_Pade,nCtrl,nTask,w)

[G_forward,G_Sys,Gc_Sys,H_Sys,Td,nPade,GP,g_loop,g_reltn]=plt_common(k_Pade,nCtrl);
arg4=[];
if nargin==3
   %selecting the frequency vector w in an automatic way
   [num,den]=tfdata(G_Sys,'v'); w=freqint2(num,den,30); 
end
if g_loop==1, 
   %processing open-loop
   if k_Pade==1 & Td>0, G_forward=G_forward*GP; 
   elseif Td>0, G_forward.InputDelay=Td; end
   G_overall=G_forward; [mag,pha]=bode(G_forward,w); mag=mag(:); pha=pha(:);
else   
   %processing closed-loop
   if Td>0 & k_Pade==0
      Gf=G_forward; Gf.InputDelay=Td;
      [mag,pha]=bode(Gf,w); mag=mag(:); pha=pi*pha(:)/180;
      Hf=mag.*exp(-sqrt(-1)*pha);
      if isa(H_Sys,'double'), H=H_Sys; else, H=nyquist(H_Sys,w); end
      switch g_reltn
      case 1, HH=Hf./(1+H.*Hf); 
      case {2,3}, HH=ones(size(Hf))./(1+H.*Hf); if g_reltn==3, HH=1-HH; end
      end
      mag=abs(HH); pha=phase(HH')'*180/pi;   
   else   
      G_forward=G_forward*GP;
      switch g_reltn
      case 1, G_overall=feedback(G_forward,H_Sys*GP); %closed loop I/O
      case {2,3}, G_overall=feedback(1,G_forward*H_Sys*GP); %closed-loop sensitivity & comp sens
         %evaluate complementary sensitivity function
         if g_reltn==3, G_overall=1-G_overall; end
      end  
      [mag,pha]=bode(G_overall,w); mag=mag(:); pha=pha(:);
   end      
end
switch nTask
case 14, [xpos,ypos]=bode_asymp(G_overall,w); arg4=[xpos; ypos];
case 15, mag=2*atan(mag)/pi;
end

%---------------------------------------------------------------------------
%time_resp is used to evaluate the time domain response of the given system.
%---------------------------------------------------------------------------
function [y,t]=time_resp(k_Extras,nCtrl,nTask,t)

y=[]; if nargout==2, t=[]; end
[G_forward,G_Sys,Gc_Sys,H_Sys,Td,nPade,GP,g_loop,g_sigs]=plt_common(k_Extras,nCtrl);
if length(G_forward)==0, return; end

if nTask==6, plt_cmd='step'; else, plt_cmd='impulse'; end
if nargin==3, %selecting the time vector t in an automatic way
   eval(['[a,t]=' plt_cmd '(G_Sys);']) 
end

%check whether there is delay and whether Pade appr is needed

if k_Extras(1)==1
   str=str2mat('This function is not available yet!  Please check off',...
      'the SIMULINK selction and try again!');
   warndlg(str,'Cannot use SIMULINK!'); 
else   
   if g_loop==1
      %processing open-loop
      if k_Extras(2)==1 & Td>0, G_forward=G_forward*GP; 
      elseif Td>0, G_forward.InputDelay=Td; end
      G_overall=G_forward;
   else   
      %processing closed-loop
      G_forward=G_forward*GP;
      switch g_sigs
      case 1, %closed-loop error signal
         G_overall=feedback(1,G_forward*H_Sys*GP); 
      case 2, %evaluate the actuating signal
         G_overall=feedback(Gc_Sys,G_forward*H_Sys*GP); 
      case 3, %closed loop I/O
         G_overall=feedback(G_forward,H_Sys*GP); G_overall.InputDelay=Td;
      end  
   end
   if nargin==3, eval(['[y,t]=' plt_cmd '(G_overall);']);   
   else, eval(['y=' plt_cmd '(G_overall,t);']); end
end

%---------------------------------------------------------------------------
%plt_common is used to extract common setting in system analysis.
%
%  [G_Sys,Gc_Sys,H_Sys,Td,nPade,g_loop,g_sel]=plt_common(key)
%where 
%  key = 1 for time response, else for frequency response
%  G_Sys, Gc_Sys, H_Sys, Td and nPade are models extracted
%  g_loop -- the loop information, i.e., closed-loop via open-loop
%  g_sel -- selection signal, for freq response, select the transfer 
%          function, else select the signal.
%---------------------------------------------------------------------------
function [G_forward,G_Sys,Gc_Sys,H_Sys,Td,nPade,GP,g_loop,g_sel]=plt_common(k_Pade,nCtrl)
if length(k_Pade)>1, if k_Pade(1)==1; 
   %direct inclusion if SIMULINK blocks are not enabled now   
   G_forward=[]; G_Sys=[]; Gc_Sys=[]; H_Sys=[]; Td=[]; 
   nPade=[]; GP=[]; g_loop=[]; g_sel=[];
   str=str2mat('This function is not available yet!  Please check off',...
      'the SIMULINK selction and try again!');
   warndlg(str,'Cannot use SIMULINK!'); 
   return; 
end, end

figure(findobj('Tag','CtrlLABMain')); uu0=get(gcf,'UserData');
g_loop=extra_funs(5,4,'Checked',24:25); 

%use I/O relationship/y(t) only
if g_loop==1, extra_funs(4,4,'Checked',30:31,[28:29,32:33]); end   

if length(k_Pade)>1, %set signal selection
   k_Pade=k_Pade(2); g_sel=extra_funs(5,4,'Checked',28:30);
else, g_sel=extra_funs(5,4,'Checked',31:33); %set TF relationsship
end

%get all the sub-models
g1=get(uu0{1}(1),'UserData'); G_Sys=g1{2}; 
g2=get(uu0{1}(2),'UserData'); if length(g2)>0, Gc_Sys=g2{2}; else, Gc_Sys=1; end
g3=get(uu0{1}(3),'UserData'); if length(g3)>0, H_Sys=g3{2}; else, H_Sys=1; end
g4=get(uu0{1}(4),'UserData'); Td=g4{1}; nPade=g4{2};

if k_Pade==1 & Td>0, [nP,dP]=pade(Td,nPade); GP=tf(nP,dP);
else, GP=1; end

G_forward=G_Sys; if nCtrl==1, G_forward=Gc_Sys*G_Sys; end

%----------------------------------------------------------------------
%make_model prepares models for further analysis tasks
%----------------------------------------------------------------------
function [G_overall,G_pade]=make_model(nCtrl,arg1)
[G_forward,G_Sys,Gc_Sys,H_Sys,Td,nPade,GP,g_loop,g_reltn]=plt_common(1,nCtrl);
if nargin==2, g_loop=2; r_reltn=3; end
if g_loop==1
   %processing open-loop
   if Td>0, G_forward.InputDelay=Td; end
   G_overall=G_forward; 
else   
   %processing closed-loop
   G_forward=G_forward*GP;
   switch g_reltn
   case 1, G_overall=feedback(G_forward,H_Sys*GP); %closed loop I/O
   case {2,3}, G_overall=feedback(1,G_forward*H_Sys*GP); %closed-loop sensitivity & comp sens
      %evaluate complementary sensitivity function
      if g_reltn==3, G_overall=1-G_overall; end
   end  
end
G_pade=G_overall; G_pade.InputDelay=0;
if Td>0, [nP,dP]=pade(Td,nPade); G_pade=G_pade*tf(nP,dP); end

%----------------------------------------------------------------------
%tim_moments evaluates the time moments of the specified system
%----------------------------------------------------------------------
function M=tim_moments(G,k)
G=ss(G); C=G.c; B=G.b; iA=inv(G.a); iA1=iA; M=[];
for i=1:k, 
   mm=-C*iA1*B; sgn='+'; if mm<0, sgn=''; end
   M=[M, sgn display_str(mm) 's^{' int2str(i) '}'];
   iA1=iA*iA1; 
end
M=[M '+o(s^{' int2str(k+1) '})'];

%----------------------------------------------------------------------
%markov_paras evaluates the Markov parameters of the specified system
%----------------------------------------------------------------------
function M=markov_paras(G,k)
G=ss(G); A=G.a; B=G.b; C=G.c; D=G.d; 
A1=A; M=display_str(C*B+D);
for i=1:k-1, 
   mm=C*A1*B; sgn='+'; if mm<0, sgn=''; end
   M=[M, sgn display_str(mm) 's^{-' int2str(i) '}'];
   A1=A*A1; 
end
M=[M '+o(s^{-' int2str(k) '})'];

%--------------------------------------------------------------------------------
%asol_disp displays in styled format the analytical solutions of the LTI systems
%--------------------------------------------------------------------------------
function [xL,t_vec]=asol_disp(sys_mod,key,xL1,yL1,nCol);
sys_mod=tf(sys_mod); key0=1; 
if strcmp(key,'on'), sys_mod.den={[sys_mod.den{1},0]}; end
if nargin==4, 
   t_vec=xL1; key0=0; if length(t_vec)==0, t_vec=0:.01:1; end; xL=zeros(size(t_vec)); 
else, xL=xL1; end

[r,p,k]=p_frac(sys_mod); Str_s=[]; pp=1.2345678; kk=0;
for i=1:length(r)
   g_i=imag(p(i)); ss1=[]; if real(r(i))>0 & i~=1, ss1='+'; end,
   if g_i>=0
      ss2='-'; if real(p(i))>0, ss2=''; end, ss_x=display_str(r(i));
      if abs(p(i)-pp)<1e-5*abs(pp), kk=kk+1; else, kk=0; pp=p(i); end   
      if ~strcmp(ss_x,'0'), 
         if (strcmp(ss_x,'1')& abs(real(p(i)))>1e-12 &i==length(r)), ss_x=''; 
         elseif strcmp(ss_x,'-1'), ss_x='-'; end
         Str_s=[Str_s,ss1,ss_x]; 
         if abs(real(p(i)))>1e-12, 
            if kk==0, ss0=''; elseif kk==1, ss0='t'; else, ss0=['t^{' int2str(kk) '}']; end   
            Str_s=[Str_s,ss0,'e^{' ss2, display_str(abs(real(p(i))),[]), 't}'];
         end
         if g_i>1e-10
            ss3='+'; if r(i+1)<0, ss3=''; end
            Str_s=[Str_s,'sin(' display_str(g_i,[]),'t',ss3,num2str(180*r(i+1)/pi),'^o)'];
         end, 
      end   
   end
end

%show analytical solutions
xL=display_str(xL1,yL1,Str_s,nCol); 

%--------------------------------------------------------------------------------
%p_frac performs extra trianglar manipulations on the results of residue function
%--------------------------------------------------------------------------------
function [R,P,K]=p_frac(G)
[num,den]=tfdata(G,'v'); [R,P,K]=residue(num,den); 
for i=1:length(R),
   if imag(P(i))>eps
      a=real(R(i)); b=imag(R(i)); R(i)=-2*sqrt(a^2+b^2); R(i+1)=atan2(-a,b);
   end
end
R=real(R);

%--------------------------------------------------------------------------------
%sim_pars creates an extra menu item for system simulation parameters using 
%SIMULINK program.
%--------------------------------------------------------------------------------
function sim_pars()
g_graf=gcf; g_SimPars=findobj('Tag','CtrlLABSimPars'); 
if length(g_SimPars)==0
   uu=get(g_graf,'UserData'); ww=uu{6};
   g_SimPars=figure('Units','normalized','Position',[0.1425 0.132 0.5 0.41],...
      'MenuBar','none','Color',0.8*[1,1,1],'Resize','off','Tag','CtrlLABSimPars',...
      'NumberTitle','off','Name','Simulation Parameters Setting ...','Resize','off');
   extra_funs(1); extra_funs(10,[0.035,0.58],[0.58,0.92]);
   uicontrol('Style','Text','Unit','normalized','Position',[0.055,0.85,0.3,0.08],...
      'String','Simulation Algorithm','BackgroundColor',0.8*[1,1,1]);
   hSimAlg=uicontrol('Style','Popupmenu','Unit','normalized','Position',[0.115,0.75,0.35,0.08],...
      'BackgroundColor',[1,1,1],'Value',1,...
      'String','ode45 (defaults) | ode45 | ode23 | ode113 | ode15s | ode23s');
   extra_funs(10,[0.035,0.05],[0.58,0.50]);
   uicontrol('Style','Text','Unit','normalized','Position',[0.065,0.46,0.33,0.07],...
      'String','Simulation Parameters','BackgroundColor',0.8*[1,1,1]);
   display_str(0.075,0.40,'Terminate Time',[0,0,0],'on',9);
   h(9)=uicontrol('Style','Edit','Unit','normalized','Position',[0.315 0.35 0.15 0.07],...
      'String',num2str(ww(6)),'BackgroundColor',[1,1,1]);
   [xL,h(1)]=display_str(0.075,0.31,'Min Step',[0,0,0],'on',9);
   [xL,h(3)]=display_str(0.075,0.21,'Max Step',[0,0,0],'on',9);
   h(2)=uicontrol('Style','Edit','Unit','normalized','Position',[0.315 0.26 0.15 0.07],...
      'BackgroundColor',[1,1,1],'String',num2str(ww(2)));
   h(4)=uicontrol('Style','Edit','Unit','normalized','Position',[0.315 0.17 0.15 0.07],...
      'BackgroundColor',[1,1,1],'String',num2str(ww(3)));
   [xL,h(5)]=display_str(0.075,0.12,'Tolerant Error',[0,0,0],'on',9);
   h(6)=uicontrol('Style','Edit','Unit','normalized','Position',[0.315 0.08 0.15 0.07],...
      'BackgroundColor',[1,1,1],'String',num2str(ww(4)));
   [xL,h(7)]=display_str(0.075,0.24,'Step Size',[0,0,0],'on',9);
   h(8)=uicontrol('Style','Edit','Unit','normalized','Position',[0.315 0.22 0.12 0.07],...
      'BackgroundColor',[1,1,1],'String',num2str(ww(5)));
   [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
   if v2==2 & v3==0, strRadio='ToggleButton'; strCheck='ToggleButton';
   else, strRadio='RadioButton'; strCheck='CheckBox'; end 
   rdFixed(1)=uicontrol('Style',strRadio,'Unit','normalized','Position',[0.055,0.63,0.19,0.08],...
      'String','Fixed Step','BackgroundColor',0.8*[1,1,1],'Value',0,'CallBack','sys_analysis(1,1);');
   rdFixed(2)=uicontrol('Style',strRadio,'Unit','normalized','Position',[0.285,0.63,0.25,0.08],...
      'String','Variable Step','BackgroundColor',0.8*[1,1,1],'Value',1,'CallBack','sys_analysis(1,2);');
   rdFixed(3)=uicontrol('Style',strCheck,'Unit','normalized','Position',[0.615,0.73,0.28,0.08],...
      'String','Show Linearised','BackgroundColor',0.8*[1,1,1],'Value',1);
   extra_funs(10,[0.61,0.054],[0.975,0.68]);
   uicontrol('Style','Text','Unit','normalized','Position',[0.635 0.62 0.19 0.08],...
      'BackgroundColor',0.8*[1,1,1],'HorizontalAlignment','left','String',' Input Signal');
   hh(1)=uicontrol('Style','PushButton','Unit','normalized','Position',[0.625,0.52,0.1,0.1],...
      'String','Sine','BackgroundColor',0.8*[1,1,1],'CallBack','sys_analysis(1,5);');
   hh(2)=uicontrol('Style','PushButton','Unit','normalized','Position',[0.74,0.52,0.1,0.1],...
      'String','Sqr','BackgroundColor',0.8*[1,1,1],'CallBack','sys_analysis(1,6);');
   hh(3)=uicontrol('Style','PushButton','Unit','normalized','Position',[0.855,0.52,0.1,0.1],...
      'String','Saw','BackgroundColor',0.8*[1,1,1],'CallBack','sys_analysis(1,7)');
   display_str(0.65,0.44,'Peak Value',[0,0,0],'on',9);
   h(10)=uicontrol('Style','Edit','Unit','normalized','Position',[0.84 0.40 0.1 0.07],...
      'String',num2str(ww(7)),'BackgroundColor',[1,1,1]);
   display_str(0.65,0.34,'Peak Range',[0,0,0],'on',9);
   h(11)=uicontrol('Style','Edit','Unit','normalized','Position',[0.84 0.30 0.10 0.07],...
      'String',num2str(ww(8)),'BackgroundColor',[1,1,1]);
   display_str(0.65,0.24,'Frequency',[0,0,0],'on',9);
   h(12)=uicontrol('Style','Edit','Unit','normalized','Position',[0.84 0.20 0.1 0.07],...
      'String',num2str(ww(9)),'BackgroundColor',[1,1,1]);
   display_str(0.65,0.14,'Freq Range',[0,0,0],'on',9);
   h(13)=uicontrol('Style','Edit','Unit','normalized','Position',[0.84 0.10 0.1 0.07],...
      'String',num2str(ww(1)),'BackgroundColor',[1,1,1]);

%%  Execute and Close Window
   uicontrol('Style','PushButton','Unit','normalized','Position',[0.65,0.85,0.14,0.09],...
      'String','Change','BackgroundColor',0.8*[1,1,1],'CallBack','sys_analysis(1,10);');
   uicontrol('Style','PushButton','Unit','normalized','Position',[0.81,0.85,0.14,0.09],...
      'String','Default','BackgroundColor',0.8*[1,1,1],'CallBack','delete(gcf)');
   set(gcf,'UserData',{h,hh,rdFixed,hSimAlg});
   sys_analysis(1,1);
else
   figure(g_SimPars);   
end

%--------------------------------------------------------------------------------
%bode_asymp gets the information for Bode asymptotics
%--------------------------------------------------------------------------------
function [wpos,ypos]=bode_asymp(G,w)
[zer,pol,gain]=zpkdata(G,'v'); wpos=[]; pos1=[];
for i=1:length(zer);
   if isreal(zer(i)), wpos=[wpos, abs(zer(i))]; pos1=[pos1,20];
   else, if imag(zer(i))>0, wpos=[wpos, abs(zer(i))]; pos1=[pos1,40]; end
end, end
for i=1:length(pol);
   if isreal(pol(i)), wpos=[wpos, abs(pol(i))]; pos1=[pos1,-20];
   else, if imag(pol(i))>0, wpos=[wpos, abs(pol(i))]; pos1=[pos1,-40]; end
end, end
wpos=[wpos w(2) w(end)]; pos1=[pos1,0,0];
[wpos,ii]=sort(wpos); pos1=pos1(ii); ii=find(abs(wpos)<eps); kslp=0; w_start=1000*eps; 
if length(ii)>0, 
   kslp=sum(pos1(ii)); ii=(ii(end)+1):length(wpos); wpos=wpos(ii); pos1=pos1(ii); 
end
while 1
   [ypos1,pp]=bode(G,w_start);
   if isinf(ypos1), w_start=w_start*10; else, break; end
end
wpos=[w_start wpos]; ypos(1)=20*log10(ypos1); pos1=[kslp pos1];
for i=2:length(wpos)
   kslp=sum(pos1(1:i-1)); ypos(i)=ypos(i-1)+kslp*log10(wpos(i)/wpos(i-1));      
end
ii=find(wpos>=w(2) & wpos<=w(end)), wpos=wpos(ii); ypos=ypos(ii);

%--------------------------------------------------------------------------------
%rloc_asymp gets the information for root locus asymptotics
%--------------------------------------------------------------------------------
function [xpos,ypos]=rloc_asymp(G)
[zer,pol,gain]=zpkdata(G,'v');
ii=find(abs(zer)<1e10); 
if length(ii)>0, zer=zer(ii); end
nExcess=length(pol)-length(zer); 
if nExcess>0
   pp=(sum(real(pol))-sum(real(zer)))/nExcess; deltaP=pi/nExcess; 
   xx=get(gca,'Xlim'); yy=get(gca,'YLim'); xx1=(xx(1)-pp)*tan(deltaP); 
end
xpos=[pp*ones(1,nExcess); zeros(1,nExcess)]; ypos=zeros(2,nExcess); 
for i=1:nExcess
   PAngle=(2*i-1)*deltaP; Kslp=tan(PAngle); 
   if (pi/2>=PAngle & PAngle>=0), xP=xx(2); yP=yy(2);
   elseif (pi>=PAngle&PAngle>pi/2), xP=xx(1); yP=yy(2);
   elseif (3*pi/2>=PAngle&PAngle>pi), xP=xx(1); yP=yy(1);
   else, xP=xx(2); yP=yy(1); end
   xx1=xP; yy1=Kslp*(xx1-pp); 
   if yy1>yy(2) | yy1<yy(1), yy1=yP; xx1=yy1/Kslp+pp; end
   xpos(2,i)=xx1; ypos(2,i)=yy1;
end
if nargout==0, line(xpos,ypos); end