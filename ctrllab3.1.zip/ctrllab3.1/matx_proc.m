%matx_proc is a group of functions which can be used either as an individual 
%program for matrix processing or used as part of CtrlLAB.
%
%   [ret1,ret2,ret3]=matx_proc(A,arg1,arg2)
%where
%  A -- either a system model, matrix, or a task code
%  arg1,arg2 -- extra arguments
%
%The functions available in the module are
%
%  matx_controls -- creates all the control objects on main window
%  matx_menu -- creates the menu system on the main window
%  matx_toolbar -- creates a toolbar for Matrix Processor
%  matx_init -- initializes the matrix processing interface
%  disp_matrix -- displays a matrix
%  matx_edit -- allows the user to edit the matrix elements
%  matx_update -- updates the current matrix 
%  matdisp_pars -- obtains the display format
%  shw_matpars -- shows the properties of the given matrix
%  matx_pars -- evaluates parameters of a given matrix
%  sys_disp -- displays the system state space format in the window
%  matx_file -- manipulates the File menu in the program
%  mat_decomp -- performs matrix decomposition
%  shw_decmat -- displays a matrix in decomposition
%  shw_matrix -- displays the matrix
%  mat_funs -- evaluates exp(A), sin(A), cos(A)
%  frame_setting -- administrates the area for matrix display
%  flt_replace -- changes the float value to MATLAB string
%  issquare -- detects whether a matrix given is square
%  con_obsv -- detects is controllable, observable, stabilizable, and detectable.
%  stab_detc -- checks the stabilizability or detectability 
%

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%----------------------------------------------------------------------------

function ret1=matx_proc(A,arg1,arg2)

if nargin==0, 
   %Using this program as in independent program
   A=[]; %initialize it
end

if nargin>=2
   nTask=A;
   switch nTask
   case 0, %administrate the File menu in the program   
      if nargout==0, matx_file(arg1); 
      else, ret1=matx_file(arg1); end  
   case 1, disp_matrix(arg1);%display a given matrix in MATLAB or TeX format
   case 2, matx_edit;%editing an existing matrix/system
   case 3, matx_update;%update the matrix display
   case 4, sys_disp;%redisplay the system
   case 5, shw_matpars(arg1);%display the parameters of a matrix
   case 6, if nargin==3, sys_disp; end %display state space model
   case 7, matx_decomp(arg1); %perform matrix decompositions
   case 8, shw_decmat(arg1); %display matrix decompositions
   case 9, disp_matrix(arg1,[]);%prepare a matrix to display
   case 10, %display a matrix
      switch arg1
      case 1, extra_funs(4,4,'Checked',2,3:4); 
      case 2, extra_funs(4,4,'Checked',3,[2,4]); 
      case 3, extra_funs(4,4,'Checked',4,2:3); 
      case 4, extra_funs(4,4,'Checked',5,[6,7]); 
      case 5, extra_funs(4,4,'Checked',6,[5,7]); 
      case 6, extra_funs(4,4,'Checked',7,[5,6]); 
      case 7, extra_funs(4,4,'Checked',10,11:13); 
      case 8, extra_funs(4,4,'Checked',11,[10,12:13]); 
      case 9, extra_funs(4,4,'Checked',12,[10,11,13]); 
      case 10, extra_funs(4,4,'Checked',13,[10:12]);  
      case 11, extra_funs(4,4,'Checked',[3,6,10],[2,4,5,7,11:13]);   
      case 12, 
         if get(gco,'Value')==1, extra_funs(4,4,'Checked',4,2:3);
         else, extra_funs(4,4,'Checked',3,[2,4]); end   
      end   
      shw_matrix;      
      %if length(arg1)==0, shw_matrix;
      %elseif nargin==2, shw_matrix(arg1); 
      %elseif nargin==3, shw_matrix(arg1, arg2); end
   case {11,12,13,14}, con_obsv(nTask);   
   end      
else
   key=0; h_win=findobj('Tag','MatxProcMain');
   if length(h_win)==0
      %open a new window for matrix processor
      h_win = figure('Units','normalized','Position',[0.12375 0.248 0.5 0.417],...
         'MenuBar','none','Color',0.8*[1,1,1],'Tag','MatxProcMain','Resize','off', ...
         'NumberTitle','off','Name','Matrix Processor');
      %define the uicontrols on the window
      [hControls,hh]=matx_controls; key=1;
   else
      %if it is exist, then bring it to front
      figure(h_win); uu=get(h_win,'UserData'); uu{1}{1}=A;
      set(h_win,'UserData',uu);
   end
   %program initialization, with menu, controls setting
   A1=matx_init(A,h_win);
   if key==1, matx_menu(A1,hControls); matx_toolbar; end
   sys_disp(A1); %display current system  
end

%---------------------------------------------------------------------------------
%matx_controls is used to create all the control objects on the matrix processor's
%main window.
%---------------------------------------------------------------------------------
function [hControls,hh]=matx_controls()

%define a group of filled frames to hide some unwanted parts of the matrix 
hh(1)=uicontrol('Style','Frame',...%right
   'Units','normalized','Position',[0.7501,0.0001,0.2498,0.9998],...
   'ForegroundColor',0.8*[1,1,1],'BackgroundColor',0.8*[1,1,1]);
hh(2)=uicontrol('Style','Frame',...%bottom
   'Units','normalized','Position',[0.0001,0.0001,0.9998,0.0698],...
   'ForegroundColor',0.8*[1,1,1],'BackgroundColor',0.8*[1,1,1]);
hh(3)=uicontrol('Style','Frame',...%left
   'Units','normalized','Position',[0.0001,0.0001,0.0499,0.9998],...
   'ForegroundColor',0.8*[1,1,1],'BackgroundColor',0.8*[1,1,1]);
hh(4)=uicontrol('Style','Frame',...%top
   'Units','normalized','Position',[0.0001,0.8961,0.9998,0.1038],...
   'ForegroundColor',0.8*[1,1,1],'BackgroundColor',0.8*[1,1,1]);

%define the push buttons on the dialog box
hControls(1)=uicontrol('Style','PushButton','String','Real Part',...
   'Units','normalized','Position',[0.80,0.87,0.17,0.08], ...
   'Enable','off','CallBack','matx_proc(8,1);');
hControls(2)=uicontrol('Style','PushButton','String','Imag Part',...
   'Units','normalized','Position',[0.80,0.76,0.17,0.08],...
   'Enable','off','CallBack','matx_proc(8,2);');
hControls(3)=uicontrol('Style','PushButton','String','Matrix U',...
   'Units','normalized','Position',[0.80,0.62,0.17,0.08],...
   'Visible','off','CallBack','matx_proc(8,3);');
hControls(4)=uicontrol('Style','PushButton','String','Matrix G',...
   'Units','normalized','Position',[0.80,0.51,0.17,0.08],...
   'Visible','off','CallBack','matx_proc(8,4);');
hControls(5)=uicontrol('Style','PushButton','String','Matrix V',...
   'Units','normalized','Position',[0.80,0.40,0.17,0.08],...
   'Visible','off','CallBack','matx_proc(8,5);');
hControls(6)=uicontrol('Style','Slider',...
   'Units','normalized','Position',[0.05,0.02,0.7,0.049],...
   'Visible','off','CallBack','extra_funs(8,1);');
hControls(7)=uicontrol('Style','Slider',...
   'Units','normalized','Position',[0.751,0.07,0.033,0.85],...
   'Visible','off','CallBack','extra_funs(8,2);');

%define a set of uicontrols for matrix editting.  
hControls(9)=uicontrol('Style','Edit','String','','Visible','off',...
   'Units','normalized','Position',[0.30,0.88,0.20,0.08],...
   'ForegroundColor',[0,0,0],'BackgroundColor',[1,1,1],...
   'HorizontalAlignment','left','CallBack','matx_proc(3,1);');
%hControls(8) and (10) are no longer used.
hControls(11)=uicontrol('Style','PushButton','String','Refresh',...
   'Units','normalized','Position',[0.80,0.16,0.17,0.08],...
   'Visible','off','CallBack','matx_proc(6,1,1);');
hControls(12)=uicontrol('Style','PushButton','String','Exit',...
   'Units','normalized','Position',[0.80,0.05,0.17,0.08],...
   'CallBack','matx_proc(0,5);');

%set invisible axis 
frame_setting(hControls);

%----------------------------------------------------------------------------------
%matx_menu is used to create the menu system on the matrix processor's main window.
%----------------------------------------------------------------------------------
function matx_menu(A,hControls)

%define the File menu
hMMatFile(1)=uimenu(gcf,'Label','&File');
hMMatFile(2)=uimenu(hMMatFile(1),'Label','&New Matrix...','CallBack','matx_proc(0,1);');
hMMatFile(3)=uimenu(hMMatFile(1),'Label','&Open ...','CallBack','matx_proc(0,2);');
hMMatFile(4)=uimenu(hMMatFile(1),'Label','&Save','CallBack','matx_proc(0,3);');
hMMatFile(5)=uimenu(hMMatFile(1),'Label','Save &As ...','CallBack','matx_proc(0,4);');
hMMatFile(8)=uimenu(hMMatFile(1),'Label','E&xit','Separator','on','CallBack','matx_proc(0,5);');

%define the Edit menu
hMMatEdit(1)=uimenu(gcf,'Label','&Edit');
hMMatEdit(2)=uimenu(hMMatEdit(1),'Label','&Edit an Element','CallBack','matx_proc(2,1);');
hMMatEdit(3)=uimenu(hMMatEdit(1),'Label','Show in MATLAB Format ...',...
   'Separator','on','CallBack','matx_proc(1,2);');
hMMatEdit(4)=uimenu(hMMatEdit(1),'Label','Show in &TeX Format ...','CallBack','matx_proc(1,1);');
hMMatEdit(5)=uimenu(hMMatEdit(1),'Label','Show System Model','Separator','on','CallBack','matx_proc(4,[]);');

%define the matrix display Format menu
hMMat(1)=uimenu(gcf,'Label','For&mats');
hMMat(2)=uimenu(hMMat(1),'Label','&High Precision','Checked','off','CallBack','matx_proc(10,1);');
hMMat(3)=uimenu(hMMat(1),'Label','&Normal Precision','Checked','on','CallBack','matx_proc(10,2);');
hMMat(4)=uimenu(hMMat(1),'Label','&Rational Approximation','Checked','off','CallBack','matx_proc(10,3);');
hMMat(5)=uimenu(hMMat(1),'Label','&Left Justify','Checked','off','Separator','on','CallBack','matx_proc(10,4);');
hMMat(6)=uimenu(hMMat(1),'Label','&Center Justify','Checked','on','CallBack','matx_proc(10,5);');
hMMat(7)=uimenu(hMMat(1),'Label','&Right Justify','Checked','off','CallBack','matx_proc(10,6);');
hMMat(9)=uimenu(hMMat(1),'Label','&Zero Truncate','Separator','on');
hMMat(10)=uimenu(hMMat(9),'Label','No Truncate','Check','on','CallBack','matx_proc(10,7);');
hMMat(11)=uimenu(hMMat(9),'Label','10^{-14}','Check','off','CallBack','matx_proc(10,8);');
hMMat(12)=uimenu(hMMat(9),'Label','10^{-15}','Check','off','CallBack','matx_proc(10,9);');
hMMat(13)=uimenu(hMMat(9),'Label','10^{-16}','Check','off','CallBack','matx_proc(10,10);');
hMMat(8)=uimenu(hMMat(1),'Label','&Defaults','CallBack','matx_proc(10,11);');

%define the matrix Analyser menu
hMMatProp(1)=uimenu(gcf,'Label','&Analysis');
hMMatProp(2)=uimenu(hMMatProp(1),'Label','&Matrix Parameters');
hMMatProp(3)=uimenu(hMMatProp(2),'Label','&Determinant','CallBack','matx_proc(5,1);');
hMMatProp(4)=uimenu(hMMatProp(2),'Label','&Rank','CallBack','matx_proc(5,2);');
hMMatProp(5)=uimenu(hMMatProp(2),'Label','&Trace','CallBack','matx_proc(5,3);');
hMMatProp(6)=uimenu(hMMatProp(2),'Label','&Eigenvalues','CallBack','matx_proc(5,4);');
hMMatProp(7)=uimenu(hMMatProp(2),'Label','&Singular Values','CallBack','matx_proc(5,5);');
hMMatProp(8)=uimenu(hMMatProp(2),'Label','&Condition Number','CallBack','matx_proc(5,6);');
hMMatProp(9)=uimenu(hMMatProp(2),'Label','&Norm');
hMMatProp(10)=uimenu(hMMatProp(9),'Label','&1-Norm','CallBack','matx_proc(5,7);');
hMMatProp(11)=uimenu(hMMatProp(9),'Label','&2-Norm','CallBack','matx_proc(5,8);');
hMMatProp(12)=uimenu(hMMatProp(9),'Label','&Infinity-Norm','CallBack','matx_proc(5,9);');
hMMatProp(13)=uimenu(hMMatProp(9),'Label','&Frobinius-Norm','CallBack','matx_proc(5,10);');
hMMatProp(14)=uimenu(hMMatProp(9),'Label','&Norms','CallBack','matx_proc(5,12)');
hMMatProp(15)=uimenu(hMMatProp(2),'Label','&Characteristic Polynomial','CallBack','matx_proc(5,11);');
hMMatProp(16)=uimenu(hMMatProp(2),'Label','&Matrix Parameters','CallBack','matx_proc(5,13)');
hMMatProp(17)=uimenu(hMMatProp(1),'Label','&Manipulations');
hMMatProp(18)=uimenu(hMMatProp(17),'Label','&Matrix A','CallBack','matx_proc(9,1);');
hMMatProp(19)=uimenu(hMMatProp(17),'Label','&Transpose','CallBack','matx_proc(9,2);');
hMMatProp(20)=uimenu(hMMatProp(17),'Label','&Inverse','CallBack','matx_proc(9,3);');
hMMatProp(21)=uimenu(hMMatProp(17),'Label','Flip &Horizontal','CallBack','matx_proc(9,4);');
hMMatProp(22)=uimenu(hMMatProp(17),'Label','Flip &Vertical','CallBack','matx_proc(9,5);');
hMMatProp(23)=uimenu(hMMatProp(17),'Label','&Rotate 90 Degree','CallBack','matx_proc(9,6);');
hMMatProp(24)=uimenu(hMMatProp(17),'Label','&Orthonormal Basis',...
   'Separator','on','CallBack','matx_proc(9,12);');
hMMatProp(25)=uimenu(hMMatProp(17),'Label','&Null Space','CallBack','matx_proc(9,13);');

hMMatProp(26)=uimenu(hMMatProp(1),'Label','&Decomposition');
hMMatProp(27)=uimenu(hMMatProp(26),'Label','&LU Decomposition','CallBack','matx_proc(7,1,1);');
hMMatProp(28)=uimenu(hMMatProp(26),'Label','&SVD Decomposition','CallBack','matx_proc(7,2,1);');
hMMatProp(29)=uimenu(hMMatProp(26),'Label','S&chur Decomposition','CallBack','matx_proc(7,3,1);');
hMMatProp(30)=uimenu(hMMatProp(26),'Label','&QR Decomposition','CallBack','matx_proc(7,4,1);');
hMMatProp(31)=uimenu(hMMatProp(26),'Label','&Hess Form','CallBack','matx_proc(7,5,1);');
hMMatProp(32)=uimenu(hMMatProp(26),'Label','&Balance Form','CallBack','matx_proc(7,6,1);');

hMMatProp(33)=uimenu(hMMatProp(1),'Label','Matrix &Evaluation');
hMMatProp(34)=uimenu(hMMatProp(33),'Label','&Exp(A)','CallBack','matx_proc(9,7);');
hMMatProp(35)=uimenu(hMMatProp(33),'Label','&Sin(A)','CallBack','matx_proc(9,8);');
hMMatProp(36)=uimenu(hMMatProp(33),'Label','&Cos(A)','CallBack','matx_proc(9,9);');
hMMatProp(37)=uimenu(hMMatProp(33),'Label','&Log(A)','CallBack','matx_proc(9,10);');
hMMatProp(38)=uimenu(hMMatProp(33),'Label','&Sqrt(A)','CallBack','matx_proc(9,11);');

if isa(A,'double')
   hMSSProp=[];
else
   hMSSProp(1)=uimenu(gcf,'Label','&StateSpace');
   hMSSProp(2)=uimenu(hMSSProp(1),'Label','&Controllability','CallBack','matx_proc(11,[]);');
   hMSSProp(3)=uimenu(hMSSProp(1),'Label','&Observability','CallBack','matx_proc(12,[]);');
   hMSSProp(4)=uimenu(hMSSProp(1),'Label','&Stabilizability','CallBack','matx_proc(13,[]);');
   hMSSProp(5)=uimenu(hMSSProp(1),'Label','&Detectability','CallBack','matx_proc(14,[]);');
end

%define the Help menu
hMMatHelp(1)=uimenu(gcf,'Label','&Help');
hMMatHelp(2)=uimenu(hMMatHelp(1),'Label','&Introduction to Matx_Proc','CallBack','clab_help(22);');
hMMatHelp(3)=uimenu(hMMatHelp(1),'Label','&About ...','Separator','on','CallBack','clab_help(24);');

uu={{A,A},hMMatFile,hMMatEdit,hMMat,hMMatProp,hMSSProp,hMMatHelp,hControls};
uu{10}={0,''}; set(gcf,'UserData',uu);

%-----------------------------------------------------------------------------
%matx_toolbar used to create a toolbar for Matrix Processor and it is now only
%working for mATLAB 5.2 and higher.
%-----------------------------------------------------------------------------
function matx_toolbar()
[v,d]=version; v1=eval(v(1)); v2=eval(v(3));
if v1>=5 & v2>=2, 
   yy=get(gcf,'Position'); screen=get(0,'ScreenSize'); ymax=yy(4)*screen(4)-20;
   load ctrllab_cdata; load matx_cdata; load graf_cdata;
   uicontrol('Style','PushButton','Units','pixels','Position',[5,ymax,20,20],...
      'CData',fnew_dat,'CallBack','matx_proc(0,1);','TooltipString','Create New Matrix','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[25,ymax,20,20],...
      'CData',fopen_dat,'CallBack','matx_proc(0,2);','TooltipString','Load Matrix','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[45,ymax,20,20],...
      'CData',fsave_dat,'CallBack','matx_proc(0,3);','TooltipString','Save Matrix','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[70,ymax,20,20],...
      'CData',tex_dat,'CallBack','matx_proc(1,1);','TooltipString','TeX Output','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[90,ymax,20,20],...
      'CData',mat_dat,'CallBack','matx_proc(1,2);','TooltipString','MATLAB Output','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[110,ymax,20,20],...
      'CData',edit_dat,'CallBack','matx_proc(2,1);','TooltipString','Edit Elements','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[135,ymax,20,20],...
      'CData',left_dat,'CallBack','matx_proc(10,4);','TooltipString','Left Align','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[155,ymax,20,20],...
      'CData',centre_dat,'CallBack','matx_proc(10,5);','TooltipString','Centre Align','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[175,ymax,20,20],...
      'CData',right_dat,'CallBack','matx_proc(10,6);','TooltipString','Right Align','Tag','Tools');
   uicontrol('Style','ToggleButton','Units','pixels','Position',[195,ymax,20,20],...
      'CData',rat_dat,'CallBack','matx_proc(10,12);','TooltipString','Rational Display','Tag','Tools');
   uicontrol('Style','PushButton','Units','pixels','Position',[220,ymax,20,20],...
      'CData',help_dat,'CallBack','clab_help(24);','TooltipString','About Matrix Processor','Tag','Tools');
end

%-------------------------------------------------------------
%matx_init used to initialize the matrix processing interface.
%-------------------------------------------------------------
function A_new=matx_init(A,h_win)

A_new=A;
if isa(A,'double')
   if length(A)==0, 
      h_main=findobj('Tag','CtrlLABMain');
      if length(h_main)>0
         %if it is part of CtrlLAB, then load system model
         u0=get(h_main,'UserData'); u0=get(u0{1}(1),'UserData');
         uu=get(h_win,'UserData'); 
         A_new=ss(u0{2}); uu{1}{1}=A_new;
      else
         %if it is an independent program, then initialize it
         A_new=[]; uu{1}{1}=A_new;
      end   
      set(h_win,'UserData',uu);
   end
end   

%-----------------------------------------------------------------------------
%disp_matrix is used to display a matrix in either TeX or MATLAB format in the 
%Information Display Window or in GUI
%
%   disp_matrix(key,arg1)
%if there is only 1 input argument, then it is 1 for TeX format, 2 for MATLAB 
%format.  If there are two input arguments, then it is displayed in the GUI.
%-----------------------------------------------------------------------------
function disp_matrix(key,arg1)
if nargin==1,
   uu=get(gcf,'UserData'); A=uu{1}{2};
   if ~isa(A,'double'), A=A.a; end
   [nrec,keyJus,err]=matdisp_pars;
   display_str; uu=get(gcf,'UserData'); [nr,nc]=size(A);
   if key==1, strMat='\left[\matrix{'; else, strMat='['; end
   for i=1:nr
      strMat1='   '; 
      for j=1:nc
         if key==1,
            strMat1=[strMat1,display_str(A(i,j),nrec,err)]; 
            if j<nc, strMat1=[strMat1,' & ']; end
         else
            %display the matrix in MATLAB strings
            ss1=display_str(A(i,j),nrec,err); ss1=ss1(find(ss1~='{' & ss1~='}'));
            n=findstr(ss1,'\times');
            if length(n)>0, ss2=ss1(n+9:end); ss1=ss1(1:n-1); end
            strMat1=[strMat1, ss1];
            if length(n)>0, strMat1=[strMat1,'e' ss2]; end
            if j<nc, strMat1=[strMat1,', ']; end
         end
      end
      if i<nr&key==1, strMat1=[strMat1 ' \cr']; end
      strMat=str2mat(strMat,strMat1);
   end
   if key==1, strMat=str2mat(strMat,'}\right]'); 
   else, strMat=str2mat(strMat,']'); end
   %set the display box on the Information Window visible
   set(uu(4),'Visible','on','Max',nr+2,'String',strMat);

else
   h_matmain=findobj('Tag','MatxProcMain');
   uu=get(h_matmain,'UserData'); A=uu{1}{1};  if isa(A,'ss'), A=A.a; end
   if ~issquare(A)& any(7:11==key) ;
      warndlg('Warning: Function of Non-square matrix cannot be evaluated!','Warning: Non-square matrix given!');
      return;   
   end

   switch key
   case 1, tmpA=A; strMatTitle='A'; %display matrix A
   case 2, tmpA=A'; strMatTitle='A^T'; %display the transpose of A
   case 3, %display the inverse matrix of A
      k_inv=0; 
      if ~issquare(A), k_inv=1; 
      elseif rank(A)<length(A), k_inv=1; end
      if k_inv==0, tmpA=inv(A); strMatTitle='A^{-1}';
      else, tmpA=pinv(A); strMatTitle='Pseudo Inverse A^+'; end   
   case 4, tmpA=fliplr(A); strMatTitle='FlipLr(A)'; %display the matrix flipped lift-right
   case 5, tmpA=flipud(A); strMatTitle='FlipUd(A)'; %display the matrix flipped up-down
   case 6, tmpA=rot90(A); strMatTitle='Rotate90(A)'; %display the matrix rotated by 90 degrees
   case 7, tmpA=mat_funs(A,1); strMatTitle='e^A'; %display the exponential matrix of A
   case 8, tmpA=mat_funs(A,2); strMatTitle='sin(A)'; %display the sine matrix of A 
   case 9, tmpA=mat_funs(A,3); strMatTitle='cos(A)'; %display the cosine matrix of A
   case 10, tmpA=funm(A,'log10'); strMatTitle='Log(A)'; %display the logarithmic matrix of A
   case 11, tmpA=sqrtm(A); strMatTitle='Sqrt(A)'; %display the square root matrix of A
   case 12, tmpA=orth(A); strMatTitle='Orthonormal Basis of A'; %display the orthonormal base of matrix A 
   case 13, %display the null space of matrix A
      tmpA=null(A);
      if length(A)==0, display_str; display_str(0.1,0.5,'Matrix A is Singular');
      else, strMatTitle='Null space of A'; end
   end
   uu{1}{2}=tmpA; set(h_matmain,'UserData',uu);
   shw_matrix(0,tmpA,0.05,0.75,strMatTitle);
end

%-----------------------------------------------------------------------
%matx_edit allows the user to edit the matrix elements in the interface.
%-----------------------------------------------------------------------
function matx_edit()
sys_disp;

uu=get(gcf,'UserData'); hA=uu{9}; hControls=uu{8};
key1=0;
if iscell(hA), hB=hA{2}; hC=hA{3}; hD=hA{4}; hA=hA{1}; key1=1; end

[nr,nc]=size(hA);
if key1==1, hA=[reshape(hA,1,prod(size(hA))),hB,hC,hD];
else, hA=reshape(hA,1,prod(size(hA))); end

while 1, %check whether the selected objects a handle of the matrix/state space model element
   [x,y,button]=ginput(1); key=0;
   if button~=1, break; 
   else   
      for i=1:length(hA), if (gco==hA(i)), key=1; break; end, end
   end
   if key==1, break; end
end   

if key==1,
   %if it is an element, then set the Edit mode
%   set(hControls(10),'UserData',hA(i)); 
   xx=get(hControls(9),'Position'); xx(1:2)=get(gcf,'CurrentPoint'); 
   set(hControls([9,11]),'Visible','on');
   set(hControls(9),'Position',xx,'String',flt_replace(get(hA(i),'String')),'UserData',hA(i)); 
   if key1==0, uu{10}{1}=1; set(gcf,'UserData',uu); end   
end

%-------------------------------------------------------------
%matx_update update the current matrix 
%-------------------------------------------------------------
function matx_update()

hA1=get(gco,'UserData'); uu=get(gcf,'UserData'); hControls=uu{8};
h_obj=get(hControls(9),'UserData'); set(hA1,'String',get(hControls(9),'String'));
set(hControls(9),'Visible','off');

hA=uu{9}; key=0; g_sys=uu{1}{1};
if iscell(hA), 
   A=g_sys.a; B=g_sys.b; C=g_sys.c; D=g_sys.d;
   key=1; hB=hA{2}; hC=hA{3}; hD=hA{4}; hA=hA{1};%key=1 for state space model
else, A=g_sys; end

[nr,nc]=size(hA);

for i=1:nr
   for j=1:nc, 
      if hA(i,j)==h_obj, A(i,j)=eval(get(hA(i,j),'String')); end
   end
   if key==1
      if hB(i)==h_obj, B(i,1)=eval(get(hB(i),'String')); end
      if hC(i)==h_obj, C(1,i)=eval(get(hC(i),'String')); end
end, end
if key==1, 
   if hD==h_obj, D=eval(get(hD,'String')); end 
   uu{1}{1}=ss(A,B,C,D); uu{1}{2}=uu{1}{1};
else, uu{1}={A,A}; end

set(gcf,'UserData',uu);

if key==1
   if ~isa(uu{1}{1},'double')
      %update the system plant model in CtrlLAB
      uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
      g_sys=uu{1}{1};
      a_str=mat2str(g_sys.a); b_str=mat2str(g_sys.b);
      c_str=mat2str(g_sys.c); d_str=mat2str(g_sys.d);
      set(uu0{1}(1),'UserData',{2,uu{1}{1},a_str,b_str,c_str,d_str});
   end   
end

%-------------------------------------------------------------
%matdisp_pars obtains the display format
%
%   [nrec,njust,err]=matdisp_pars()
%where 
%  nrec -- the number of digit to display
%  njust -- the justification of display
%  err -- the zero truncation format.  err=0 for rational
%-------------------------------------------------------------
function [nrec,njust,err]=matdisp_pars();

aa=extra_funs(5,4,'Checked',2:4);
switch aa
case 1, nrec=8; 
case 2, nrec=4;
case 3, nrec=0;
end
njust=extra_funs(5,4,'Checked',5:7); aa=extra_funs(5,4,'Checked',10:13);
switch aa
case 1, err=0; 
case 2, err=1e-14;
case 3, err=1e-15;
case 4, err=1e-16;
end

%-------------------------------------------------------------
%shw_matpars shows the properties of the given matrix
%-------------------------------------------------------------
function shw_matpars(key)

switch key
case {1,2,3,6,7,8,9,10,11}, matx_pars(key,0.1,0.6);
case {4,5}, [xL,A]=matx_pars(key,0.1,0.6);
case 12
   xL=0.07; yL=0.45; [xL,A]=matx_pars(7,xL,yL);
   xL=xL+0.05; xL=matx_pars(8,xL,yL,A); xL=xL+0.05; xL=matx_pars(9,xL,yL,A);
   xL=matx_pars(10,xL,yL,A);    
case 13
   uu=get(gcf,'UserData'); A=uu{1}{1};
   if isa(A,'ss'), A=A.a; end   
   keyy=issquare(A);
   xL0=0.03; yL=0.63; [xL0,A]=matx_pars(5,xL0,yL);
   xL3=0.03; yL=0.92; if keyy, xL3=matx_pars(4,xL3,yL,A); end
   xL1=0.03; yL=0.35; if keyy, xL1=matx_pars(1,xL1,yL,A); end
   xL1=xL1+0.05; xL1=matx_pars(3,xL1,yL,A);
   xL1=xL1+0.05; xL1=matx_pars(6,xL1,yL,A);
   xL1=xL1+0.05; xL1=matx_pars(2,xL1,yL,A);
   xL2=0.03; yL=0.17; xL2=matx_pars(7,xL2,yL,A);
   xL2=xL2+0.05; xL2=matx_pars(8,xL2,yL,A);
   xL2=xL2+0.05; xL2=matx_pars(9,xL2,yL,A);
   xL2=xL2+0.05; xL2=matx_pars(10,xL2,yL,A);
   if ~keyy, 
      warndlg('Warning: some of the parameters not analyzable!','Warning: Non-square matrix given!');
   end   
end

%-------------------------------------------------------------
%matx_pars evaluates parameters of a given matrix
%-------------------------------------------------------------
function [xL,A]=matx_pars(key,xL,yL,A)

if nargin==3, 
   uu=get(gcf,'UserData'); A=uu{1}{1};
   if isa(A,'ss'), A=A.a; end   
end

if nargout~=1, display_str; end

%check whether the matrix is a square one for some analysis
if any([1,4,11]==key), 
   if ~issquare(A), 
      warndlg('Parameters cannot be evaluated!','Warning: Non-square matrix given!');
      return;
   end   
end

switch key
case {1,3,6}
   switch key
   case 1, atmp=det(A); str1='det(A)=';
   case 3, atmp=trace(A); str1='tr(A)=';
   case 6, atmp=cond(A); str1='cond(A)=';
   end
   xL=display_str(xL,yL,[str1,display_str(atmp)]);
case 2, xL=display_str(xL,yL,['rank(A)=' int2str(rank(A))]);
case {4,5}
   switch key
   case 4, atmp=eig(A); str1='Eigenvalues of Matrix';
   case 5, atmp=svd(A); str1='Singular Values of Matrix';
   end
   display_str(xL,yL,str1);
   xL=display_str(xL+0.05,yL-0.14,atmp,0);
case {7,8,9,10}
   switch key
   case 7, atmp=norm(A,1); str1='1';
   case 8, atmp=norm(A,2); str1='2';
   case 9, atmp=norm(A,Inf); str1='\infty';
   case 10, atmp=norm(A,'fro'); str1='F';
   end
   xL=display_str(xL,yL,['||A||_',str1 '=' display_str(atmp)]);
case 11
   display_str(xL,yL,'Characteristic Polynomial of Matrix');
   xL=display_str(xL+0.05,yL-0.18,display_str(poly(A)));
end

%-------------------------------------------------------------
%sys_disp displays the system state space format in the window
%-------------------------------------------------------------
function sys_disp(g_sys)

h_matmain=findobj('Tag','MatxProcMain'); uu=get(h_matmain,'UserData'); 
if nargin==0, g_sys=uu{1}{1}; end

hControls=uu{8}; frame_setting(hControls);

if ~isa(g_sys,'double')
   if ~isa(g_sys,'ss'), g_sys=ss(g_sys); end
   xL=0.05; yL=0.85; [xL_a,yL,hA]=shw_matrix(0,g_sys.a,xL,yL,'A matrix');
   vec=get(h_matmain,'Position'); YSpace=0.0417/vec(4); yL=yL-YSpace;
   [xL_b,yL,hB]=shw_matrix(0,g_sys.b',xL,yL,'B vector transpose'); yL=yL-YSpace;
   [xL_c,yL,hC]=shw_matrix(0,g_sys.c,xL,yL,'C vector'); yL=yL-YSpace;
   [xL_d,yL,hD]=shw_matrix(0,g_sys.d,xL,yL,'D constant');
   uu{9}={hA,hB,hC,hD}; uu{1}{2}=g_sys.a; set(h_matmain,'UserData',uu); xL=max([xL_a,xL_b,xL_c]);   
   if xL>1, 
      set(hControls(6),'Visible','on','Min',0.5,'Max',xL-0.5,'Value',0.5); 
   else, set(hControls(6),'Visible','off'); end   
elseif ~isempty(g_sys), disp_matrix(1,[]); end   

%-----------------------------------------------------------------------------
%matx_file manipulates the File menu in the program
%
%   key=matx_file(nTask)
%where 
%  nTask=1 for New matrix creation
%        2 for Open
%        3, 4 for Save, Save As
%        5 for Exit
%the other values of nTask can be found in the comments of the function itself.
%------------------------------------------------------------------------------
function key=matx_file(nTask)
h_matmain=findobj('Tag','MatxProcMain'); uu=get(h_matmain,'UserData');
switch nTask
case 1
   h_win=findobj('Tag','MatxProcNew'); 
   if length(uu)>0
      A=uu{1}{1}; 
      if isa(uu{1}{1},'double'), [n,m]=size(A); else, [n,m]=size(A.a); end
   else, n=3; m=3; end
   if n*m==0, n=3; m=3; end
   if length(h_win)==0
      h_win=figure('Units','normalized','Position',[0.22125 0.232 0.425 0.3],...
         'MenuBar','none','Color',0.8*[1,1,1],'Interruptible','on','Tag','MatxProcNew',...
         'NumberTitle','off','Name','New Matrix Initialisation','Resize','off');
      extra_funs(1);
      hh(1)=uicontrol('Style','PushButton','String','Create',...
         'Units','normalized','Position',[0.80,0.80,0.16,0.13],'CallBack','matx_proc(0,7);');
      hh(2)=uicontrol('Style','PushButton','String','Cancel',...
         'Units','normalized','Position',[0.80,0.65,0.16,0.13],'CallBack','close(gcf);');
      hh(8)=uicontrol('Style','PushButton','String','Help',...
         'Units','normalized','Position',[0.80,0.50,0.16,0.13],'CallBack','clab_help(28);');
      [x,hh(11)]=display_str(0.05,0.66,'Number of Rows',[0,0,0],'on',9);
      hh(3)=uicontrol('Style','Edit','String',int2str(n),...
         'Units','normalized','Position',[0.32,0.59,0.10,0.10],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      [x,hh(12)]=display_str(0.45,0.66,'Columns',[0,0,0],'on',9);
      hh(4)=uicontrol('Style','Edit','String',int2str(m),...
         'Units','normalized','Position',[0.60,0.59,0.10,0.10],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      display_str(0.05,0.53,'Initial Form',[0,0,0],'on',9);
      str=str2mat('Zero matrix','Identity matrix','Hilbert matrix',...
         'Magic matrix','Random matrix','Diagonal matrix',...
         'Companion matrix','Hankel matrix','Vandermonde matrix');
      hh(5)=uicontrol('Style','Popupmenu','String',str,...
         'Units','normalized','Position',[0.10,0.36,0.35,0.10],...
         'BackgroundColor',[1,1,1],'Value',1,'CallBack','matx_proc(0,6);');
      [x,hh(6)]=display_str(0.05,0.23,'Known Vector',[0,0,0],'off',9);
      hh(7)=uicontrol('Style','Edit','String','[1,1,1]','Visible','off',...
         'Units','normalized','Position',[0.10,0.08,0.8,0.10],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      hh(9)=1; 
      [x,hh(13)]=display_str(0.05,0.92,'Enter Entire Matrix Here',[0,0,0],'on',9);
      hh(14)=uicontrol('Style','Edit','String','[]',...
         'Units','normalized','Position',[0.10,0.75,0.65,0.11],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1],'Visible','on');
      set(gcf,'UserData',hh);
   else, figure(h_win); end
case 2
   if nargout==1, key=0; end
   [filename,filepath]=uigetfile('*.mtx','Please Specify the File Name');
   if ~isa(filename,'double')
      if nargout==1, key=1; end
      str=[filepath,filename]; uu{10}={0,str}; eval(['load(str, ''-mat'');']);
      uu{1}{1}=A; uu{1}{2}=A; set(gcf,'UserData',uu); shw_matrix;
   end   
case 3
   if nargout==1, key=0; end
   if length(uu{10}{2})>=10
      str=uu{10}{2}; A=uu{1}{1}; eval(['save(str,''A'')']);
      uu{10}{1}=0; set(gcf,'UserData',uu);
   else, 
      k_tmp=matx_file(4); 
      if nargin==1, key=k_tmp; end
   end   
case 4
   key=0;
   [filename,filepath]=uiputfile('*.mtx','Please Specify the File Name');
   if ~isa(filename,'double')
      str=[filepath,filename]; uu{10}{2}=str; set(gcf,'UserData',uu); matx_file(3); key=1;
   end   
case 5
   if uu{10}{1}==1
      ButtonName=questdlg('The matrix has not been save.  Save it?', ...
         'Quit Matx_Proc Confirm','Yes','No','Cancel','Cancel');
      switch ButtonName,
      case 'Yes', matx_file(9);
      case 'No',  matx_file(8);
      end % switch
   else, matx_file(8); end      
case 6
   h_win=findobj('Tag','MatxProcNew');
   hh=get(h_win,'UserData'); hh(9)=get(hh(5),'Value');
   if any([3,4]==hh(9)),
      extra_funs(4,[],'Visible',hh([3,11]),hh([4,12,6,7]))
   elseif hh(9)<=5,
      extra_funs(4,[],'Visible',hh([3,4,11,12]),hh([6,7]))
   else,
      extra_funs(4,[],'Visible',hh([6,7]),hh([3,4,11,12]))
   end
   set(h_win,'UserData',hh);
case 7
   h_win=findobj('Tag','MatxProcNew'); key=0; 
   hh=get(h_win,'UserData'); strMat=get(hh(14),'String');
   if length(strMat)>2, A=eval(strMat);
   else   
      kMatForm=hh(9);
      if kMatForm<=5
         n=eval(get(hh(3),'String'));
         if ~any([3,4]==kMatForm), m=eval(get(hh(4),'String')); end
         switch kMatForm
         case 1, A=zeros(n,m);
         case 2, A=eye(n,m);
         case 3, A=hilb(n);
         case 4, A=magic(n);
         case 5, A=rand(n,m); 
         end
      else
         vecA=eval(get(hh(7),'String'));
         switch kMatForm
         case 6, A=diag(vecA);
         case 7, A=compan([1,vecA]);
         case 8, A=hankel(vecA);
         case 9, A=vander(vecA); 
         end
      end
   end   
   close(h_win); figure(h_matmain); uu=get(gcf,'UserData');
   uu{1}{1}=A; uu{1}{2}=A; uu{10}{1}=1; set(h_matmain,'UserData',uu); shw_matrix;
case 8
   close(h_matmain); close(findobj('Tag','MatxProcNew')); close(findobj('Tag','MatxProcExtras'));   
case 9
   key0=matx_file(3);
   if key0==1, close(h_matmain); close(findobj('Tag','MatxProcNew')); end   
   close(findobj('Tag','MatxProcExtras'));   
end      

%----------------------------------------------------
%mat_decomp perform matrix decomposition
%----------------------------------------------------
function matx_decomp(nTask)

uu=get(gcf,'UserData'); A=uu{1}{1}; hControls=uu{8}; 
if nargin==0, nTask=1; end
if isa(A,'ss'), A=A.a; end   

if ~issquare(A)& any([1,3,4,5,6]==nTask) ;
   warndlg('Warning: Non-Square matrix cannot be decomposited!','Warning: Non-square matrix given!');
   return;   
end

switch nTask
case 1, %LU decomposition
   [A1,A2]=lu(A); extra_funs(4,8,'Visible',[3:4],5); 
   u_dat={A1,'L matrix in LU decomposition, A=LU'};
   set(hControls(3),'UserData',u_dat,'String','Matrix L');
   u_dat={A2,'U matrix in LU decomposition, A=LU'};
   set(hControls(4),'UserData',u_dat,'String','Matrix U');
case 2, %Singular Value Decompistion (SVD)
   [A1,A2,A3]=svd(A); set(hControls(3:5),'Visible','on'); 
   u_dat={A1,'U matrix in SVD decomposition, A=UGV'};
   set(hControls(3),'UserData',u_dat,'String','Matrix U');
   u_dat={A2,'G matrix in SVD decomposition, A=UGV'};
   set(hControls(4),'UserData',u_dat,'String','Matrix G');
   u_dat={A3,'V matrix in SVD decomposition, A=UGV'};
   set(hControls(5),'UserData',u_dat,'String','Matrix V');
case 3, %Schur decompistion
   [A1,A2]=schur(A); extra_funs(4,8,'Visible',[3:4],5); 
   u_dat={A2,'T matrix in Schur decomposition, A=UTU^T'};
   set(hControls(4),'UserData',u_dat,'String','Matrix T');
   u_dat={A1,'U matrix in Schur decomposition, A=UTU^T'};
   set(hControls(3),'UserData',u_dat,'String','Matrix U');
case 4, %QR decompistion
   [A1,A2]=qr(A); extra_funs(4,8,'Visible',[3:4],5);  
   u_dat={A1,'Q matrix in QR decomposition, A=Q R'};
   set(hControls(3),'UserData',u_dat,'String','Matrix Q');
   u_dat={A2,'R matrix in QR decomposition, A=Q R'};
   set(hControls(4),'UserData',u_dat,'String','Matrix R');
case 5, %Hess decomposition
   [A1,A2]=hess(A); extra_funs(4,8,'Visible',[3:4],5);
   u_dat={A1,'P matrix in Hess decomposition, A=PHP^T'};
   set(hControls(3),'UserData',u_dat,'String','Matrix P');
   u_dat={A2,'H matrix in Hess decomposition, A=PHP^T'};
   set(hControls(4),'UserData',u_dat,'String','Matrix H');
case 6, %Balanced decomposition
   [A1,A2]=balance(A); extra_funs(4,8,'Visible',[3:4],5);
   u_dat={A1,'T matrix in balanced decomposition, A=T^{-1}BT'};
   set(hControls(3),'UserData',u_dat,'String','Matrix T');
   u_dat={A2,'B matrix in balanced decomposition, A=T^{-1}BT'};
   set(hControls(4),'UserData',u_dat,'String','Matrix B');
otherwise
   set(hControls(3:5),'Visible','off'); 
end
shw_decmat(3);

%----------------------------------------------------
%shw_decmat displays a matrix in decomposition
%----------------------------------------------------
function shw_decmat(nTask)
uu0=get(gcf,'UserData'); uu=get(uu0{8}(nTask),'UserData'); A=uu{1}; 
shw_matrix(0,A,0.05,0.75,uu{2});
if nTask<=2, extra_funs(4,8,'Enable',1:2,3:5); 
else, extra_funs(4,8,'Enable',3:5,1:2); end

%---------------------------------------------
%shw_matrix displays the matrix
%---------------------------------------------
function [xL,yL,hA]=shw_matrix(nTask,A,xL,yL,strMatTitle)
h_matmain=findobj('Tag','MatxProcMain'); figure(h_matmain);
uu=get(gcf,'UserData'); hControls=uu{8}; hButRI=hControls(1:2); 
%set defaults parameters in matrix display
if nargin==0, nTask=1; strMatTitle='Matrix A'; end
if nargin<=1, xL=0.05; yL=0.75; A=uu{1}{2};
elseif nargin==2, A=get(gco,'UserData'); end
[nrec,keyJus,err]=matdisp_pars; [nr,nc]=size(A);
%make display truncation
ii=find(abs(imag(A'))<err);
for i=1:length(ii), ix=ceil(ii(i)/nc); iy=ii(i)-(ix-1)*nc; A(ix,iy)=real(A(ix,iy)); end
if nargin<=1 | nr>1, frame_setting(hControls); end
if isreal(A), set(hButRI,'Enable','off');
elseif length(A)>0
   set(hButRI(1),'Enable','on','UserData',{real(A),'Real part'});
   set(hButRI(2),'Enable','on','UserData',{imag(A),'Imag part'});
   strMatTitle='Real part'; A=real(A);
end
%set x- and y-axis displacement
vec=get(h_matmain,'Position'); XSpace=0.02/vec(3); YSpace=0.0417/vec(4); 
xL0=display_str(xL,yL+YSpace,strMatTitle,[1,0,0]); hA=zeros(size(A)); 
%display each element in the matrix
for i=1:nc
   for j=1:nr
      [xL1,hA(j,i)]=display_str(xL,yL-(j-1)*YSpace,display_str(A(j,i),nrec,err),[0,0,0],'off');
      xLEx1(j)=xL1-xL;
   end
   maxL=max(xLEx1);
   if keyJus==2, %center justified
      for j=1:nr, set(hA(j,i),'Position',[xL+(maxL-xLEx1(j))/2,yL-(j-1)*YSpace]); end
   elseif keyJus==3,  %right justified
      for j=1:nr, set(hA(j,i),'Position',[xL+maxL-xLEx1(j),yL-(j-1)*YSpace]); end
   end
   set(hA(:,i),'Visible','on'); xL=xL+maxL+XSpace;
end
yL=yL-YSpace*nr;
uu{9}=hA; uu{1}{2}=A; set(h_matmain,'UserData',uu);
%setting horizontal and vertical scroll bars if necessary
if xL>1, set(hControls(6),'Visible','on','Min',0.5,'Max',xL-0.5,'Value',0.5); 
else, set(hControls(6),'Visible','off'); end
if yL<0, set(hControls(7),'Visible','on','Min',yL+0.45,'Max',0.5,'Value',0.5);
else, set(hControls(7),'Visible','off'); end

%---------------------------------------------------
%mat_funs evaluates exp(A), sin(A), cos(A)
%---------------------------------------------------
function A_new=mat_funs(A,nTask)
A_new=zeros(size(A));
switch nTask
case 1, AA=A; F=eye(size(A)); ratio='1/(k+1)'; k=0; dk=1;%exp(A)
case 2, AA=-A^2; F=A; ratio='1/((k+2)*(k+1))'; k=1; dk=2;%sin(A)
case 3, AA=-A^2; F=eye(size(A)); ratio='1/((k+2)*(k+1))'; k=0; dk=2;%cos(A)
end
while norm(F+A_new-A_new,1)>0, A_new=A_new+F; F=AA*F*eval(ratio); k=k+dk; end

%-------------------------------------------------------
%frame_setting administrate the area for matrix display.
%-------------------------------------------------------
function frame_setting(hControls)
%set new axis
extra_funs(1,[0.05,0.07,0.70,0.83]);
%create a frame and save the handle to corresponding controls
hFrame=extra_funs(10,[0,0],[1,1]); 
set(hFrame,'Color',[0,0,1]); set(hControls(6:7),'UserData',hFrame);

%------------------------------------------------------------------------------------
%flt_replace changes the TeX representation of a float value to MATLAB representation
%------------------------------------------------------------------------------------
function str=flt_replace(str)
i=findstr(str,'\times'); if length(i)>0, str=[str(1:i-1), 'e',  str(i+10:end-1)]; end

%------------------------------------------------------------------------------------
%issquare detects whether a matrix given is square.  If not square, an warning dialog 
%box will be given.
%------------------------------------------------------------------------------------
function key=issquare(A)
key=size(A,1)==size(A,2);

%------------------------------------------------------------------------------------
%con_obsv detects a system given is controllable, observable, stabilizable and
%detectable.
%------------------------------------------------------------------------------------
function con_obsv(nTask)

h_win=findobj('Tag','MatxProcMain'); uu=get(h_win,'UserData'); G_Sys=uu{1}{1};
A=G_Sys.a; B=G_Sys.b; C=G_Sys.c; D=G_Sys.d; display_str;
switch nTask
case 11, %controllability judgement
   [a,b,c,t,k]=ctrbf(A,B,C); n=size(A,1); n_c=n-sum(k);
   if n_c==0
      display_str(0.1,0.7,'System is Full Controllable');
   else
      display_str(0.1,0.7,['There are ' int2str(n_c) ' Uncontrollable Modes']);
      A1=a(1:n_c,1:n_c); display_str(0.1,0.5,eig(A1),0)
   end   
case 12
   [a,b,c,t,k]=obsvf(A,B,C); n=size(A,1); n_c=n-sum(k);
   if n_c==0
      display_str(0.1,0.7,'System is Full Observable');
   else
      display_str(0.1,0.7,['There are ' int2str(n_c) ' Unobservable Modes']);
      A1=a(1:n_c,1:n_c); display_str(0.1,0.5,eig(A1),0)
   end   
case 13
   [V,ss]=stab_detc(A,B);
   if length(ss)==0,    
      display_str(0.1,0.7,'System is Full Controllable');
   else
      display_str(0.1,0.7,'System is not Full Stabilizable, with Unstabilizable Modes');
      display_str(0.1,0.5,ss,0)
   end
case 14
   [V,ss]=stab_detc(A,C); 
   if length(ss)==0,    
      display_str(0.1,0.7,'System is Full Detectable');
   else
      display_str(0.1,0.7,'System is not Full Detectable, with Undetectable Modes');
      display_str(0.1,0.5,ss,0)
   end
end   

%-----------------------------------------------------------------------
%[V,ss]=stab_detc(A,X) checks the stabilizability or detectability of a
%given system.  The syntax is the same as in the lecture note.
%-----------------------------------------------------------------------
function [V,ss]=stab_detc(A,X)
n=length(A); [nc,nr]=size(X); ss=[];
if nc==n & nr==1, A0=A; B0=X;
elseif nc==1 & nr==n, A0=A'; B0=X';
else, errordlg('uncompetible (A,B)'); V=[]; return; end
C=ctrb(A0,B0); nB=rank(C);
if nB==n, V=1; 
else
   [Ac,Bc,Cc]=ctrbf(A0,B0,ones(1,n)); 
   Anc=Ac(1:n-nB,1:n-nB); ee=eig(Anc);
   for i=1:length(ee)
      if real(ee(i))>=0, ss=[ss,ee(i)]; end
   end
   if length(ss)>0, V=0; else, V=1; end
end
