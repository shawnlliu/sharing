%mod_reduction is used to administrate the reduction of the plant model.
%
%   mod_reduction(nTask,arg1)
%
%If there is no input argument supplied, then reduced model comparison dialog box 
%will appear which allows the user to compare the behaviours of different reduced 
%models.
%
%If there is only one input argument supplied, then the parameters of the reduction 
%process should be entered, and it will chose properiate algorithm to do reduction.
%
%If there are two input arguments supplied, then 
%    
%   arg1=0 --- setting reduction parameters
%   arg1=1,2 --- perform reduction
%   arg1=3 --- compare reduction
%
%Available lists of functions under this module
%
%  do_reduction -- manipulate the model reduction procedures
%  pade_red -- implements the Pade approximation technique
%  routh_red -- implements the Routh approximation technique
%  dom_mod_red -- implements the dominent mode technique
%  ffpade_red -- implements the FF Pade approximation technique
%  bal_real_red -- implements the balanced rr\ealization technique
%  robust_red -- implements the robust reduction technique
%  opt_reduction -- implements the optimal reduction technique
%  tf_monic -- performs monic transformation to transfer functions
%  tf_revs -- write the TF polynomials in reversed order
%  cmp_reduction -- compare different reduced order models.
%  modcmp_win -- creates a dialog box for model comparison
%  modred_win -- creates a dialog box for reduction parameters
%  opt_func -- defines the optimal criterion for model reduction
%  r_intgl -- evaluate the H_2 norm using recursive algorithm
%  tf_derv -- obtain the first derivative of a TF
%  vec_plus -- adds two polynomials of different lengths
%

%Designed by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%This module is for CtrllAB 3.0, (c) 1996-1999
%Last modified 5 October, 1999
%-------------------------------------------------------------------------

function G_out=mod_reduction(nTask,arg1,arg2,arg3,arg4,arg5,arg6,arg7)

switch nargin
case 0, modcmp_win;
case 1, 
   g_main=findobj('Tag','CtrlLABMain');
   uu0=get(g_main,'UserData'); g1=get(uu0{1}(1),'UserData');
   if length(g1)>0, modred_win(nTask);
   else, 
      warndlg('Plant model dose not exist, please enter it first!','Model reduction failed'); 
   end   
case 2   
   switch arg1
   case 0, do_reduction;
   case 1
      uu=get(gcf,'UserData'); nTask=get(uu{1}(1),'Value');
      switch nTask
      case {1,3,4}, extra_funs(4,2,'Visible',1:4,5:10);
      case 6, extra_funs(4,2,'Visible',[1:4,7:10],5:6);
      otherwise, extra_funs(4,2,'Visible',5:6,[1:4,7:10]);   
      end
   case 2
      uu=get(gcf,'UserData'); nTask=get(uu{1}(1),'Value');
      switch get(uu{2}(10),'Value')
      case 1, avec(4:5)=[0,0];
      case 2, avec(4:5)=[0,1];
      case 3, avec(4:5)=[1,0]; 
      end; 
      set(uu{2}(8),'String',mat2str(avec));  
   case 3, cmp_reduction;
   case 4
      uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
      g4=get(uu0{1}(4),'UserData'); ModPars=g4{3}; 
      m_list=findobj(gcf,'Tag','MList'); m_list=m_list(end:-1:1);
      keyMod=extra_funs(5,m_list,'Value');
      if length(keyMod)==0, keyMod=n_max; end
      nn=ModPars(keyMod,1); nd=ModPars(keyMod,2); 
      num=ModPars(keyMod,7:7+nd); den=ModPars(keyMod,8+nd:8+2*nd);
      Tau=ModPars(keyMod,9+2*nd); g4{4}=tf(num,den,'InputDelay',Tau);
      set(uu0{1}(4),'UserData',g4);
      proc_model(1,5);   
   end
case {3,4,5,6,7}   
   G_Sys=nTask; 
   nn=arg1(1); nd=arg1(2); avec=arg2; id=arg3(1); ic=arg3(2);
   nPade=arg4(1); Pdly=arg4(2); G_Sys
   G_out=opt_reduction(G_Sys,nn,nd,avec,id,ic,[nPade,Pdly]);
case 8, G_out=opt_func(nTask,arg1,arg2,arg3,arg4,arg5,arg6,arg7);
end

%------------------------------------------------------------------------------
%do_reduction is the function which calls the corresponding routines to perform
%model reduction.
%------------------------------------------------------------------------------
function do_reduction()
uu=get(gcf,'UserData'); nTask=get(uu{1}(1),'Value'); Pdly=get(uu{1}(2),'Value');
if any([1,3,4,6]==nTask),
   nn=eval(get(uu{2}(2),'String')); nd=eval(get(uu{2}(4),'String'));
   if nTask==6,
      avec=eval(get(uu{2}(8),'String')); ic=get(uu{2}(10),'Value');
   else, ic=0; id=0; end;
else, 
   ic=0; id=0; nd=eval(get(uu{2}(6),'String')); nn=nd-1; 
   if nTask==5, nn=nd; end
end

uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
g1=get(uu0{1}(1),'UserData'); G1=tf(g1{2}); g4=get(uu0{1}(4),'UserData');
Td=g4{1}; nPade=g4{2}; G1.InputDelay=Td; 

if nTask==6
   if abs(avec(2))<1e-5, id=2;
   elseif abs(avec(1))<1e-5, if abs(avec(3))<1e-5, id=1; else, id=3; end
   else, if abs(avec(3))<1e-5, id=4; else, id=5; end
   end
end

%check whether such a reduced order model exists
ModPars=g4{3}; [n,m]=size(ModPars); key1=0;
for i=1:n,
   ii=(ModPars(i,1:6)==[nn,nd,nTask,Pdly id ic]);
   if sum(ii)==6, key1=1; break; end
end

key=1; 
if key1==1
   %if it exists, then load and display it directly
   nn=ModPars(i,1); nd=ModPars(i,2);
   num=ModPars(i,7:7+nd); den=ModPars(i,8+nd:8+2*nd);
   Td=ModPars(i,9+2*nd); G_red=tf(num,den,'InputDelay',Td); 
else
   %if not exist, then perform reduction
   switch nTask
   case 1, G_red=pade_red(G1,nn,nd,[nPade,Pdly]);
   case 2, G_red=routh_red(G1,nd,[nPade,Pdly]);
   case 3, [G_red,key]=dom_mod_red(G1,nn,nd,[nPade,Pdly]);
   case 4, G_red=ffpade_red(G1,nn,nd,[nPade,Pdly]);
   case 5, G_red=bal_real_red(G1,nd,[nPade,Pdly]);
   case 6, 
      g_wait=extra_funs(12,'Performing optimal reduction');
      pause(0.01)
      G_red=opt_reduction(G1,nn,nd,avec,id,ic,[nPade,Pdly]);
      close(g_wait);
   case {9,10}
      if exist('balmr')~=2,
         key=0;
         errordlg('Robust Control Toolbox is not available!','Warning: Reduction failed!');
      else,
         G_red=robust_red(G1,nd,nTask,[nPade,Pdly]);
      end
   otherwise,
      key=0;
      errordlg('Algorithm not available yet!','Warning: Reduction failed!');
   end
   if key==1, 
      %if reduction is success, then write the results back to the system
      g4=get(uu0{1}(4),'UserData'); ModPars=g4{3}; [n1,n2]=size(ModPars);
      [num,den,Td]=tfdata(G_red,'v'); PVec=[nn,nd,nTask,Pdly,id,ic,num,den,Td];
      n3=length(PVec); 
      ModPars=[ModPars,zeros(n1,n3-n2); PVec, zeros(1,n2-n3)];
      % reserve only the last 7 models
      if n1==7, ModPars=ModPars(2:8,:); end
      g4{3}=ModPars; 
   end
end
if key==1
   g4{4}=G_red; set(uu0{1}(4),'UserData',g4); close(gcf); proc_model(1,5); 
   uu=get(gcf,'UserData'); set(uu(6),'Visible','on');
end

%-----------------------------------------------------------------------------
%pade_red implements the Pade approximation technique
%
%   G_red=pade_red(G_Sys,nn,nd,arg1)
%where G_Sys is the original plant model transfer function which possibily have 
%delay terms.  (nn,nd) is the expected order of num and den, respectively. arg1 
%contains delay parameters -- [nPade, Pdly], where nPade is the order of Pade 
%approximation, and Pdly is where delay terms are used in the reduced model.
%G_red is the reduced model which can contain delays.
%------------------------------------------------------------------------------
function G_red=pade_red(G_Sys,nn,nd,arg1)
nPade=arg1(1); Pdly=arg1(2); [num,den,Td]=tfdata(G_Sys,'v');
if abs(Td)>0 & Pdly==0, [nP,dP]=pade(Td,nPade); num=conv(num,nP); den=conv(den,dP); end
n=length(den)-1; k=length(num)-1; d0=den(n+1); L=nn+nd;
num0=[zeros(1,L+n-k-1) num]/d0; den0=[zeros(1,L) den]/d0;
c=zeros(1,nn+nd); c(1)=num0(n+L);
for i=2:nn+nd+1, c(i)=num0(n+1+L-i)-sum(den0(n-i+2+L:n+L).*c(1:i-1)); end

w=-c(nn+2:nn+nd+1)'; vv=[c(nn+1:-1:1)'; zeros(nd-1-nn,1)];
W=rot90(hankel(c(nn+nd:-1:nn+1),vv)); V=rot90(hankel(c(nn:-1:1)));
x=[1 (W\w)']; dred=x(nd+1:-1:1)/x(nd+1); y=[c(1) x(2:nn+1)*V'+c(2:nn+1)]; nred=y(nn+1:-1:1)/x(nd+1);

if Pdly==0, Td=0; end
G_red=tf(nred,dred,'InputDelay',Td);

%----------------------------------------------------------
%routh_red implements the Routh approximation technique
%
%   G_red=routh_red(G_Sys,nd,arg1)
%descriptions to the I/O arguments can be found in pade_red
%----------------------------------------------------------
function G_red = routh_red(G_Sys,nr,arg1)
nPade=arg1(1); Pdly=arg1(2); [num,den,Td]=tfdata(G_Sys,'v');
if abs(Td)>0 & Pdly==0, [nP,dP]=pade(Td,nPade); num=conv(num,nP); den=conv(den,dP); end
n0=length(den); n1=length(num); a1=den(n0:-1:1); b1=[num(n1:-1:1) zeros(1,n0-n1-1)];
for k=1:n0-1, 
   k1=k+2; alpha(k)=a1(k)/a1(k+1); beta(k)=b1(k)/a1(k+1);
   for i=k1:2:n0-1, a1(i)=a1(i)-alpha(k)*a1(i+1); b1(i)=b1(i)-beta(k)*a1(i+1); end, 
end
nn=[]; dd=[1]; nn1=beta(1); dd1=[alpha(1), 1]; nred=nn1; dred=dd1;
for i=2:nr,
   nred=[alpha(i)*nn1, beta(i)]; dred=[alpha(i)*dd1, 0]; n0=length(dd); n1=length(dred);
   nred=nred+[zeros(1,n1-n0),nn]; dred=dred+[zeros(1,n1-n0),dd];
   nn=nn1; dd=dd1; nn1=nred; dd1=dred;
end
nred=nred(1:nr); [nred,dred]=tf_revs(nred,dred); [nred,dred]=tf_monic(nred,dred,1);

if Pdly==0, Td=0; end
G_red=tf(nred,dred,'InputDelay',Td);

%----------------------------------------------------------
%dom_mod_red implements the dominent mode technique
%
%   G_red=dom_mod_red(G_Sys,nn,nd,arg1)
%descriptions to the I/O arguments can be found in pade_red
%----------------------------------------------------------
function [G_red,key]=dom_mod_red(G_Sys,nn,nd,arg1)
nPade=arg1(1); Pdly=arg1(2); key=1; [num,den,Td]=tfdata(G_Sys,'v');
if abs(Td)>0 & Pdly==0, [nP,dP]=pade(Td,nPade); num=conv(num,nP); den=conv(den,dP); end
n0=length(den); n1=length(num); j=sqrt(-1); r=roots(den); rr=abs(real(r)); ri=imag(r);
[rr,i]=sort(rr); dmode(1:nd)=-rr(1:nd)+ri(i(1:nd))*j; dred=[1 -dmode(1)];
for i=2:nd, dred=conv(dred,[1 -dmode(i)]); end
d0=dred(nd+1); dred=dred(nd+1:-1:1)/d0; num1=[zeros(1,n0-n1) num]; c(1)=num(n1)/den(n0);
for i=2:nd, c0=0;
   for j=1:i-1, 
      i0=n0-j; if i0>0, c0=c0+den(i0)*c(i-j); end
   end
   i0=n0+1-i; if i0>0, c(i)=(num1(i0)-c0)/den(n0);
   else, c(i)=-c0/den(n0);
end, end
v0=dred(2:nn+1); 
for i=1:nn, for j=1:nn, if i+1-j>0, v(i,j)=c(i+1-j); end, end, end
nred=[c(1) v0*v'];
for i=2:nn+1, nred(i)=nred(i)+c(i); end
[nred,dred]=tf_revs(nred,dred); [nred,dred]=tf_monic(nred,dred,1);
if (abs(sum(imag(nred)))+abs(sum(imag(dred)))<10000*eps), 
   key=0; 
   errordlg('Cannot find the specified dominent modes!','Warning: Reduction failed!');
else,
   if Pdly==0, Td=0; end
   G_red=tf(nred,dred,'InputDelay',Td);
end

%------------------------------------------------------------------------
%ffpade_red implements the frequency fitting Pade approximation technique
%
%   G_red=ffpade_red(G_Sys,nn,nd,arg1)
%descriptions to the I/O arguments can be found in pade_red
%------------------------------------------------------------------------
function G_red=ffpade_red(G_Sys,nn,nd,arg1)
nPade=arg1(1); Pdly=arg1(2); [num,den,Td]=tfdata(G_Sys,'v');
if abs(Td)>0 & Pdly==0, [nP,dP]=pade(Td,nPade); num=conv(num,nP); den=conv(den,dP); end
w=logspace(-1,3); [m,p]=bode(num,den,w); graf_tool(1);
semilogx(w,20*log10(m)); [xx,yy]=ginput(nd-1);
np=nd-1;xx=[1;4]; wp=xx'; [mp,pp]=bode(num,den,wp); pp=pp*pi/180;

n0=length(den); n1=length(num); num1=[zeros(1,n0-n1) num]; c(1)=num(n1)/den(n0);
aa=den(n0:-1:1); bb=num1(n0:-1:1); [bb,aa]=tf_monic(bb,aa);
for i=2:nn+nd+1,
   for j=1:n0-1, cc(j)=bb(1)*aa(j+1)-bb(j+1); end
   bb=[cc zeros(1,n0-length(cc))]; cc=[]; c(i)=(-1)^(i-1)*bb(1);  
end
w11=eye(nn+1); w21=zeros(nd,nn+1); w12=zeros(1,nd); temp=w12;
for i=1:nn, temp=[-c(i), temp(1:nd-1)]; w12=[w12; temp]; end
w22=[c(nn+1), -temp(1:nd-1)]; temp=w22;
for i=1:nd-1, temp=[c(nn+1+i), temp(1:nd-1)]; w22=[w22; temp]; end
W=[w11,w12; w21,w22]; V=[c(1:nn+1)'; -c(nn+2:nn+nd+1)'];
%  ** replacing 2*np equation by Frequency Fit
for i=1:np,
   i1=nd+nn+2-2*i; i2=i1+1; W(i1,1)=-sin(pp(i)); W(i2,1)=cos(pp(i)); xp=wp(i)*wp(i);
   if nn~=0, W(i1,2)=wp(i)*cos(pp(i)); W(i2,2)=wp(i)*sin(pp(i)); end
   for j=3:nn+1, W(i1,j)=-xp*W(i1,j-2); W(i2,j)=-xp*W(i2,j-2); end
   W(i1,nn+2)=-wp(i)*mp(i); W(i1,nn+3)=0; W(i2,nn+2)=0; W(i2,nn+3)=xp*mp(i);
   for j=nn+4:nn+nd+1, W(i1,j)=-xp*W(i1,j-2); W(i2,j)=xp*W(i2,j-2); end
   V(i1)=0; V(i2)=mp(i);
end
theta=inv(W)*V; nred=theta(nn+1:-1:1)'/theta(nd+nn+1); dred=[theta(nd+nn+1:-1:nn+2)' 1]/theta(nd+nn+1);

if Pdly==0, Td=0; end
G_red=tf(nred,dred,'InputDelay',Td);

%----------------------------------------------------------
%bal_real_red implements the balanced realization technique
%
%   G_red=bal_real_red(G_Sys,nr,arg1)
%descriptions to the I/O arguments can be found in pade_red
%----------------------------------------------------------
function G_red=bal_real_red(G_Sys,nr,arg1)
nPade=arg1(1); Pdly=arg1(2); [num,den,Td]=tfdata(G_Sys,'v');
if abs(Td)>0 & Pdly==0, [nP,dP]=pade(Td,nPade); num=conv(num,nP); den=conv(den,dP); end
G_Sys=ss(tf(num,den)); G_red=minreal(G_Sys); [G_red,g]=balreal(G_red);
nn=length(g); aa=nn:-1:1; [g,ii]=sort(g); aa=aa(ii); elim=aa(nr+1:nn);
G_red=modred(G_red,elim); 
if Pdly==0, Td=0; end
G_red=tf(G_red); G_red.InputDelay=Td; 

%--------------------------------------------------------------------------------
%robust_red implements the robust reduction technique
%
%   robust_red(G_Sys,nd,nTask,arg1)
%where nTask=1 for optimal Hankel approximation, while 2 for Schur approximation. 
%Other descriptions to the I/O arguments can be found in pade_red
%--------------------------------------------------------------------------------
function G_red=robust_red(G_Sys,nd,nTask,arg1);
nPade=arg1(1); Pdly=arg1(2); [num,den,Td]=tfdata(G_Sys,'v');
if abs(Td)>0 & Pdly==0, [nP,dP]=pade(Td,nPade); G_Sys=G_Sys*tf(nP,dP); end
ss_G=ss(G_Sys); ii=find(real(eig(ss_G))>=0);
if nTask==9, [am,bm,cm,dm,totbnd,hsv]=balmr(ss_G.a,ss_G.b,ss_G.c,ss_G.d,1,nd);
else, [am,bm,cm,dm,totbnd,hsv]=schmr(ss_G.a,ss_G.b,ss_G.c,ss_G.d,1,nd); end
G_red=tf(ss(am,bm,cm,dm)); 
num=G_red.num{1}; ii=find(abs(num)>eps); G_red.num{1}=num(ii(1):end);
if Pdly==0, Td=0; end
G_red.InputDelay=Td;

%----------------------------------------------------------------
%opt_reduction implements the optimal reduction technique
%
%   G_red=opt_reduction(G_Sys,nn,nd,avec,id,ic,arg1)
%where 
%   avec -- the weighting vector for optimal reduction
%   (id,ic) -- criterion weighting and performance weighting
%Other descriptions to the I/O arguments can be found in pade_red
%----------------------------------------------------------------
function G_red=opt_reduction(G_Sys,nn,nd,avec,id,ic,arg1)
nPade=arg1(1); Pdly=arg1(2); [num,den,Td]=tfdata(G_Sys,'v');
if num(1)==0, key=0; num=num(2:end); else, key=1; end
if abs(Td)>0 & Pdly==0, [nP,dP]=pade(Td,nPade); num=conv(num,nP); den=conv(den,dP); end
G_routh=routh_red(G_Sys,nd,[3,0]); beta=G_routh.num{1}(nd+1-nn:nd+1); alph=G_routh.den{1};
n0=1; if id==1 | key==1, n0=0; end
x=[beta(1:nn+1-n0),alph(2:nd+1)];
Tau=1.5*Td; if abs(Tau)<1e-5, Tau=0.5; end
if Pdly==1, x=[x,Tau]; end
y=opt_func(x,num,den,[nn,nd,id,n0,ic,key],Td,nPade,Pdly,avec);
x=fmins('mod_reduction',x,[0,1e-4,1e-4,zeros(1,10),500],[],num,den,[nn,nd,id,n0,ic,key],Td,nPade,Pdly,avec);
alph=[1,x(nn+2-n0:nn+1-n0+nd)]; beta=x(1:nn+1);
if id~=1 & key==0, beta(nn+1)=alph(end)*num(end)/den(end); end

if Pdly==1, Tau=x(end)+Td; else, Tau=0; end
G_red=tf(beta,alph,'InputDelay',Tau); 

%-------------------------------------------------------------------------------
%tf_monic is a function which can be used to perform monic transformation to the
%transfer function of a control system.
%
%  [NN, DD]=tf_monic(NUM, DEN)
%where
%   NN, DD are the num and den after monic transformation
%   NUM, DEN are the num and den of original system
%-------------------------------------------------------------------------------
function [nn,dd]=tf_monic(num,den,key)
if nargin==2
   nb=length(den); nn=num./den(1); i=length(den):-1:1; dd(i)=den(i)/den(1); 
   nn=[zeros(1,length(dd)-length(nn)) nn];
elseif key==1, nn=num/den(1); dd=den/den(1);
else, nn=num/den(end); dd=den/den(end); end

%--------------------------------------------------------------------------
%tf_revs is a function which can be used to transform the transfer function
%                 B(1) s^M + ... + B(M+1) 
%       ^G(s) = -----------------------------
%                 A(1) s^N + ... + A(N+1)
%into its equivelent form of
%               B(1) + B(2) s + ... + B(M+1) s^M
%      G(s) = ------------------------------------
%              A(1) + A(2) s + ... + A(N+1) s^N
%or vise versa.
%    [N, D] = tf_revs(NUM, DEN)
%     N, D are the num and DEN of G(s) 
%     NUM, DEN are the num and den of ^G(s)
%---------------------------------------------------------------------------
function [n,d]=tf_revs(num,den)
d=den(end:-1:1); n=num(end:-1:1);

%----------------------------------------------------------------
%cmp_reduction is used to compare different reduced order models.
%----------------------------------------------------------------
function cmp_reduction()
g0=gcf;
g_Slnk=findobj(g0,'Tag','SLnk'); g_list=findobj(g0,'Tag','List');
nTask=get(g_list,'Value'); b_Simulink=get(g_Slnk,'Value');
uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
if b_Simulink==1
   g1=get(uu0{1}(1),'UserData');   
   if g1{1}==4, sim_model=g1{3};
   else, b_Simulink=0; set(g_Slnk,'Value',0); end   
end
g4=get(uu0{1}(4),'UserData'); ModPars=g4{3};
g1=get(uu0{1}(1),'UserData'); G_Sys=g1{2}; G_Sys.InputDelay=g4{1};
ii=[]; 
m_list=findobj(g0,'Tag','MList'); m_list=m_list(end:-1:1);
for i=1:length(m_list), if get(m_list(i),'Value')==1, ii=[ii,i]; end, end
lstColorMap=[0         0    1.0000
             0    0.5000         0
        1.0000         0         0
             0    0.7500    0.7500
        0.7500         0    0.7500
        0.7500    0.7500         0
        0.2500    0.2500    0.2500
        0.5000    0.2500    0.7500];
switch nTask     
case 3, graf_tool(3); delete(gca); hold off; ngrid; 
case 4, tr_cmd='step';
case 5, tr_cmd='impulse';   
end
for i=0:length(ii)
   if i==0, G_red=G_Sys; 
   else
      i_now=ii(i); nn=ModPars(i_now,1); nd=ModPars(i_now,2); 
      num=ModPars(i_now,7:7+nd); den=ModPars(i_now,8+nd:8+2*nd);
      Tau=ModPars(i_now,9+2*nd); G_red=tf(num,den,'InputDelay',Tau); 
   end
   switch nTask
   case 1,
      graf_tool(1); [mag,phi,w]=bode(G_red);
      subplot(211), h(1)=semilogx(w,20*log10([mag(:)]));
      subplot(212), h(2)=semilogx(w,[phi(:)]);
   case 2
      graf_tool(2); [re,im,w]=nyquist(G_red); h=plot([re(:)],[im(:)]);
   case 3
      graf_tool(3); [mag,phi,w]=nichols(G_red); h=plot([phi(:)],20*log10([mag(:)]));
   case {4,5}
      graf_tool(nTask+2); eval(['[y,t]=' tr_cmd '(G_red); ']); 
      if i==0 & b_Simulink==1
         Td=G_Sys.InputDelay; t_end=t(end);
         if nTask==4, ut=[0,1; t_end,1]; 
         else, ut=[0,1000; 0.001,1000; t_end,0]; end  
         [t,x,y]=sim(sim_model,[0,t_end],[],ut); ii=find(t>=Td); 
         y=[zeros(length(t)-length(ii),1); y]; y=y(1:length(t)); h=plot(t,y);
      else, eval(['[y,t]=' tr_cmd '(G_red); ']); h=plot(t,y); end      
   end
   set(h,'Color',lstColorMap(i+1,:));   
   if i==0
      h_axes=extra_funs(2); for j=1:length(h_axes), axes(h_axes(j)); hold on; end   
   end
end   
for i=1:length(h_axes), axes(h_axes(i)); hold off; end   

%--------------------------------------------------------
%modcmp_win creates a dialog box for model comparison
%--------------------------------------------------------
function modcmp_win()
g_cmp=findobj('Name','Reduced Model Comparison');
if length(g_cmp)==0
   g_cmp=figure('Units','normalized','Position',[0.18625 0.248 0.425 0.367],...
      'NumberTitle','off','Name','Reduced Model Comparison','Tag','CtrlLABExtras',...
      'MenuBar','none','Color',0.8*[1,1,1],'Resize','off');
   extra_funs(1); hh=extra_funs(10,[0.05,0.05],[0.56,0.9]);
   uicontrol('Style','Text','String','Select a Model',...
      'Units','normalized','Position',[0.07,0.87,0.30,0.06],'BackgroundColor',0.8*[1,1,1]);
   uicontrol('Style','PushButton','String','Compare',...
      'Units','normalized','Position',[0.80,0.81,0.18,0.1],'CallBack','mod_reduction(0,3); ');
   uicontrol('Style','PushButton','String','Show',...
      'Units','normalized','Position',[0.60,0.81,0.18,0.1],'CallBack','mod_reduction(0,4);');
   uicontrol('Style','PushButton','String','Close',...
      'Units','normalized','Position',[0.60,0.68,0.18,0.1],'CallBack','close(gcf);');
   uicontrol('Style','PushButton','String','Help',...
      'Units','normalized','Position',[0.80,0.68,0.18,0.1],'CallBack','clab_help(26);');
   uicontrol('Style','PushButton','String','Refresh List',...
      'Units','normalized','Position',[0.65,0.55,0.28,0.1],'CallBack','mod_reduction;');
   add_modlist;
   extra_funs(10,[0.60,0.05],[0.97,0.48]);
   uicontrol('Style','Text','String','Assign Specifications',...
      'Units','normalized','Position',[0.62,0.45,0.31,0.06],'BackgroundColor',0.8*[1,1,1]);
   str=str2mat('Bode diagram','Nyquist plot','Nichols chart',...
        'Step response','Impulse response','Criterion');
   uicontrol('Tag','List','Style','Popupmenu','String',str,'Value',4,...
      'Units','normalized','Position',[0.63,0.32,0.30,0.07],'BackgroundColor',[1,1,1]);
   uu=get(findobj('Tag','CtrlLABMain'),'UserData');
   g1=get(uu{1}(1),'UserData');
   [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
   if v2==2 & v3==0, strCheck='ToggleButton'; else, strCheck='CheckBox'; end 
   uicontrol('Tag','SLnk','Style',strCheck,'String','Use SIMULINK','Value',0,...
      'Units','normalized','Position',[0.66,0.14,0.26,0.08],...
      'BackgroundColor',0.8*[1,1,1],'Enable',extra_funs(6,g1{1}==4));
else, 
   h_win=figure(g_cmp); delete(findobj(gcf,'Tag','MList')); add_modlist;
end

%--------------------------------------------------------
%modred_win creates a dialog box for reduction parameters
%--------------------------------------------------------
function modred_win(nTask)
g_red=findobj('Name','Model Reduction Parameters');
if length(g_red)==0
   avec=[1,0,0,0,0];
   g_red=figure('Units','normalized','Position',[0.18625 0.248 0.425 0.283],...
      'NumberTitle','off','Name','Model Reduction Parameters','Tag','CtrlLABExtras',...
      'MenuBar','none','Color',0.8*[1,1,1],'Resize','off');
   extra_funs(1); kDly=0; 
   display_str(0.04,0.9,'Select a Method',[0,0,0],'on',9);
   str=str2mat('Pade approximation','Routh''s method','Dominant modes',...
        'FF-Pade method','Balanced realisation','Optimal reduction',...
        'Modal reduction','Aggregation','Optimal Hankel Approxation','Schur reduction');
   h_alg(1)=uicontrol('Style','Popupmenu','String',str,'Value',nTask,...
      'Units','normalized','Position',[0.1,0.72,0.45,0.11],...
      'BackgroundColor',[1,1,1],'CallBack','mod_reduction(0,1);');
   [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
   if v2==2 & v3==0, strCheck='ToggleButton'; else, strCheck='CheckBox'; end 
   h_alg(2)=uicontrol('Style',strCheck,'String','With Delay',...
      'Units','normalized','Position',[0.1,0.55,0.30,0.11],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','extra_funs(3,gco,''Value'');');
   extra_funs(10,[0.0386, 0.0509],[0.55,0.4281]);
   uicontrol('Style','Text','String','Expected Reduction Order',...
      'Units','normalized','Position',[0.08,0.36,0.38,0.10],'Backgroundcolor',0.8*[1,1,1]);
   [xL,h_red(1)]=display_str(0.08,0.31,'Numerator Order',[0,0,0],'on',9);
   h_red(2)=uicontrol('Style','Edit','String','1',...
      'Units','normalized','Position',[0.4,0.25,0.1,0.11],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
   [xL,h_red(3)]=display_str(0.08,0.16,'Denominator Order',[0,0,0],'on',9);
   h_red(4)=uicontrol('Style','Edit','String','2',...
      'Units','normalized','Position',[0.4,0.11,0.1,0.11],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
   [xL,h_red(5)]=display_str(0.08,0.29,'Reduction Order',[0,0,0],'off',9);
   h_red(6)=uicontrol('Style','Edit','String','2',...
      'Units','normalized','Position',[0.4,0.24,0.1,0.11],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1],'Visible','off');
   [xL,h_red(7)]=display_str(0.58,0.24,'Weighting Vector',[0,0,0],'off',9);
   h_red(8)=uicontrol('Style','Edit','String','[1,0,0,0,0]',...
      'Units','normalized','Position',[0.60,0.08,0.35,0.11],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1],'Visible','off');
   [xL,h_red(9)]=display_str(0.58,0.49,'Criterion',[0,0,0],'off',9);
   h_red(10)=uicontrol('Style','PopupMenu','Value',1,'Visible','off',...
      'String','ISE criterion |TISE criterion |Exponential',...
      'Units','normalized','Position',[0.60,0.32,0.34,0.11],...
      'BackgroundColor',[1,1,1],'CallBack','mod_reduction(0,2);');
   set(gcf,'UserData',{h_alg,h_red});
   uicontrol('Style','Pushbutton','String','Reduce',...
      'Units','normalized','Position',[0.80,0.83,0.17,0.14],'CallBack','mod_reduction(0,0);');
   uicontrol('Style','Pushbutton','String','Cancel',...
      'Units','normalized','Position',[0.80,0.67,0.17,0.14],'CallBack','close(gcf);');
   uicontrol('Style','Pushbutton','String','Help',...
      'Units','normalized','Position',[0.80,0.51,0.17,0.14],'Callback','clab_help(4);');
else, figure(g_red); end
mod_reduction(0,1);

%------------------------------------------------------------------------------
%opt_func defines the optimal criterion for model reduction of control systems.
%
%  y=opt_func(x,b,a,nvec,Tdly,nPad,Pdly,avec)
%where
%  y -- the actual criterion calculated
%  x -- the vector of parameters to be optimized
%  (b,a) -- the transfer function of the original system
%  nvec -- the vector contains information for reduction
%  Tdly -- delay constant of the original system
%  nPad -- order of Pade approximation
%  Pdly -- key for whether delay is expected in reduction
%  avec -- the weighting vector for optimal reduction
%------------------------------------------------------------------------------
function y=opt_func(x,b,a,nvec,Tdly,nPad,Pdly,avec)
ff0=1e10;

nn=nvec(1); nd=nvec(2); id=nvec(3); n0=nvec(4); ic=nvec(5); key=nvec(6);
alph=[1,x(nn+2-n0:nn+1-n0+nd)]; beta=x(1:nn+1);
if id~=1 & key==0, beta(nn+1)=alph(end)*b(end)/a(end); end

a0=conv(a,alph); b0=conv(b,alph); c0=conv(beta,a);
if Pdly==1,
   tau=x(end); [nP,dP]=pade(tau,nPad); a0=conv(a0,dP); b0=conv(b0,dP); c0=conv(c0,nP); 
end

d0=vec_plus(c0,-b0); c0=a0; n_max=length(d0);
switch id
case 2, d0=[0,d0(1:n_max)];
case 3, c0=conv(c0,[a3,1]); d0=[0,d0(1:n_max)];
case 4, d0=[0 conv(d0,[a2,a1])];
case 5, c0=conv(a0,[a3,a1]); d0=[0 conv([a2+a1*a3,a1],d0)];
end
ct=c0; dt=d0;

if ic==2, for i=1:avec(5), [b0,a0]=tf_derv(d0,c0); c0=a0; d0=b0; end
elseif ic==3, c0=polyexpd(c0,avec(4)); d0=polyexpd(d0,avec(4)); end

[y,ierr]=r_intgl(c0,d0);
if ic==4, [y1,ierr]=r_intgl(ct,dt); y=y+y1; end
if ierr==1, y=10*ff0; else, ff0=y; end

%--------------------------------------------------------------------------------
%r_intgl is used to evaluate the H_2 norm of a transfer function model, using the 
%Astrom recursive algorithm.
%
%   [v,ierr]=r_intgl(a,b)
%where
%   (a,b) --- den and num of the transfer function
%   v --- the H_2 norm
%   ierr --- 1 if there are error or unstable
%--------------------------------------------------------------------------------
function [v,ierr]=r_intgl(a,b)
ierr=0; v=0; 
n=length(a); nb=length(b);
if n<nb,
   warndlg('System not proper!','Warning: Reduction failed!');
   ierr=1; return
elseif n==nb
   if abs(b(1))>eps,
      warndlg('System not strictly proper!','Warning: Reduction failed!');
      ierr=1; return
   else, a1=a; b1=b(2:nb); end
else, a1=a; b1=[zeros(1,n-nb-1) b]; end
if (a1(1)<=eps), ierr=1;  
else
   for k=1:n-1
      if (a1(k+1)<=eps), ierr=1; return
      else,
         alpha=a1(k)/a1(k+1); beta=b1(k)/a1(k+1); v=v+beta*beta/alpha; k1=k+2;
         for i=k1:2:n-1, a1(i)=a1(i)-alpha*a1(i+1); b1(i)=b1(i)-beta*a1(i+1); end
   end, end,
   v=0.5*v;
end

%----------------------------------------------------------------------------
%tf_derv is used to obtain the first derivative of a given transfer function.
%
%   [e,f]=tf_derv(b,a)
%where 
%  (b,a) --- the num, den of the original TF
%  (e,f) --- the num, den of the derivative of the TF
%----------------------------------------------------------------------------
function [e,f]=tf_derv(b,a)
f=conv(a,a); e1=conv((length(b)-1:-1:1).*b(1:end-1),a);
e2=conv((length(a)-1:-1:1).*a(1:end-1),b); e=vec_plus(e1,-e2);

%----------------------------------------------------------------------------
%add_modlist is used to add the obtained reduced order model to the existing
%model list so that they can be compared.
%----------------------------------------------------------------------------
function add_modlist()

%define the reduction name abbreviate form
MRedName=str2mat('Pade approximation','Routh approximation','Dominant mode',...
   'FF-Pade approximation','Balance Realization','Optimal reductition',...
   'Modal reduction','Aggregation','Optimal Hankel','Optimal Schur');
uu=get(findobj('Tag','CtrlLABMain'),'UserData');
g4=get(uu{1}(4),'UserData'); ModPars=g4{3}; [nModels,m]=size(ModPars); chkModels=[];
[v,d]=version; v1=eval(v(1)); v2=eval(v(3));
if v2>=2, strCheck='ToggleButton'; else, strCheck='CheckBox'; end 

%set a check box for each of the reduced models
X0=0.1; Y0=0.75;
for i=1:nModels
   str=[MRedName(ModPars(i,3),:),int2str(ModPars(i,1)),'/' int2str(ModPars(i,2))];
   uicontrol('Tag','MList','Style',strCheck,'String',str,'Value',0,...
      'Units','normalized','Position',[X0,Y0,0.45,0.09],'BackgroundColor',0.8*[1,1,1]);
   Y0=Y0-0.10;
end

%----------------------------------------------------------------------------
%vec_plus is used to add two polynomials together
%    
%        e=vec_plus(e1,e2)
%----------------------------------------------------------------------------
function e=vec_plus(e1,e2)
L0=length(e1)-length(e2); e=[zeros(1,-L0) e1]+[zeros(1,L0) e2];