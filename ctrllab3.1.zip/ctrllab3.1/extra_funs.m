%extra_funs is composed of -
%common functions used in CtrlLAB.  These functions are accumulated in the same 
%module.  The functions are identified by an ID value nTask, followed by necessary
%arguments, given in arg_i.  Each of the function is commented with its function, 
%and extra explanation is given in the functions.
%
%   key=extra_funs(nTask,arg1,arg2,arg3,arg4,arg5)
%
%Details of the function and IDs are shown in the syntax
%
%The functions available in the module are
%
%  Sub 1: renew_axes -- delete and re-create new axes
%  Sub 2: prop_list -- handle lists which have the property 
%  Sub 3: taggle_onoff -- taggle on/off a certain property
%  Sub 4: menu_exclusive -- make the properties mutual exclusive
%  Sub 5: menu_value -- get the values in the list which is on
%  Sub 6: onoff -- convert '0/1 to 'on'/'off'
%  Sub 7: vec_len -- get the actual length of a TeX string
%  Sub 8: set_slider -- set the sliders on
%%%  Sub 9: err_msg_disp -- display a dialog box with error messages
%     (replaced by warndlg, this is no longer used)
%  Sub 10: drwframe -- draw a frame in a dialog box
%  Sub 11: is_on -- test a property is on or not
%  Sub 12: waitmsg -- displays a waiting dialog box
%  Sub 13: reveal_win-- called under err_msg_disp;
%

%Designed by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%  This module is for use with CtrlLAB 3.0.
%  Date: 16 October, 1999 $3.0
%------------------------------------------------------------

function key=extra_funs(nTask,arg1,arg2,arg3,arg4,arg5)
switch nTask
case 1
   %clearing existing axes  
   if nargin==1, renew_axes;
   elseif nargin==2, renew_axes(arg1); end   
case 2
   %finding the list of all objects in current figure
   %which have the given Type
   switch nargin
   case 1, key=prop_list('axes');
   case 2, key=prop_list(arg1);       
   case 3, key=prop_list(arg1,1);
   end
case 3 
   %taggle the handles of certain property
   taggle_onoff(arg1,arg2);
case 4
   %set the properties of certain object exclusive
   Property=arg2;
   if length(arg1)==0
      h_items_on=arg3; h_items_off=arg4;
   else
      uu=get(gcf,'UserData');     
      if isa(uu,'cell')
         h_items_on=uu{arg1}(arg3); h_items_off=uu{arg1}(arg4);
      else
         h_items_on=uu(arg3); h_items_off=uu(arg4);
      end
   end
   menu_exclusive(Property,h_items_on,h_items_off);
case 5
   %get the values of certain properties from the list
   Property=arg2; uu=get(gcf,'UserData');
   if isa(uu,'cell'), Handle=uu{arg1}(arg3);
   else, 
      if nargin==3, Handle=arg1; else, Handle=uu(arg3); end
   end
   if nargin<=4,
      %find the first matching item
      key=menu_value(Handle, Property);
   else,
      %find all the items which matches requests
      key=menu_value(Handle, Property,[]);
   end   
case 6
   %convert 1 and 0 into 'on' and 'off' respectively
   key=onoff(arg1);
case 7
   %get the actual length of a TeX string
   key=vec_len(arg1);
case 8
   %set horizontal and vertical sliders in the graphcs window
   set_slider(arg1);
case 9
   %show an error message dialog box
   if nargout==0, 
      if nargin==2, err_msg_disp(arg1);
      elseif nargin==3, err_msg_disp(arg1,arg2); end   
   else, key=err_msg_disp(arg1); end
case 10
   %draw a frame in graphics window
   p1=arg1; p2=arg2; 
   if nargin==4, vis=arg3; else, vis='on'; end
   key=drwframe(p1,p2,vis);
case 11, %test a property is on or not
   key=is_on(arg1,arg2);
case 12, %display a wait dialog box
   if nargout==0, waitmsg(arg1);
   else, key=waitmsg(arg1); end
case 13, reveal_win;   
end      

%-------------------------------------------------------------------------------
%Sub Function 1: renew_axes()
%  delete all the axes and then create new axes in the current window.  There is 
%  no input and output argument in the function call.
%-------------------------------------------------------------------------------
function renew_axes(arg1)
%remove all the axes on the graph window
delete(prop_list('axes'));
if nargin==0, 
   %if there is no size argument, then set it to maximum 
   arg1=[0.001,0.001,0.998,0.998]; 
end
%set new axis and define it to invisible mode
axes('Position',arg1);
axis([0,1,0,1]); set(gca,'Visible','off');

%---------------------------------------------------------------------------
%Sub Function 2: key=prop_list(Type,arg1) 
%  get all the handles of the specified property in the current window.  The 
%  handles are returned in key.
%---------------------------------------------------------------------------
function key=prop_list(Type,arg1)
if nargin==1, y=get(gcf,'Child');
else, y=get(gca,'Child'); end

ii=[];
for i=1:length(y)
   c=get(y(i),'Type');
   if strcmp(c,Type), ii=[ii,i]; end
end   
key=y(ii);

%---------------------------------------------------------------------------
%Sub Function 3: taggle_onoff(Handle,Property)
%  taggle on/off a certain property 'Property' of a handle 'Handle'.  If the 
%  property value is 0/1, it also tangle the values.
%---------------------------------------------------------------------------
function taggle_onoff(Handle,Property)
h_str=get(Handle,Property);
if isa(h_str,'double')
   if h_str==1, set(Handle,Property,1);
   else, set(Handle,Property,0); end
else
   if strcmp(h_str,'on'), set(Handle,Property,'off');
   else, set(Handle,Property,'on'); end
end   

%------------------------------------------------------------------------------
%Sub Function 4: make the properties in a object in the window mutual exclusive.
%  menu_exclusive(key,Property,items_on,items_off)
%  where key is the ID in userdata of the window.  Property is the actual 
%  property to be set or unset.  items_on and items_off are the lists of the 
%  arrays to be set or unset.  key0 is an extra argument which set properties 
%  to 1 or 0 instead.
%------------------------------------------------------------------------------
function menu_exclusive(Property,items_on,items_off)
h_str=get(items_on(1),Property);
if isa(h_str,'double')
   set(items_on,Property,1); set(items_off,Property,0); 
else
   set(items_on,Property,'on'); set(items_off,Property,'off'); 
end  

%------------------------------------------------------------------------------
%Sub Function 5: ret=menu_value(key, Property, vec)
%  get the values in the list which is on.  The vec is used to contain the list 
%  of menu items.  
%------------------------------------------------------------------------------
function ret=menu_value(hHandle,Property,arg1)
h_str=get(hHandle(1),Property); key=0; ret=[];
for k=1:length(hHandle)
   if isa(h_str,'double')
      if get(hHandle(k),Property)==1, 
         if nargin==3, ret=[ret;k];
         else, ret=k; break; end
      end
   else   
      if strcmp(get(hHandle(k),Property),'on'), 
         if nargin==3, ret=[ret;k];
         else, ret=k; break; end
      end
   end   
end

%-----------------------------------------------------------
%Sub Function 6: key=onoff(key0)
%  convert the 0 and 1 to 'on' or 'off'
%-----------------------------------------------------------
function key=onoff(key0)
%OnOff convert 0,1 value into strings
key='on';
if length(key0)>0, if key0==0, key='off'; end, end

%--------------------------------------------------------------------------
%Sub Function 7: n=vec_len(vec)
%  get the actual length of the string.  In the string, TeX commands can be 
%  contained.  The actual length is returned in n.
%--------------------------------------------------------------------------
function n=vec_len(vec)
vec_1=vec(find(vec~='^'&vec~='{'&vec~='}'));
ii=findstr(vec_1,'\times'); n=length(vec_1)-5*length(ii);
ii=findstr(vec_1,'\pm'); n=n-2*length(ii);

%------------------------------------------------------------------------------
%Sub Function 8: set_slider(key)
%  set the sliders of the horizontal and vertical axes after on set the sliders 
%  to new positions. Here 1 for horizontal axis and 2 for veryical axis.
%------------------------------------------------------------------------------
function set_slider(key)
vv=get(gco,'Value'); hFrame=get(gco,'UserData');
if key==1,
   set(gca,'XLim',[vv-0.5,vv+0.5]); set(hFrame,'XData',[0,1,1,0,0]+vv-0.5);
else
   set(gca,'YLim',[vv-0.5,vv+0.5]); set(hFrame,'YData',[0,0,1,1,0]+vv-0.5);
end

%--------------------------------------------------------------------------------
%Sub Function 9: err_msg_disp(strMsg)
%  display a dialog box with error messages, where the error information is given 
%  in strMsg.
%--------------------------------------------------------------------------------
function g_err=err_msg_disp(strMsg,kk)
h_err=findobj('Name','Error Message');
if length(h_err)==0
   screen=get(0,'ScreenSize');
   WinWidth=screen(3); WinHeight=screen(4); XYpt=[WinWidth WinHeight]/2;  
   nWidth=length(strMsg)*6.3; nHeight=0.15*WinHeight; [m,n]=size(strMsg);
   h_err=figure('Position',[XYpt(1)-nWidth/2,XYpt(2)-nHeight/2,nWidth+20,nHeight+(m-1)*20],...
      'NumberTitle','off','Name','Error Message',...
      'MenuBar','none','Color',[1;0;0],...
      'Tag','CtrlLABError','Resize','off');
   if nargin==2, set(gcf,'Tag','CtrlLABError_E'); end
   uicontrol('Style','Pushbutton','String','OK',...
      'Unit','pixel','Position',[nWidth/2-30,15,60,22],...
      'UserData',[],'Callback','extra_funs(13);')
else
   figure(h_err); delete(axes_list('axes'));   
end

yL=0.7; renew_axes;
for i=1:m
   display_str(0.08,yL,strMsg(i,:),[0,0,0]); yL=yL-0.1;
end

%---------------------------------------------------------------------------------
%Sub Function 10: hh=drwframe(p1,p2,vis)
% where p1, p2 are bottom-left and upper-right points of the frame to be drawn.  
% vis is for the visibility of the frame box.  hh returns the handle of the frame.
%---------------------------------------------------------------------------------
function hh=drwframe(p1,p2,vis)
hh=line([p1(1),p2(1),p2(1),p1(1),p1(1)],[p1(2),p1(2),p2(2),p2(2),p1(2)]);
set(hh,'Color',[0,0,0],'Visible',vis); 

%---------------------------------------------------------------------------------
%Sub Function 11: hh=is_on(Handle,Property)
% where Property is the property of Handle is tested, and the returned variable is 
% 1 if property is on, 0 if it is off.
%---------------------------------------------------------------------------------
function hh=is_on(Handle,Property)
h_onoff=get(Handle,Property);
hh=0;
if strcmp(h_onoff,'on'), hh=1; end

%-----------------------------------------------------------
%Sub Function 12: g_wait=waitmsg(nametx,XYpt)
% displays a dialog box which prompts the user to wait
%-----------------------------------------------------------
function g_wait=waitmsg(nametx,XYpt)
screen=get(0,'ScreenSize');
WinWidth=screen(3); WinHeight=screen(4); 

if nargin==1, XYpt=[WinWidth WinHeight]/2; end 
nWidth=length(nametx)*6; nHeight=0.05*WinHeight;
g_wait=figure('Position',[XYpt(1)-nWidth/2,XYpt(2)-nHeight/2,nWidth,nHeight],...
   'NumberTitle','off','Name','Please Wait',...
   'MenuBar','none','Color',[1,1,0],'Resize','off');
renew_axes; display_str(0.08,0.6,nametx,[0,0,0]);

%-----------------------------------------------------------
%Sub Function 13: reveal_win
% close the error msg window and reveal the previous window
%-----------------------------------------------------------
function reveal_win()
uu=get(gcf,'UserData'); close(gcf);
if length(uu)>0, set(uu,'Visible','on'); figure(uu); end

