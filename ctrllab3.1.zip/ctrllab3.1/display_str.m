%display_str show strings in the current window or convert a string into TeX format
%
%  [xL,h]=display_str(x,y,Str1,nCol,vis,nFSize,...
%         fName,fWeight,fAngle)
%
%where
%
%  xL -- the coordinate of the right most point 
%  h  -- the handle of the string displayed
%  (x,y) -- the atarting position of the strings
%  Str1 -- the string to be displayed
%  nCol -- the color specification ([1,1,1])
%  vis  -- the visibility of the strings  ('on')  
%  nFSize -- the size of the characters to be displayed (9)
%  fName -- the font name ('Times New Roman') 
%  fWeight -- the font weight ('normal')
%  fAngle  -- the font angle ('normal')
%
%If there is no input/output variable, then the information display window will be 
%brought to front and clears the existing window.
%
%If Str1 is a double variable, and four input arguments are specified, then complex 
%format will be displayed.
%
%If a single input argument is specified, and the argument is a vector, then a TeX 
%string is returned which reflects the polynomial.  Otherwise a TeX string for the 
%floating point value is returned.
%
%The functions available in the module are
%
%  compl_shw -- shows complex vectors on graphics window
%  flt2string -- converts a number into TeX string
%  poly2str -- converts a polynomial into TeX string
%  info_disp_win -- initializes the information display window
%

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%This module is used only with CtrlLAB.
%------------------------------------------------------------------------

function [xL,h]=display_str(varargin)
%x,y,Str1,nCol,vis,nFSize,...
%                            fName,fWeight,fAngle,arg1)
if nargin==0, 
   %if no argument given, just bring the information display window to front 
   %and initialize it                      
   info_disp_win; 
else                         
   ni=nargin; j=0;
   if isa(varargin{1},'char'), ni=ni-1; j=1; end
   if ni>=1, x=varargin{1+j}; end   
   if ni>=2, y=varargin{2+j}; end   
   if ni>=3, Str1=varargin{3+j}; end   
   if ni>=4, nCol=varargin{4+j}; else, nCol=[0,0,0]; end   
   if ni>=5, vis=varargin{5+j}; else, vis='on'; end   
   if ni>=6, nFSize=varargin{6+j}; else, nFSize=10; end   
   if ni>=7, fName=varargin{7+j}; else, fName='Times New Roman'; end   
   if ni>=8, fWeight=varargin{8+j}; else, fWeight='normal'; end   
   if ni>=9, fAngle=varargin{9+j}; else, fAngle='normal'; end   
   if nargin<=2, Str1=0; end
   if isa(Str1,'char')
      %if the argument to be displayed is a string, then display it and set 
      %all the font properties
      h=text(x,y,Str1); 
      screen=get(0,'ScreenSize');
      nFSize=floor(nFSize*screen(3)/800);
      set(h,'FontName',fName,'FontSize',nFSize,'EraseMode','normal',...
         'FontWeight',fWeight,'Color',nCol,'Visible',vis,'FontAngle',fAngle);
      if j==1, set(h,'Tag',varargin{1}); end
      xL1=get(h,'Extent'); xL=xL1(1)+xL1(3); 
   else, 
      switch nargin
      case 1,
         if length(x)>1, 
            %convert a polynomial vector into string
            xL=poly2str(x);
         else, 
            %convert a floating point value into string
            xL=flt2string(x);   
         end
      case {2,3}, 
         %convert a floating point value into string
         if length(y)==0, %return empty string if it equals 1
            if abs(x-1)<1e-10, xL=''; else, xL=flt2string(x); end
         else, xL=flt2string(x,y,Str1); end
      case 4
         %convert a complex vector into string
         [xL,h]=compl_shw(x,y,Str1,nCol); 
         xL1=get(h,'Extent'); xL=xL1(1)+xL1(3); 
      end   
end, end

%-----------------------------------------------------
%compl_shw shows complex vectors on graphics window
%
%   [xL,h]=compl_shw(x,y,z,bSorted)
%where
%  [xL, h] --- same as in display_str
%  (x,y) -- the starting point of display
%  z -- the vector to be displayed
%  bSorted -- declare whether z should be shorted
%-----------------------------------------------------
function [xL,h]=compl_shw(x,y,z,bSorted)
%set default mode, i.e., un-sorted mode to the vector
if nargin<4, bSorted=0; end

%if sorting is needed, then perform sorting to the vector
if bSorted, [xx,ii]=sort(real(z)); z=z(ii,:); end
Str_C=[];
for i=1:length(z)
   if imag(z(i))>=0
      Str_C=[Str_C, flt2string(real(z(i)))];
      if imag(z(i))>1e-10, 
         %if element is complex, then convert it to TeX form
         Str_C=[Str_C, '\pm' flt2string(imag(z(i))) 'i']; 
      end, 
      if i~=length(z), Str_C=[Str_C,',   ']; end
   end
end

%if the vector is empty, then display an empty sign
if length(z)==0, Str_C='[]'; end

%display the converted string
[xL,h]=display_str(x,y,Str_C);

%--------------------------------------------------------
%flt2string converts a number into TeX string
%
%   ss2=flt2string(v,nrec,err)
%where
%  v -- the value to be converted
%  nrec -- number of digits preserved (4)
%  err -- zero trancation tolerance (0 for no trancation) 
%--------------------------------------------------------
function ss2=flt2string(v,nrec,err)

%set default display properties
if nargin==1, nrec=4; err=0; end
if nargin==3, if abs(v)<err, v=0; end, end

spow=[]; 
if nrec>0
   ss2=num2str(v,nrec); k=find(ss2=='e'); 
   if length(k)>0, 
      sss2=ss2(k+1:end); kk=find(sss2>='1' & sss2<='9'); spow=ss2(kk(1)+k:end);
      if eval(sss2)<0, spow=['-' spow]; end
      ss2=[ss2(1:k-1) '\times10^{' spow '}']; key=length(ss2); 
   end
else
   %display in rational format
   [n,d]=rat(v); 
   if n==0, ss2='0';
   elseif d==1, ss2=int2str(n); 
   else, ss2=[int2str(n) '/' int2str(d)]; spow=[]; end
end

%-----------------------------------------------------
%poly2str converts a polynomial into TeX string
%
%   Str_C=poly2str(vec)
%where
%	vec -- is the polynomial to be converted
%  Str_C -- the converted TeX string
%-----------------------------------------------------
function Str_C=poly2str(vec)
Str_C=[];
ii=find(abs(vec)>eps);  order=length(vec)-ii;
for i=1:length(ii)
   if i==1 & (vec(ii(i))>0), ss1=''; 
   elseif (vec(ii(i))>0), ss1='+';
   else, ss1='-'; end
   if abs((abs(vec(ii(i))-1))<1e-10 &order(i)~=0), ss2=[];
   else, ss2=flt2string(abs(vec(ii(i)))); end
   if order(i)==0, ss3=[];
   elseif order(i)==1, ss3='s';
   elseif order(i)<=9, ss3=['s^' int2str(order(i))];
   else, ss3=['s^{' int2str(order(i)) '}']; end
   Str_C=[Str_C ss1 ss2 ss3]; 
end

%---------------------------------------------------------
%info_disp_win initializes the information display window.
%---------------------------------------------------------
function info_disp_win()

h_info=findobj('Tag','CtrlLABInfo');
if length(h_info)==0
   h_info = figure('Units','normalized','Position',[0.47 0.005 0.52625 0.205],...
      'NumberTitle','off','Name','Information Display Window', ...
      'MenuBar','none','Color',0.8*[1,1,1],'Tag','CtrlLABInfo','Resize','off');
   extra_funs(1);
   bButton(1) = uicontrol('Style','PushButton','String','Clear', ...
	   'Units','normalized','Position',[0.833729 0.60 0.142518 0.18], ...
      'Callback','extra_funs(1);');
   bButton(2) = uicontrol('Style','PushButton','String','Modify', ...
	   'Units','normalized','Position',[0.833729 0.39 0.142518 0.18], ...
      'Callback','proc_model(2);');
   bButton(3) = uicontrol('Style','PushButton','String','Show Matrix', ...
	   'Units','normalized','Position',[0.8 0.18 0.19 0.18], ...
      'Visible','off','Callback','matx_proc(get(gco,''UserData''));');
   bButton(4) = uicontrol('Style','Edit','String','', ...
      'Units','normalized','Position',[0.01 0.01 0.98 0.98], ...
      'BackgroundColor',0.8*[1,1,1],'ForegroundColor',[0,0,0],...
      'HorizontalAlignment','left','Visible','off');
   bButton(5)=uicontrol('Style','Slider','Visible','off',...
      'Units','normalized','Position',[0.0001,0.0001,0.7998,0.08],...
      'CallBack','set(gca,''XLim'',[get(gco,''Value'')-0.5,get(gco,''Value'')+0.5]);');
   bButton(6) = uicontrol('Style','PushButton','String','Compare Reduction', ...
	   'Units','normalized','Position',[0.75 0.18 0.24 0.18], ...
      'Visible','off','Callback','mod_reduction;');
   bButton(7) = uicontrol('Style','PushButton','String','SIMULINK Model', ...
	   'Units','normalized','Position',[0.75 0.18 0.24 0.18], ...
      'Visible','off','Callback','proc_model(4);');
   set(h_info,'UserData',bButton);
else
   figure(h_info); uu=get(h_info,'UserData');  
   extra_funs(1);  set(uu([3:7]),'Visible','off');   
end

extra_funs(1,[0.001,0.001,0.798,0.998]);
