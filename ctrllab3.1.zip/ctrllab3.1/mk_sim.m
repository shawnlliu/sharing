function mk_sim()
h_main=figure(findobj('Tag','CtrlLABMain'));
uu0=get(gcf,'UserData'); 
g_model=extra_funs(5,3,'Checked',10:13);   
uu=get(uu0{1}(g_model),'UserData'); %get model name

%getting the linearized model
strMod=uu{3};
[xx,ux,yy,dx]=trim(strMod);
[a,b,c,d]=linmod2(strMod,xx,ux);
uu{2}=ss(a,b,c,d);  

%save system model to the block
set(uu0{1}(g_model),'UserData',uu);

uu0{1}(6)=1; set(h_main,'UserData',uu0);
if g_model==1, ctrllab(0,1); end

%display the linearized model
proc_model(6,uu);
