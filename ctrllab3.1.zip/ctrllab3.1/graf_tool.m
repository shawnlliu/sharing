%graf_tool is a set of functions which can be used to process figure properties.  
%This function can either be used as an individual function:
%
%   graf_tool
%
%or used as part of CrtlLAB:
%
%   graf_tool(nTask,arg1)
%where
%  nTask -- system analysis code, as shown in sys_analysis
%  arg1 -- extra arguments
%
%The functions available in the module are
%
%  figwin_menu -- create menu system on the figure window
%  graf_toolbar --- add toolbar for MATLAB is higher than 5.2.
%  chg_graphs -- change graph properties
%  graf_file -- administrates the File menu 
%  redraw_plot -- re-draw the previously saved plots
%  graf_capture -- extracts the plot elements on the existing plots
%  shifty_plt -- shift the y axis of the plot down or up
%  add_extramenu -- add an extra menu item for system analysis, if required
%

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%---------------------------------------------------------------------------------

function graf_tool(nTask,arg1)

[v,d]=version; v1=eval(v(1)); v2=eval(v(3));
switch nargin
case {0,1}, %initial program interface
   if nargin==0, %when it is used as an independent program
      nTask=3; strWndTitle='GrafTools -- Plot Window'; posPlot=[0.2425 0.232 0.5 0.45]; 
   else %when it is used under CtrlLAB
      WindwName=str2mat('Bode Diagram','Nyquist Plots','Nichols Charts',...
         'Inverse Nyquist Plots','Root Locus','Step Responses',...
         'Impulse Responses','Stability Margins');
      strWndTitle=WindwName(nTask,:); PltWndRect=[0.48625 0.465 0.5 0.467]; 
      rectMod=[0.0188,0.025,0,0]; posPlot=PltWndRect-(nTask-1)*rectMod;               
   end   
   h_win=findobj('Name',strWndTitle);
   if length(h_win)==0, %if there is no such a window, then open a new one
      h_win=figure('Units','normalized','Position',posPlot,...
         'NumberTitle','off','Name',strWndTitle,'MenuBar','none','Color',0.8*[1,1,1],...
         'Tag','CtrlLABFigs','Interruptible','on',...
         'PaperUnits','inch','PaperPosition',[0.15,8,5,3.5]); 
      %the reason why such a PaperPosition argument is set is that the text 
      %size/figure size should be preserved when printed in EPS files.  It 
      %does not have any effect on other copy format.
      if nargin==0, figwin_menu(nTask,[]);   
      else, figwin_menu(nTask); end
      if v1>=5 & v2>=2, 
         set(gcf,'ResizeFcn','graf_tool(3,[]);');
         graf_toolbar([]); set_contxtmenu(5);
      end
   else, figure(h_win); end
case 2   
   switch nTask
   case 0, graf_file(arg1); %processing the File menu
   case 1, chg_graphs(arg1); %taggle graphics properties
   case 2, chg_graphs(arg1,[]); %update graphics properties
   case 3, graf_toolbar(arg1);   
   case 4, %shift down/up the axes
      v=get(gco,'Value'); if v==0, v=-1; end, shifty_plt(v);
   end      
end               

%---------------------------------------------------------------
%figwin_menu is used to create menu system on the figure window.
%---------------------------------------------------------------
function figwin_menu(nTask,arg1)
if nargin==0, nTask=1; end

%buiding the menu system for Graf_Tool

%Build the File menu
hMOptions(2)=uimenu(gcf,'Label','&File');
hMOptions(7)=uimenu(hMOptions(2),'Label','&New','CallBack','graf_tool(1,5);');
hMOptions(50)=uimenu(hMOptions(2),'Label','&Open','CallBack','graf_tool(0,1);');
hMOptions(51)=uimenu(hMOptions(2),'Label','&Save','CallBack','graf_tool(0,2);');
hMOptions(52)=uimenu(hMOptions(2),'Label','Save &As','CallBack','graf_tool(0,3);');
hMOptions(53)=uimenu(hMOptions(2),'Separator','on','Label','Axis and &Grids');
hMOptions(3)=uimenu(hMOptions(53),'Label','with &Grids','Checked','off','CallBack','graf_tool(1,1);');
hMOptions(4)=uimenu(hMOptions(53),'Label','with &Box','Checked','on','CallBack','graf_tool(1,2);');
hMOptions(5)=uimenu(hMOptions(53),'Label','&Hold Figure','Checked','off','CallBack','graf_tool(1,3);');
hMOptions(60)=uimenu(hMOptions(2),'Label','Clear','CallBack','delete(extra_funs(2));');
hMOptions(6)=uimenu(hMOptions(53),'Label','with Square Axis',...
   'Checked','off','Visible','off','CallBack','graf_tool(1,4);');
hMOptions(40)=uimenu(hMOptions(2),'Label','Preferences...','Separator','on','CallBack','plot_proc(1);');
hMOptions(36)=uimenu(hMOptions(2),'Label','Print');
hMOptions(61)=uimenu(hMOptions(36),'Label','Print on Printer','CallBack','plot_proc(19,[]);');
hMOptions(37)=uimenu(hMOptions(36),'Label','Copy as &MetaFile',...
   'Separator','on','CallBack','plot_proc(17,[]);');
hMOptions(38)=uimenu(hMOptions(36),'Label','Copy as &Bitmap','CallBack','plot_proc(18,[]);');
hMOptions(39)=uimenu(hMOptions(36),'Label','Save in Mono &EPS File','CallBack','plot_proc(15,0);');
hMOptions(63)=uimenu(hMOptions(36),'Label','Save in Color &EPS File','CallBack','plot_proc(16,0);');
hMOptions(62)=uimenu(hMOptions(36),'Label','Printer Setup...','Separator','on','CallBack','print -v;');
hMOptions(64)=uimenu(hMOptions(36),'Label','Page Setup...','CallBack','pagedlg;');
hMOptions(41)=uimenu(hMOptions(2),'Label','Close Window','Separator','on','CallBack','close(gcf);');

%Enable square axis format for some cases
if any([2,4,5]==nTask|nargin==2), set(hMOptions(6),'Visible','on'); end

%Build Legends Processing menu
hMOptions(8)=uimenu(gcf,'Label','&Legends');
hMOptions(9)=uimenu(hMOptions(8),'Label','&New Legend','Callback','legd_proc(1);');
hMOptions(10)=uimenu(hMOptions(8),'Label','&Edit Legend','Callback','legd_proc(2);');
hMOptions(11)=uimenu(hMOptions(8),'Label','&Move Legend','Callback','legd_proc(3);');
hMOptions(13)=uimenu(hMOptions(8),'Label','&Add a Line','Callback','legd_proc(5);');
hMOptions(14)=uimenu(hMOptions(8),'Label','Add an Arro&w','Callback','legd_proc(8);');
hMOptions(12)=uimenu(hMOptions(8),'Separator','on','Label','&Delete a Legend','Callback','legd_proc(4);');
hMOptions(42)=uimenu(hMOptions(8),'Label','&Remove All Legends','Callback','legd_proc(9);');
hMOptions(58)=uimenu(hMOptions(8),'Label','&Change a Legend Color','Callback','legd_proc(23);');
hMOptions(7)=uimenu(hMOptions(8),'Label','&Cursor Positioning','Separator','on','CallBack','legd_proc(18);');
hMOptions(15)=uimenu(hMOptions(8),'Label','&Properties ...','Callback','legd_proc(13);');

%Building the Zooming Faciliies menu
hMOptions(16)=uimenu(gcf,'Label','&Zooming');
hMOptions(17)=uimenu(hMOptions(16),'Label','&Zooming','Checked','off','CallBack','plot_proc(1,0,0);');
hMOptions(18)=uimenu(hMOptions(16),'Label','&X-axis Zooming','CallBack','plot_proc(2,0,0);');
hMOptions(19)=uimenu(hMOptions(16),'Label','&Y-axis Zooming','CallBack','plot_proc(3,0,0);');
hMOptions(20)=uimenu(hMOptions(16),'Label','&Full','CallBack','plot_proc(4,0,0);');
hMOptions(21)=uimenu(hMOptions(16),'Label','&User Define...','Separator','on','CallBack','plot_proc(5,0,0);');
   
%Building the Curves Processing menu   
hMOptions(22)=uimenu(gcf,'Label','Curves');
hMOptions(23)=uimenu(hMOptions(22),'Label','&Delete a Certain Curve','CallBack','plot_proc(1,0);');
hMOptions(24)=uimenu(hMOptions(22),'Label','&Change Curve Color','CallBack','plot_proc(2,0);');
hMOptions(25)=uimenu(hMOptions(22),'Label','&Change Curve Line Style');
hMOptions(26)=uimenu(hMOptions(25),'Label','&Solid Line','Checked','on','CallBack','plot_proc(3,0);');
hMOptions(27)=uimenu(hMOptions(25),'Label','&Dash Line','Checked','off','CallBack','plot_proc(4,0);');
hMOptions(28)=uimenu(hMOptions(25),'Label','D&otted Line','Checked','off','CallBack','plot_proc(5,0);');
hMOptions(29)=uimenu(hMOptions(25),'Label','D&ash Dotted Line','Checked','off','CallBack','plot_proc(6,0);');
hMOptions(30)=uimenu(hMOptions(22),'Label','&Change Curve Marker');
hMOptions(31)=uimenu(hMOptions(30),'Label','* Signs','Checked','on','CallBack','plot_proc(7,0);');
hMOptions(32)=uimenu(hMOptions(30),'Label','+ Signs','Checked','off','CallBack','plot_proc(8,0);');
hMOptions(33)=uimenu(hMOptions(30),'Label','o Signs','Checked','off','CallBack','plot_proc(9,0);');
hMOptions(34)=uimenu(hMOptions(30),'Label','x Signs','Checked','off','CallBack','plot_proc(10,0);');
hMOptions(35)=uimenu(hMOptions(30),'Label','. Signs','Checked','off','CallBack','plot_proc(11,0);');
hMOptions(46)=uimenu(hMOptions(30),'Label','Remove Markers','Separator','on','CallBack','plot_proc(12,0);');
hMOptions(43)=uimenu(hMOptions(22),'Label','Line Thickness');
hMOptions(44)=uimenu(hMOptions(43),'Label','Thicker','CallBack','plot_proc(13,0);');
hMOptions(45)=uimenu(hMOptions(43),'Label','Thinner','CallBack','plot_proc(14,0);');
hMOptions(59)=uimenu(hMOptions(22),'Label','Change Plot Range ...',...
   'Separator','on','Visible',extra_funs(6,nargin<2),'CallBack','legd_proc(24);');
hMOptions(47)=uimenu(hMOptions(22),'Label','Line Properties','CallBack','legd_proc(22);');
hMOptions=add_extramenu(nTask,hMOptions);

%Building the Help Facilities menu
hMOptions(1)=uimenu(gcf,'Label','&Help');
hMOptions(49)=uimenu(hMOptions(1),'Label','Help on Graphics Toolbox','CallBack','clab_help(29);');
hMOptions(55)=uimenu(hMOptions(1),'Label','Help on Legends','CallBack','clab_help(21);');
hMOptions(56)=uimenu(hMOptions(1),'Label','Help on Zooming','CallBack','clab_help(20);');
hMOptions(57)=uimenu(hMOptions(1),'Label','Help on Curve Editing','CallBack','clab_help(30);');
hMOptions(48)=uimenu(hMOptions(1),'Label','About Graphics ToolKit ...',...
   'Separator','on','CallBack','clab_help(27);');

%set the uicontrols for legend editting facilities.  The initial status of the
%controls are set to invisible as a start.
hLegd(1)=uicontrol('Style','Edit','String','','Visible','off',...
   'Units','normalized','Position',[0.20,0.9,0.6,0.07],...
   'HorizontalAlignment','left','BackgroundColor',[1,1,1],'Callback','legd_proc(10);');
if any(6:7==nTask), 
   ww=[5,0.001,0.1,1e-3,0.1,5,1,5,1,5];
   set(gcf,'UserData',{hMOptions,[hLegd,0],[],nTask,'',ww});
else
   set(gcf,'UserData',{hMOptions,[hLegd,0],[],nTask});
end
   
%-------------------------------------------------------------------------------------
%graf_toolbar is used to add toolbar to the main graphics window if the version of 
%MATLAB is higher than 5.2.
%-------------------------------------------------------------------------------------
function graf_toolbar(key)
[v,d]=version; v1=eval(v(1)); v2=eval(v(3));
if v1>=5 & v2>=2, 
   yy=get(gcf,'Position'); screen=get(0,'ScreenSize'); 
   ymax=yy(4)*screen(4)-20; xmax=yy(3)*screen(3);
   load ctrllab_cdata; load graf_cdata, 
   yy=[findobj(gcf,'Tag','Tools'); findobj(gcf,'Tag','Toolz')]; 
   if length(yy)==0 & length(key)==0
      uicontrol('Style','Frame','Units','pixels','Position',[1,ymax,xmax,20],...
         'BackgroundColor',0.8*[1,1,1],'ForegroundColor',0.8*[1,1,1],'Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[5,ymax,20,20],...
         'CData',fnew_dat,'CallBack','graf_tool(1,5);','TooltipString','Clear figure','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[25,ymax,20,20],...
         'CData',fopen_dat,'CallBack','graf_tool(0,1);','TooltipString','Load graphs','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[45,ymax,20,20],...
         'CData',fsave_dat,'CallBack','graf_tool(0,2);','TooltipString','Save graphs','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[65,ymax,20,20],...
         'CData',print_dat,'CallBack','plot_proc(19,[]);','TooltipString','Print graphs','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[90,ymax,20,20],...
         'CData',edit_dat,'CallBack','legd_proc(3);','TooltipString','Moving Object','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[110,ymax,20,20],...
         'CData',text_dat,'CallBack','legd_proc(1,[]);','TooltipString','Draw Text','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[130,ymax,20,20],...
         'CData',line_dat,'CallBack','legd_proc(5);','TooltipString','Draw Line','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[150,ymax,20,20],...
         'CData',arrow_dat,'CallBack','legd_proc(8);','TooltipString','Draw Arrow','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[175,ymax,20,20],...
         'CData',zoom_dat,'CallBack','plot_proc(1,0,0);','TooltipString','Zooming','Tag','Toolz');
      uicontrol('Style','PushButton','Units','pixels','Position',[195,ymax,20,20],...
         'CData',zoomx_dat,'CallBack','plot_proc(2,0,0);','TooltipString','Zoom X Axis','Tag','Toolz');
      uicontrol('Style','PushButton','Units','pixels','Position',[215,ymax,20,20],...
         'CData',zoomy_dat,'CallBack','plot_proc(3,0,0);','TooltipString','Zoom Y Axis','Tag','Toolz');
      uicontrol('Style','PushButton','Units','pixels','Position',[235,ymax,20,20],...
         'CData',fzoom_dat,'CallBack','plot_proc(4,0,0);','TooltipString','Full Axis','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[260,ymax,20,20],...
         'CData',cut_dat,'CallBack','plot_proc(20,0);','TooltipString','Delete an Object','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[280,ymax,20,20],...
         'CData',color_dat,'CallBack','legd_proc(26,0);','TooltipString','Change Colour','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[300,ymax,20,20],...
         'CData',curv_dat,'CallBack','legd_proc(30,0);','TooltipString','Edit Curves','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[320,ymax,20,20],...
         'CData',tools_dat,'CallBack','plot_proc(1);','TooltipString','Plot Preferences','Tag','Tools');
      uicontrol('Style','ToggleButton','Units','pixels','Position',[340,ymax,20,20],...
         'CData',shifty_dat,'CallBack','graf_tool(4,[]);','TooltipString','Shift Axes Down','Tag','Tools');
      uicontrol('Style','PushButton','Units','pixels','Position',[375,ymax,20,20],...
         'CData',help_dat,'CallBack','clab_help(27);','TooltipString','About Graphics Toolkit','Tag','Tools');
   elseif length(key)==0, set(yy,'Visible','on');
   else, set(yy,'Visible','off'); end
   if length(key)>0, set(gcf,'ResizeFcn',''); end   
end
   
%-------------------------------------------------------------------------------------
%chg_graphs is used to change graph properties according to users' own specifications.
%-------------------------------------------------------------------------------------
function chg_graphs(nTask,arg1)

%get all the axis handles under current figure window
g_axes=extra_funs(2); uu=get(gcf,'UserData');
if nargin==1
   if nTask~=5, extra_funs(3,uu{1}(2+nTask),'Checked'); end   
end   
yesno=get(uu{1}(nTask+2),'Checked');

switch nTask
case 1, set(g_axes,'XGrid',yesno,'YGrid',yesno); %set the GRID mode on all the graphics
case 2, set(g_axes,'Box',yesno); %set the BOX mode on all the graphics
case 3, %set the HOLD mode on all the graphics
   for i=1:length(g_axes), axes(g_axes(i)); eval(['hold ',yesno]); end   
case 4, %set the SQUARE/NORMAL mode on all the graphics
   if strcmp(yesno,'on'), axis('square'); else, axis('normal'); end   
case 5, delete(g_axes); %clear the current graphics window
end      

%-------------------------------------------------------
%graf_file -- administrates the File menu
%-------------------------------------------------------
function g=graf_file(nTask,arg1)

uu=get(gcf,'UserData'); 
switch nTask
case 1, %Open file and redraw graphs
   u_prompt='*.grf';
   if length(uu)>=5, u_prompt=[uu{5},u_prompt]; end
   [filename,filepath]=uigetfile(u_prompt,'Please Specify the File Name');
   if ~isa(filename,'double')
      str=[filepath,filename]; uu{3}=str; uu{5}=filepath;
      eval(['load(str, ''-mat'');']); set(gcf,'UserData',uu); redraw_plot(Graf_Dat);
   end   
case 2, %Save current graphs to a file
   if nargin==1, Graf_Dat=graf_capture; 
   else, Graf_Dat=arg1; end
   key=0; 
   if length(uu)>=3, 
      if length(uu{3})>0, key=1; eval(['save(uu{3},''Graf_Dat'')']); end
   end   
   if key==0, graf_file(3,Graf_Dat); end   
case 3, %Save current graphs to a new file
   if nargin==1, Graf_Dat=graf_capture; 
   else, Graf_Dat=arg1; end
   u_prompt='*.grf'; uu
   if length(uu)>=5, u_prompt=[uu{5},u_prompt]; end
   [filename,filepath]=uiputfile(u_prompt,'Please Specify the File Name');
   if ~isa(filename,'double')
      uu{3}=[filepath,filename]; uu{5}=filepath;
      set(gcf,'UserData',uu); graf_file(2,Graf_Dat);   
   end   
end      

%-------------------------------------------------------------------------------
%redraw_plot -- from the saved data to draw the plot of a previously saved plot.
%-------------------------------------------------------------------------------
function redraw_plot(g)

delete(extra_funs(2)); %delete all current axes

%find the number of new axes
nCol1=g{1}(1:3); nCol2=g{1}(4:6); nCol3=g{1}(7:9);
set(gcf,'Color',nCol1); [nr,nc]=size(g);
for i=2:nr
   %for each of the axes, redraw the plot
   pos=g{i}.Pos; h=axes('Position',pos(1:4));  
   set(h,'XColor',nCol2,'YColor',nCol2,'Color',nCol3,'Xlim',pos(5:6),'Ylim',pos(7:8));
   set(h,'Box',g{i}.fBox,'XGrid',g{i}.fXGrid,'YGrid',g{i}.fYGrid,'XScale',g{i}.fX,'YScale',g{i}.fY);
   x=g{i}.Dat; [nr0,nc0]=size(x);
   for j=1:nc0
      if length(x{j})==9, %draw a text
         Pos=x{j}{1}; x0=Pos(1); y0=Pos(2);
         str=x{j}{2}; nCol=x{j}{3}; vis=x{j}{4}; nFSize=x{j}{5}; 
         fName=x{j}{6}; fWeight=x{j}{7}; fAngle=x{j}{8}; fRot=x{j}{9}; 
         [xL,h]=display_str(x0,y0,str,nCol,vis,nFSize,fName,fWeight,fAngle);
         set(h,'Rotation',fRot);
      elseif length(x{j})==8, %draw a line
         x0=x{j}{1}; y0=x{j}{2}; nCol=x{j}{3}; vis=x{j}{4}; fStyle=x{j}{5};
         fMarker=x{j}{6}; fWidth=x{j}{7}; fUserDat=x{j}{8}; h=line(x0,y0); 
         set(h,'Color',nCol','Visible',vis,'LineStyle',fStyle,'Marker',fMarker,...
            'LineWidth',fWidth,'UserData',fUserDat);
      end   
   end
   g0=g{i}.XLab; pos=g0{1}; str=g0{2}; hh=xlabel(str); set(hh,'Position',pos);
   g0=g{i}.YLab; pos=g0{1}; str=g0{2}; hh=ylabel(str); set(hh,'Position',pos);
   g0=g{i}.Lab; pos=g0{1}; str=g0{2}; hh=title(str); set(hh,'Position',pos);
end

%------------------------------------------------------------------------------------
%graf_capture -- extracts the plot elements, axes, line and text only on the existing
%plots.  The information will be returned in a variable g using the following syntax
%
%   g=graf_capture()
%------------------------------------------------------------------------------------
function g=graf_capture()

g={[get(gcf,'Color'),get(gca,'XColor'),get(gca,'Color')]};
ii=extra_funs(2); %get all the axis handles under current figure window

for i=1:length(ii)
   %for each axis handle, capture all the information of the graphics 
   %elements under it.
   %(1) the general properties of the axis
   g{i+1,1}=ii(i); h=ii(i); axes(h);
   g{i+1}.Pos=[get(h,'Position'),get(h,'XLim'),get(h,'YLim')];
   g{i+1}.fBox=get(h,'Box'); g{i+1}.fXGrid=get(h,'XGrid'); g{i+1}.fYGrid=get(h,'YGrid');
   g{i+1}.fX=get(h,'XScale'); g{i+1}.fY=get(h,'YScale'); 
   g0=get(gca,'xlabel'); pos=get(g0,'Position'); str=get(g0,'String'); g{i+1}.XLab={pos,str};
   g0=get(gca,'ylabel'); pos=get(g0,'Position'); str=get(g0,'String'); g{i+1}.YLab={pos,str};
   g0=get(gca,'title'); pos=get(g0,'Position'); str=get(g0,'String'); g{i+1}.Lab={pos,str};
   %(2) the general properties of the lines
   h_lines=extra_funs(2,'line',1); DD=[]; j=0;
   for j=1:length(h_lines)
      DD{j}{1}=get(h_lines(j),'XData'); DD{j}{2}=get(h_lines(j),'YData'); 
      DD{j}{3}=get(h_lines(j),'Color'); DD{j}{4}=get(h_lines(j),'Visible');
      DD{j}{5}=get(h_lines(j),'LineStyle'); DD{j}{6}=get(h_lines(j),'Marker');
      DD{j}{7}=get(h_lines(j),'LineWidth'); DD{j}{8}=get(h_lines(j),'UserData');
   end
   %(3) the general properties of the text
   if length(j)==0, j=0; end; j0=j; 
   h_texts=extra_funs(2,'text',1);
   for j=1:length(h_texts)
      DD{j+j0}{1}=get(h_texts(j),'Position'); DD{j+j0}{2}=get(h_texts(j),'String'); 
      DD{j+j0}{3}=get(h_texts(j),'Color'); DD{j+j0}{4}=get(h_texts(j),'Visible');
      DD{j+j0}{5}=get(h_texts(j),'FontSize'); DD{j+j0}{6}=get(h_texts(j),'FontName');
      DD{j+j0}{7}=get(h_texts(j),'FontWeight'); DD{j+j0}{8}=get(h_texts(j),'FontAngle');
      DD{j+j0}{9}=get(h_texts(j),'Rotation');
   end   
   g{i+1}.Dat=DD;
end

%------------------------------------------------------------------------------------
%shifty_plt -- shift the y axis of the plot down or up
%------------------------------------------------------------------------------------
function shifty_plt(key)
drw_dat=graf_capture;
for i=2:length(drw_dat)
   pos=drw_dat{i}.Pos; pos(2)=pos(2)-0.04*key; drw_dat{i}.Pos=pos;
end
redraw_plot(drw_dat);

%---------------------------------------------------------------------------
%add_extramenu -- add an extra menu item for simulation analysis, if required.
%---------------------------------------------------------------------------
function h=add_extramenu(nTask,h)
switch nTask
case 1
   h(65)=uimenu(h(22),'Label','Add Asymptotics','CallBack','sys_analysis(14);');
case 2,
   h(65)=uimenu(h(22),'Label','ATAN Nyquist Plots','CallBack','sys_analysis(15);');
case 5
   h(65)=uimenu(h(22),'Label','Add Asymptotics','CallBack','sys_analysis(16);');
case {6,7}
   h_main=findobj('Tag','CtrlLABMain');
   key=0; uu0=get(h_main,'UserData');
   for i=1:3, 
      g1=get(uu0{1}(i),'UserData');   
      if length(g1)>0, if g1{1}==4, key=1; break; end, end
   end      
   %check whether nonlinearity/delay is involved in system.  If yes, then allow
   %simulation parameters specifications
   if key==1, 
      h(65)=uimenu(h(22),'Label','Simulation Parameters','CallBack','sys_analysis;');
   end   
end
