%sys_design is the function used in CtrlLAB for administrating system design tasks.
%
%Available Design Tasks are:
%
%  1 for lead/lag compensator design
%  2 for LQ optimal regulator/controller
%  3 for pole placement regulator/controller
%  4 for model following control
%  5 for LQG control
%  6 for LQG/LTR control
%  7 for H2 optimal control
%  8 for H_inf standard control
%  9 for H_inf optimal control
% 10 for mu-synthesis (not available now)
%
%Besides, PID controller designs are in a separate module.
%
%Available lists of functions under this module
%
%  leadlag_design -- lead-lag compensator design 
%  ll_compn -- the lead-lag compensator design algorithm
%  state_fdbk -- administrates the state-feedback 
%  model_follow - the model following compensator design
%  lqgltr_design -- LQG and LQG/LTR controller design
%  robust_design -- administrates robust controller design facilities
%  std_tf -- find the standard transfer function
%  get_tf -- find the transfer function from N/D strings
%  shw_controller -- set and display the controller
%

%Designed by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%This module is for CtrllAB 3.0, (c) 1996-1999
%Last modified 16 October, 1999
%------------------------------------------------------------------------------

function sys_design(nTask,arg1,arg2)

switch nTask
case 1
   if nargin==1, lead_lag_design(nTask);
   else, lead_lag_design(1,arg1); end
case {2,3}
   if nargin==1, state_fdbk(nTask);
   else, state_fdbk(2,arg1); end
case 4
   if nargin==1, model_follow(nTask);
   else, model_follow(nTask,arg1); end
case {5,6}
   if nargin==1, lqgltr_design(nTask);
   else, lqgltr_design(5,arg1); end
case {7,8,9,10}
   switch nargin
   case 1, robust_design(nTask);
   case 2, robust_design(7,arg1); 
   case 3, robust_design(7,arg1,arg2); 
   end
otherwise
     
end      

%----------------------------------------------
%leadlag_design for lead-lag compensator design 
%----------------------------------------------
function lead_lag_design(nTask, arg1)

%show the lead-lag controller dialog box
if nargin==1
   g_leadlag=findobj('Tag','CtrlLABLeadLag');
   if length(g_leadlag)==0 
      g_leadlag=figure('Units','normalized','Position',[0.18625 0.248 0.375 0.267],...
         'MenuBar','none','Color',0.8*[1,1,1],'Resize','off','Tag','CtrlLABLeadLag',...
         'NumberTitle','off','Name','Lead/Lag Controller Specifications','Resize','off');
      extra_funs(1); display_str(0.03,0.90,'Phase Margin \gamma',[0,0,0],'on',9);
      uicontrol('Tag','Gam','Style','Edit','String','50',...
         'Units','normalized','Position',[0.45,0.83,0.22,0.13],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      display_str(0.03,0.72,'Crossover Frequency \omega_c',[0,0,0],'on',9);
      uicontrol('Tag','Wc','Style','Edit','String','1',...
         'Units','normalized','Position',[0.45,0.65,0.22,0.13],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      display_str(0.03,0.54,'Error Coefficient K_v',[0,0,0],'on',9);
      uicontrol('Tag','Kv','Style','Edit','String','10',...
         'Units','normalized','Position',[0.45,0.47,0.22,0.13],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      display_str(0.03,0.36,'Compensator Type',[0,0,0],'on',9);
      uicontrol('Tag','Lst','Style','ListBox','String','Auto|Lead|Lag|Leag-Lag',...
         'Units','normalized','Position',[0.40,0.04,0.29,0.37],...
         'Value',1,'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      uicontrol('Style','PushButton','String','Design',...
         'Units','normalized','Position',[0.75,0.80,0.22,0.15],'CallBack','sys_design(1,1);');
      uicontrol('Style','PushButton','String','Cancel',...
         'Units','normalized','Position',[0.75,0.62,0.22,0.15],'CallBack','delete(gcf);');
      uicontrol('Style','PushButton','String','Help',...
         'Units','normalized','Position',[0.75,0.44,0.22,0.15],'Callback','clab_help(10)');
      uicontrol('Style','PushButton','String','Maximise Wc',...
         'Units','normalized','Position',[0.73,0.10,0.26,0.15],'CallBack','sys_design(1,2);');
   else, figure(g_leadlag); end
else
   g0=gcf;
   g_Gam=findobj(g0,'Tag','Gam'); g_Wc=findobj(g0,'Tag','Wc');
   g_Kv=findobj(g0,'Tag','Kv'); g_list=findobj(g0,'Tag','Lst');
   Gam_c=eval(get(g_Gam,'String')); Wc=eval(get(g_Wc,'String')); 
   Kv=eval(get(g_Kv,'String')); kLeagLag=get(g_list,'Value')-1;
   uu0=get(findobj('Tag','CtrlLABMain'),'UserData'); 
   g1=get(uu0{1}(1),'UserData'); G_Sys=tf(g1{2}); 
   g4=get(uu0{1}(4),'UserData'); Td=g4{1}; 
   if arg1==1
      Gc_Sys=ll_compn(Wc,Gam_c,Kv,kLeagLag,G_Sys,Td); shw_controller(Gc_Sys);
   else arg1==2
      GGc_tmp=num2str(Gam_c); GGW_tmp=num2str(Wc); GGK_tmp=num2str(Kv);
      key=1; W1=0.01; W2=1000; Gc1=ll_compn(W1,Gam_c,Kv,kLeagLag,G_Sys,Td);
      [Gm,P1,Wcg,Wcp]=margin(Gc1*G_Sys);
      Gc2=ll_compn(W2,Gam_c,Kv,kLeagLag,G_Sys,Td);
      [Gm,P2,Wcg,Wcp]=margin(Gc2*G_Sys); PP=[]; d=10;
      if P2>(1-0.05)*Gam_c, key=0; Wc=1000; end
      ww=[]; ii=0;
      while (key==1)
         Wc=10^((log10(W1)+log10(W2))/2); Gcn=ll_compn(Wc,Gam_c,Kv,kLeagLag,G_Sys,Td);
         [Gm,P0,Wcg,Wcp]=margin(Gcn*G_Sys); 
         ww=[ww;W1,W2,P1,P2,Wc,P0]; PP=[PP;P1,P2,P0,W1,W2,Wc,d];
         if xor((P1>0.95*Gam_c),(P0>0.95*Gam_c)), 
            d=(W2-Wc); W2=Wc; P2=P0; ii=ii+1;
         elseif xor((P0>0.95*Gam_c),(P2>0.95*Gam_c)), 
            d=(Wc-W1); W1=Wc; P1=P0; ii=ii+1;
         end
         if abs(d)<0.001, key=0; end
      end
      set(g_Wc,'String',num2str(Wc));
   end
end   

%--------------------------------------------------------------
%ll_compn implements the lead-lag compensator design algorithm.
%
%  G2=ll_compn(Wc,Gam_c,Kv,kLeadLag,G1,Td)
%where 
%  G2 -- the designed controller
%  Wc -- expected cross-over frequency
%  Gam_c -- expected phase margin
%  Kv -- the steady state error tolerance
%  kLeadLag -- the format of lead/lag controller
%  G1,Td -- the plant model with delay
%--------------------------------------------------------------
function G2=ll_compn(Wc,Gam_c,Kv,kLeadLag,G1,Td)

[G_n,G_d]=tfdata(G1,'v'); [Gai,Pha]=bode(G1,Wc); Pha=Pha-Td*Wc*180/pi;
Phi_c=sin((Gam_c-Pha-180)*pi/180); a=G_d(end:-1:1); ii=find(abs(a)<=0); 
if length(ii)>0
   if ii(1)>1, a=a(ii(1)+1); else, a=a(ii(1)+1); end
else, a=a(1); end;
alpha=sqrt((1-Phi_c)/(1+Phi_c)); Zc=alpha*Wc; Pc=Wc/alpha;
Kc=sqrt((Wc*Wc+Pc*Pc)/(Wc*Wc+Zc*Zc))/Gai; K1=G_n(end)*Kc*alpha/a;

%set the leag/lag compensator mode
if kLeadLag==0,
   kLeadLag=1; if Phi_c<0, kLeadLag=2; else, if K1<Kv, kLeadLag=3; end, end
end

if kLeadLag==1, G2=tf([1 Zc]*Kc,[1 Pc]); 
elseif kLeadLag==2, Kc=1/Gai; K1=G_n(end)*Kc/a; G2=tf([1 0.1*Wc],[1 0.1*K1*Wc/Kv]); 
elseif kLeadLag==3
   Zc2=Wc*0.1; Pc2=K1*Zc2/Kv; G2=tf(Kc*conv([1 Zc],[1,Zc2]),conv([1 Pc],[1,Pc2])); 
end

%--------------------------------------------------------------
%state_fdbk administrates the state-feedback compensator design
%
%   state_fdbk(nTask,arg1)
%where
%   nTask=2 for LQ, 3 for pole placement
%--------------------------------------------------------------
function state_fdbk(nTask,arg1)
uu0=get(findobj('Tag','CtrlLABMain'),'UserData'); g1=get(uu0{1}(1),'UserData'); 
G_Sys=tf(g1{2}); n=length(G_Sys.den{1})-1;
if nargin==1
   g_state=findobj('Tag','CtrlLABStateFdbk');
   if length(g_state)==0
      g_state=figure('Units','normalized','Position',[0.18625 0.248 0.45 0.367],...
         'NumberTitle','off','Name','State Spece Design','Tag','CtrlLABStateFdbk',...
         'MenuBar','none','Color',0.8*[1,1,1],'Resize','off');
      extra_funs(1); hh=extra_funs(10,[0.04,0.05],[0.52,0.38]);
      uicontrol('Style','Text','String','Feedback Scheme',...
         'Units','normalized','Position',[0.06,0.34,0.33,0.06],'BackgroundColor',0.8*[1,1,1]);
      [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
      if v2==2 & v3==0, strRadio='ToggleButton'; else, strRadio='RadioButton'; end 
      ud2(1)=uicontrol('Style',strRadio,'String','State Feedback','Value',1,...
         'Units','normalized','Position',[0.07,0.23,0.38,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(2,1);');
      ud2(2)=uicontrol('Style',strRadio,'String','Observer-based','Value',0,...
         'Units','normalized','Position',[0.07,0.14,0.38,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(2,2);');
      [xL,ud2(3)]=display_str(0.05,0.65,'Expected Poles for Observer',[0,0,0],'off',9);
      tmpPVec='['; for i=1:n, tmpPVec=[tmpPVec, '-10; ']; end
      tmpPVec=[tmpPVec(1:end-2), ']'];  
      ud2(4)=uicontrol('Style','Edit','String',tmpPVec,'Visible','off',...
         'Units','normalized','Position',[.08 .50 .6 .09],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      if nTask==2
         tmpQMat='diag(['; for i=1:n, tmpQMat=[tmpQMat, '1, ']; end
         tmpQMat=[tmpQMat(1:end-2), '])'];  
         txtVec=['Enter Q matrix, while R=1  (order of system=',int2str(n),')'];
         [xL,ud2(5)]=display_str(0.05,0.94,txtVec,[0,0,0],'on',9);
         ud2(6)=uicontrol('Style','Edit','String',tmpQMat,...
            'Units','normalized','Position',[.08 .74 .6 .09],...
            'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      elseif nTask==3
         txtVec=['Expected poles (order of system=',int2str(n),')'];
         [xL,ud2(5)]=display_str(0.05,0.94,txtVec,[0,0,0],'on',9);
         tmpVVec='[';  
         for i=1:n, tmpVVec=[tmpVVec, '-10, ']; end
         tmpVVec=[tmpVVec(1:end-2), ']'];  
         ud2(6)=uicontrol('Style','Edit','String',tmpVVec,...
            'Units','normalized','Position',[.08 .79 .6 .09],...
            'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      end
      uicontrol('Style','PushButton','String','Design',...
         'Units','normalized','Position',[0.80,0.84,0.18,0.11],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(2,4);');
      uicontrol('Style','PushButton','String','Cancel',...
         'Units','normalized','Position',[0.80,0.71,0.18,0.11],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','delete(gcf);');
      uicontrol('Style','PushButton','String','Help',...
         'Units','normalized','Position',[0.80,0.58,0.18,0.11],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(2,3);');
      ud2(7)=nTask; set(g_state,'UserData',ud2);   
   else, figure(g_state); end
else
   ud2=get(gcf,'UserData'); nTask=ud2(7); 
   switch arg1
   case 1
      extra_funs(4,1,'Value',1,2); set(ud2(3:4),'Visible','off');
   case 2
      extra_funs(4,1,'Value',2,1); set(ud2(3:4),'Visible','on');
   case 3, clab_help(9+nTask)
   case 4, [a,b,c,d]=ssdata(g1); nA=size(a); Q=eval(get(ud2(6),'String'));
      if nTask==2
         nQ=size(Q); if sum(nQ==nA)==2, K_fdbk=lqr2(a,b,Q,1); end
      elseif nTask==3
         if length(Q)==nA(1), K_fdbk=acker(a,b,Q); end
      end
      if get(ud2(1),'Value')==1, L_vec=zeros(size(b));
      else   
         P=eval(get(ud2(4),'String'));
         if nA(1)==length(P), L_vec=acker(a',c',P)'; end
      end
      Gc_Sys=ss(a-b*K_fdbk-L_vec*c-L_vec*d*K_fdbk,b,-K_fdbk,1);
      H_Sys=ss(a-L_vec*c,L_vec,K_fdbk,0); shw_controller(Gc_Sys,H_Sys);
      display_str(0.05,0.28,'State Feedback Vector');
      display_str(0.08,0.13,mat2str(K_fdbk,5));
   end   
end

%------------------------------------------------------------------------
%model_follow function implements the model following compensator design.
%------------------------------------------------------------------------
function model_follow(nTask,arg1)

uu0=get(findobj('Tag','CtrlLABMain'),'UserData'); g1=get(uu0{1}(1),'UserData');
[G_num,G_den,Td]=tfdata(g1{2},'v');
ii=find(abs(G_num)>1e-8); G_num=G_num(ii(1):end);
n_ord=length(G_den)-length(G_num); nn=n_ord;
g4=get(uu0{1}(4),'UserData'); Td=g4{1}; nPade=g4{2};
if nargin==1
   g_model=findobj('Tag','CtrlLABModelFollow');
   if length(g_model)==0 
      g_model=figure('Units','normalized','Position',[0.18625 0.248 0.45 0.333],...
         'NumberTitle','off','Name','Model Following Control Design','Tag','CtrlLABModelFollow',...
         'MenuBar','none','Color',0.8*[1,1,1],'Resize','off');
      extra_funs(1);
      aWMats(1)=uicontrol('Style','PushButton','String','Design',...
         'Units','normalized','Position',[0.80,0.84,0.18,0.12],'CallBack','sys_design(4,4);');
      aWMats(2)=uicontrol('Style','PushButton','String','Cancel',...
         'Units','normalized','Position',[0.80,0.7,0.18,0.12],'CallBack','delete(gcf);');
      aWMats(3)=uicontrol('Style','PushButton','String','Help',...
         'Units','normalized','Position',[0.80,0.54,0.18,0.12],'CallBack','clab_help(25);');
      [xL,cWMats(1)]=display_str(0.1,0.83,'Order of Standard Model:',[0,0,0],'on',9);
      [xL,cWMats(9)]=display_str(0.1,0.70,'Expected Natrual Freq \omega_n',[0,0,0],'on',9);
      cWMats(2)=uicontrol('Style','Edit','String',num2str(nn),...
         'Units','normalized','Position',[0.53,0.78,0.10,0.08],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
      if v2==2 & v3==0, strRadio='ToggleButton'; else, strRadio='RadioButton'; end 
      cWMats(3)=uicontrol('Style',strRadio,'String','ITAE Type I','Value',1,...
         'Units','normalized','Position',[0.12,0.40,0.30,0.07],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],...
         'CallBack','extra_funs(4,3,''Value'',3,4:5);');
      cWMats(4)=uicontrol('Style',strRadio,'String','ITAE Type II','Value',0,...
         'Units','normalized','Position',[0.12,0.29,0.30,0.07],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(4,1);');
      cWMats(5)=uicontrol('Style',strRadio,'String','Butterworth Model','Value',0,...
         'Units','normalized','Position',[0.12,0.18,0.35,0.07],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],...
         'CallBack','extra_funs(4,3,''Value'',5,3:4);');
      cWMats(6)=uicontrol('Style','Edit','String','10',...
         'Units','normalized','Position',[0.49,0.65,0.10,0.08],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1]);
      cWMats(7)=extra_funs(10,[0.10,0.13],[0.58,0.55]);
      cWMats(8)=uicontrol('Style','Text','String','Standard Model Selection',...
         'Units','normalized','Position',[0.12,0.52,0.4,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1]);
      cWMats(10)=uicontrol('Style','Text','String','Transfer Function to follow',...
         'Units','normalized','Position',[0.05,0.90,0.50,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],'Visible','off');
      cWMats(11)=uicontrol('Style','Edit','String',mat2str(1),...
         'Units','normalized','Position',[0.08 0.60 0.5 0.09],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],'Visible','off');
      cWMats(12)=uicontrol('Style','Edit','String',mat2str([1,1]),...
         'Units','normalized','Position',[0.08,0.30,0.5,0.09],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],'Visible','off');
      [xL,cWMats(13)]=display_str(0.05,0.72,'Numerator Array',[0,0,0],'off',9);
      [xL,cWMats(14)]=display_str(0.05,0.42,'Denominator Array',[0,0,0],'off',9);
      bWMats(1)=extra_funs(10,[0.62,0.13],[0.97,0.42]);
      bWMats(2)=uicontrol('Style','Text','String','Reference Model',...
         'Units','normalized','Position',[0.64,0.40,0.25,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1]);
      bWMats(3)=uicontrol('Style',strRadio,'String','Standard','Value',1,...
         'Units','normalized','Position',[0.64,0.30,0.25,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(4,2);');
      bWMats(4)=uicontrol('Style',strRadio,'String','User Specified','Value',0,...
         'Units','normalized','Position',[0.64,0.20,0.31,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(4,3);');
      set(gcf,'UserData',{aWMats,bWMats,cWMats});
   else, figure(g_model); end   
else
   u_c=get(gcf,'UserData');
   switch arg1
   case 1
      extra_funs(4,3,'Value',4,[3,5]); nn=eval(get(u_c{3}(2),'String'));
      if n_ord>nn-1, set(u_c{3}(2),'String',int2str(n_ord+1)); end
   case 2, extra_funs(4,2,'Value',3,4); extra_funs(4,3,'Visible',[1:9],[10:14]);
   case 3, extra_funs(4,2,'Value',4,3); extra_funs(4,3,'Visible',[10:14],[1:9]);
   case 4, 
      [nn,dd]=tfdata(G_Sys,'v');
      if Td>0, [nP,dP]=pade(Td,nPade); nn=conv(nn,nP); dd=conv(dd,dP); end
      if get(u_c{2}(3),'Value')==1
         n=eval(get(u_c{3}(2),'String')); wn=eval(get(u_c{3}(6),'String'));
         bStdModel=extra_funs(5,3,'Value',3:5); [mf_num,mf_den]=std_tf(bStdModel,wn,n); 
      else, Gc=get_tf(1); [mf_num,mf_den]=tfdata(Gc,'v'); end,
      nn=mf_num; dd=mf_den-[zeros(1,length(mf_den)-length(mf_num)),mf_num];
      Gc_Sys=tf(nn,dd)*inv(G_Sys); shw_controller(Gc_Sys);
   end  
end   

%--------------------------------------------------------------------
%lqgltr_design implements the LQG and LQG/LTR controller design tasks
%
%   lqgltr_design(nTask,arg1)
%where nTask=5 for LQG and 6 for LQG/LTR
%--------------------------------------------------------------------
function lqgltr_design(nTask,arg1)
uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
g1=get(uu0{1}(1),'UserData'); G_Sys=tf(g1{2}); 
if nargin==1
   n=length(G_Sys.den{1})-1; g_lqgltr=findobj('Tag','CtrlLABLQGLTR');
   if length(g_lqgltr)==0
      g_lqgltr=figure('Units','normalized','Position',[0.24625 0.267 0.4 0.333],...
         'NumberTitle','off','Name','LQG/LTR Control Design','Tag','CtrlLABLQGLTR',...
         'MenuBar','none','Color',0.8*[1,1,1],'Resize','off');
      extra_funs(1); display_str(0.05,0.75,'Optimal Control Weighting Matrix Q',[0,0,0],'on',9);
      tmpQMat='diag(['; for i=1:n, tmpQMat=[tmpQMat, '1, ']; end
      tmpQMat=[tmpQMat(1:end-2), '])'];  
      aWMats(2)=uicontrol('Style','Edit','String',tmpQMat,...
         'Units','normalized','Position',[0.08 0.58 0.6 0.1],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      [xL,aWMats(5)]=display_str(0.05,0.43,'the Value of \Xi',[0,0,0],'on',9);
      aWMats(3)=uicontrol('Style','Edit','String','1e-3',...
         'Units','normalized','Position',[0.3 0.39 0.2 0.1],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      [xL,aWMats(6)]=display_str(0.05,0.25,'the Value of \Theta',[0,0,0],'on',9);
      aWMats(7)=uicontrol('Style','Edit','String','1e-6',...
         'Units','normalized','Position',[0.3 0.22 0.2 0.1],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      if nTask==6
         tmpqVec='[1,1e5,1e10,1e15]';
         [xL,aWMats(4)]=display_str(0.05,0.95,'Recovery Gain Vector q',[0,0,0],'on',9);
         aWMats(1)=uicontrol('Style','Edit','String',tmpqVec,...
            'Units','normalized','Position',[0.08 0.80 0.6 0.1],...
            'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      end
      extra_funs(10,[0.56,0.10],[0.98,0.42]);
      uicontrol('Style','Text','String',' Problem Specifications',...
         'Units','normalized','Position',[0.59,0.39,0.35,0.06],'BackgroundColor',0.8*[1,1,1]);
      [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
      if v2==2 & v3==0, strRadio='ToggleButton'; else, strRadio='RadioButton'; end 
      aWMats(8)=uicontrol('Style',strRadio,'String','Regulator Problem','Value',1,...
         'Units','normalized','Position',[0.59,0.28,0.32,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','extra_funs(4,1,''Value'',8,9);');
      aWMats(9)=uicontrol('Style',strRadio,'String','Controllor Problem','Value',0,...
         'Units','normalized','Position',[0.59,0.18,0.31,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','extra_funs(4,1,''Value'',9,8);');
      uicontrol('Style','PushButton','String','Design',...
         'Units','normalized','Position',[0.80,0.84,0.18,0.12],'CallBack','sys_design(5,1);');
      uicontrol('Style','PushButton','String','Cancel',...
         'Units','normalized','Position',[0.80,0.70,0.18,0.12],'CallBack','delete(gcf);');
      uicontrol('Style','PushButton','String','Help',...
         'Units','normalized','Position',[0.80,0.56,0.18,0.12],'CallBack','sys_design(5,2);');
      aWMats(10)=nTask;
      set(g_lqgltr,'UserData',aWMats);
   else, figure(g_lqgltr); end
else
   aWMats=get(gcf,'UserData');
   switch arg1
   case 1
      robust_design(7,1);
   case 2   
      if aWMats(8)==5, clab_help(16);
      else, clab_help(17); end
   end   
end   

%-------------------------------------------------------------------------
%robust_design function administrates LQG, LQG/LTR and H-norm based robust 
%controller design facilities.
%
%  robust_design(nTask,arg1,arg2)
%where nTask is as described as above.
%-------------------------------------------------------------------------
function robust_design(nTask,arg1,arg2)

uu0=get(findobj('Tag','CtrlLABMain'),'UserData'); g1=get(uu0{1}(1),'UserData');
G_Sys=tf(g1{2}); [G_num,G_den]=tfdata(G_Sys,'v');
n_ord=length(G_den)-length(G_num); nn=n_ord;
g4=get(uu0{1}(4),'UserData'); Td=g4{1}; nPade=g4{2};  
switch nargin
case 1
   g_hinf=findobj('Tag','CtrlLABHinf');
   if length(g_hinf)==0 
      g_hinf=figure('Units','normalized','Position',[0.18625 0.248 0.45 0.417],...
         'NumberTitle','off','Name','Robust Control Design','Tag','CtrlLABHinf',...
         'MenuBar','none','Color',0.8*[1,1,1],'Resize','off');
      extra_funs(1);
      [xL,bWMats(1)]=display_str(0.05,0.94,'Weighting Transfer Function W_1(s)',[0,0,0],'on',9);
      aWMats(1)=uicontrol('Style','Edit','String',mat2str([0.5,0.5]),...
         'Units','normalized','Position',[0.08 0.82 0.4 0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      aWMats(2)=uicontrol('Style','Edit','String',mat2str([0.5,1]),...
         'Units','normalized','Position',[0.08,0.74,0.4,0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      [xL,bWMats(2)]=display_str(0.05,0.70,'Weighting Transfer Function W_2(s)',[0,0,0],'on',9);
      aWMats(3)=uicontrol('Style','Edit','String',mat2str([0.5,1]),...
         'Units','normalized','Position',[0.08 0.58 0.4 0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      aWMats(4)=uicontrol('Style','Edit','String',mat2str([0.5,0.5]),...
         'Units','normalized','Position',[0.08,0.50,0.4,0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      [xL,bWMats(3)]=display_str(0.05,0.46,'Weighting Transfer Function W_3(s)',[0,0,0],'on',9);
      aWMats(5)=uicontrol('Style','Edit','String',mat2str([0.5,0.5]),...
         'Units','normalized','Position',[0.08 0.34 0.4 0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      aWMats(6)=uicontrol('Style','Edit','String',mat2str([0.5,1]),...
         'Units','normalized','Position',[0.08,0.26,0.4,0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      bWMats(4)=uicontrol('Style','PushButton','String','Design',...
         'Units','normalized','Position',[0.52,0.85,0.15,0.09],'CallBack','sys_design(7,1);');
      bWMats(5)=uicontrol('Style','PushButton','String','Cancel',...
         'Units','normalized','Position',[0.68,0.85,0.15,0.09],'CallBack','delete(gcf);');
      bWMats(6)=uicontrol('Style','PushButton','String','Help',...
         'Units','normalized','Position',[0.84,0.85,0.15,0.09],'CallBack','clab_help(18);');
      [xL,cWMats(1)]=display_str(0.03,0.85,'Order of Standard Model:',[0,0,0],'off',9);
      [xL,cWMats(9)]=display_str(0.03,0.75,'Expected Natrual Freq \omega_n',[0,0,0],'off',9);
      cWMats(2)=uicontrol('Style','Edit','String','3','Visible','off',...
         'Units','normalized','Position',[0.37,0.81,0.10,0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
      if v2==2 & v3==0, strRadio='ToggleButton'; else, strRadio='RadioButton'; end 
      cWMats(3)=uicontrol('Style',strRadio,'String','ITAE Type I','Visible','off','Value',1,...
         'Units','normalized','Position',[0.05,0.49,0.30,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],...
         'CallBack','extra_funs(4,3,''Value'',3,4:5);');
      cWMats(4)=uicontrol('Style',strRadio,'String','ITAE Type II','Value',0,'Visible','off',...
         'Units','normalized','Position',[0.05,0.39,0.30,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(7,3);');
      cWMats(5)=uicontrol('Style',strRadio,'String','Butterworth Model','Value',0,'Visible','off',...
         'Units','normalized','Position',[0.05,0.29,0.35,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],...
         'CallBack','extra_funs(4,3,''Value'',5,3:4);');
      cWMats(6)=uicontrol('Style','Edit','String','10','Visible','off',...
         'Units','normalized','Position',[0.37,0.70,0.10,0.07],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      cWMats(7)=extra_funs(10,[0.04,0.26],[0.5,0.62],'off');
      cWMats(8)=uicontrol('Style','Text','String',' Standard Model Selection',...
         'Units','normalized','Position',[0.06,0.59,0.38,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1],'Visible','off');
      if nTask==10
         [xL,bWMats(10)]=display_str(0.05,0.10,'Frequency Vector',[0,0,0],'on',9);
         aWMats(7)=uicontrol('Style','Edit','String','logspace(-1,1)',...
            'Units','normalized','Position',[0.08 0.10 0.6 0.07],...
            'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
      end
      bWMats(10)=extra_funs(10,[0.05,0.03],[0.82,0.18]);
      bWMats(11)=uicontrol('Style','Text','String','Show Magnitude Plots',...
         'Units','normalized','Position',[0.28,0.16,0.37,0.06],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1]);
      bWMats(7)=uicontrol('Style','PushButton','String','W1(s)','Tag','1',...
         'Units','normalized','Position',[0.10,0.05,0.2,0.09],'CallBack','sys_design(7,5,1);');
      bWMats(8)=uicontrol('Style','PushButton','String','W2(s)','Tag','2',...
         'Units','normalized','Position',[0.33,0.05,0.2,0.09],'CallBack','sys_design(7,5,2);');
      bWMats(9)=uicontrol('Style','PushButton','String','W3(s)','Tag','3',...
         'Units','normalized','Position',[0.56,0.05,0.2,0.09],'CallBack','sys_design(7,5,3);');
      bWMats(12)=extra_funs(10,[0.54,0.495],[0.97,0.74]);
      bWMats(13)=uicontrol('Style','Text','String','Problem Specifications',...
         'Units','normalized','Position',[0.56,0.71,0.35,0.06],'BackgroundColor',0.8*[1,1,1]);
      bWMats(14)=uicontrol('Style',strRadio,'String','Sensitivity','Value',0,...
         'Units','normalized','Position',[0.57,0.63,0.25,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(7,6);');
      bWMats(15)=uicontrol('Style',strRadio,'String','Mixed-sensitivity','Value',1,...
         'Units','normalized','Position',[0.57,0.54,0.31,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','sys_design(7,7);');
      bWMats(18)=extra_funs(10,[0.54,0.495],[0.97,0.25]);
      bWMats(16)=uicontrol('Style',strRadio,'String','Regulator Problem','Value',1,...
         'Units','normalized','Position',[0.57,0.40,0.30,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','extra_funs(4,2,''Value'',16,17);');
      bWMats(17)=uicontrol('Style',strRadio,'String','Control Problem','Value',0,...
         'Units','normalized','Position',[0.57,0.30,0.31,0.06],...
         'BackgroundColor',0.8*[1,1,1],'CallBack','extra_funs(4,2,''Value'',17,16);');
      set(g_hinf,'UserData',{aWMats,bWMats,cWMats,nTask});
   else, figure(g_hinf); end
case 2
   u_c=get(gcf,'UserData');
   if length(u_c)==10, nTask=u_c(10); bRegulate=get(u_c(8),'Value');
   else, nTask=u_c{4}; bRegulate=get(u_c{2}(16),'Value'); end
   switch arg1
   case 1
      if Td>0, [nP,dP]=pade(Td,nPade); tf_G=G_Sys*tf(nP,dP);  end   
      [Ax,Bx,Cx,Dx]=ssdata(G_Sys); 
      if any([7:10]==nTask)
         if get(u_c{2}(14),'Value')==1
            n=eval(get(u_c{3}(2),'String')); wn=eval(get(u_c{3}(6),'String'));
            bStdModel=extra_funs(5,3,'Value',3:5); 
            [nn,dd]=std_tf(bStdModel,wn,n); w1_num=dd; 
            w1_den=dd-[zeros(1,length(dd)-length(nn)),nn]; w1_den(end)=1e-5;
            w2_num=1e-5; w2_den=1; w3_num=[]; w3_den=[];
         else
            wtmp_Sys=get_tf(1); [w1_num,w1_den]=tfdata(wtmp_Sys,'v')
            wtmp_Sys=get_tf(2); [w2_num,w2_den]=tfdata(wtmp_Sys,'v')
            wtmp_Sys=get_tf(3); [w3_num,w3_den]=tfdata(wtmp_Sys,'v')
            if nTask==9, w_vec=eval(get(aWMats(7),'String')); end
         end
      else
         Qmat=eval(get(u_c(2),'String')); Xi=eval(get(u_c(3),'String'));
         Theta=eval(get(u_c(7),'String')); nA=size(Ax); nQ=size(Qmat); 
         if sum(nA==nQ)<2 
            warndlg('Matrices not match, try again!','Warning: Design failed!');
         end
      end
      bBiLin=0; [z,p,k]=zpkdata(G_Sys,'v');
      if any(abs(real(p))<1e-8), Ax=Ax+0.1*eye(size(Ax)); bBiLin=1; end
      Sys=mksys(Ax,Bx,Cx,Dx);
      switch nTask
      case 5
         W=diagmx(Qmat,1); V=diagmx(Xi*Bx*Bx',Theta); ss_f=lqg(Sys,W,V);
      case 6
         w=logspace(-2,2); q_vec=eval(get(u_c(1),'String')); 
         Kc=lqr2(Ax,Bx,Qmat,1); gg=gcf;  graf_tool(2); 
         bHold=0; if ishold, bHold=1; end, hold on
         ss_f=ltru(Sys,Kc,Xi,Theta,q_vec,w);
         if bHold==0, hold off; end
         figure(gg);
      case {7,8,9,10}
         w1=[zeros(1,length(w1_den)-length(w1_num)) w1_num;
             zeros(1,length(w1_num)-length(w1_den)) w1_den];
         w2=[zeros(1,length(w2_den)-length(w2_num)) w2_num;
             zeros(1,length(w2_num)-length(w2_den)) w2_den];
         w3=[zeros(1,length(w3_den)-length(w3_num)) w3_num;
             zeros(1,length(w3_num)-length(w3_den)) w3_den];
         extra_funs(12,'Please wait for controller design...'); pause(0.0001)
         Tss_=augtf(Sys,w1,w2,w3); 
         switch nTask
         case 7, ss_f=h2lqg(Tss_);
         case 8, ss_f=hinf(Tss_);
         case 9, [rho_opt,ss_f]=hinfopt(Tss_,1);
         case 10, ss_f=musyn(Tss_,w_vec);
         end
      end
      [Af,Bf,Cf,Df]=branch(ss_f);
      if bBiLin==1, Af=Af-0.1*eye(size(Af)); end
      if any([7:10]==nTask), close(gcf); end
      if bRegulate==1
         Gc_Sys=ss(Af,Bf,Cf,Df); shw_controller(Gc_Sys);
      else      
         if nTask>=7,
            [A,B,C,D]=branch(Tss_); C=C'; D=D(1,1);
         else, [A,B,C,D]=ssdata(ss_G); end   
         Gc_Sys=ss(Af,B,-Cf,1);
         H_Sys=ss(Af,Bf,Cf,0); shw_controller(Gc_Sys,H_Sys);
      end
      if nTask==9
         display_str(0.1,0.35,['\rho','_{optimal} =',display_str(rho_opt)]);
      end
   case 3
      extra_funs(4,3,'Value',4,[3,5]); nn=eval(get(u_c{3}(2),'String'));
      if n_ord>nn-1,
         set(u_c{3}(2),'String',int2str(n_ord+1));
      end
   case 5, wtmp_Sys=get_tf(arg2);
   case 6
      extra_funs(4,2,'Value',14,15); set(u_c{2}([1:3,8:9]),'Visible','off');
      set(u_c{1}(1:6),'Visible','off'); set(u_c{3}(1:9),'Visible','on');
   case 7   
      extra_funs(4,2,'Value',15,14); set(u_c{2}([1:3,8:9]),'Visible','on');
      set(u_c{1}(1:6),'Visible','on'); set(u_c{3}(1:9),'Visible','off');
   end
case 3,
   aWMats=get(gcf,'UserData');
   key=eval(get(gco,'Tag'));
   num=eval(get(aWMats{1}(2*key-1),'String')); den=eval(get(aWMats{1}(2*key),'String')); 
   G_W=tf(num,den); graf_tool(1); sys_analysis(1,G_W,[]);
end
      
%-----------------------------------------------------
%std_tf is used to find the standard transfer function
%-----------------------------------------------------
function [nn,dd]=std_tf(id,wn,n)
Dat_Tab{1}=[1,1,0,0,0,0,0; 1,1.41,1,0,0,0,0; 
            1,1.75,2.15,1,0,0,0; 1,2.1,3.4,2.7,1,0,0; 
            1,2.8,5.0,5.5,3.4,1,0; 1,3.25,6.6,8.6,7.45,3.95,1];
Dat_Tab{2}=[1,3.2,1,0,0,0,0; 1,1.75,3.25,1,0,0,0; 
            1,2.41,4.93,5.14,1,0,0; 1,2.19,6.5,6.3,5.24,1,0; 
            1,6.12,13.42,17.16,14.14,6.76,1];
Dat_Tab{3}=[1,1,0,0,0,0,0; 1,1.4,1,0,0,0,0; 1,2,2,1,0,0,0;
            1,2.6,3.4,2.6,1,0,0; 1,3.24,5.24,5.24,3.24,1,0; 
            1,3.86,7.46,9.13,7.46,3.86,1];

if n>6, warndlg('The selected order is too high!','Warning: Design failed!');
else   
   dd=Dat_Tab{id}(n,1:n+1).*(wn*ones(1,n+1)).^[0:n]; nn=dd(n+1); 
   if id==2, nn=dd(n:n+1); end
end
   
%-------------------------------------------------------------------------
%get_tf is used to find the transfer function from the given numerator and 
%denominator strings
%
%   G1=get_tf(keyMod)
%where
%  keyMod=1,2,3 for W1(s), W2(s), W3(s), respectively
%  G1 -- the weighting function entered
%-------------------------------------------------------------------------
function W_Sys=get_tf(keyMod)
aWMats=get(gcf,'UserData'); key=0; 
if isa(aWMats,'cell'), aWMats=aWMats{1}; key=1; end
vec1=get(aWMats(2*(keyMod-1)+1),'String'); vec2=get(aWMats(2*keyMod),'String'); 
W_Sys=proc_model(2,vec1,vec2); 

%---------------------------------------------------------------------------
%shw_controller set the controller to the system and display the results in 
%information window
%
%  shw_controller(Gc_Sys,H_Sys)
%where
%  Gc_Sys and H_Sys are controller and feedback model,  respectively.  
%---------------------------------------------------------------------------
function shw_controller(Gc_Sys,H_Sys)
close(gcf); 
figure(findobj('Tag','CtrlLABMain')); uu0=get(gcf,'UserData'); 
extra_funs(4,3,'Checked',[11,23],[10,12,13,20:22]);
set(uu0{4}(26),'Enable','on','Checked','on');
if isa(Gc_Sys,'ss')
   [a,b,c,d]=ssdata(Gc_Sys); 
   set(uu0{1}(2),'UserData',{2,Gc_Sys,mat2str(a),mat2str(b),mat2str(c),num2str(d)});
else
   [nn,dd]=tfdata(Gc_Sys,'v'); 
   set(uu0{1}(2),'UserData',{1,Gc_Sys,mat2str(nn),mat2str(dd)});
end 
if nargin==2
   if isa(H_Sys,'ss')
      [a,b,c,d]=ssdata(H_Sys); 
      set(uu0{1}(3),'UserData',{2,H_Sys,mat2str(a), mat2str(b),mat2str(c),num2str(d)});
   else
      [nn,dd]=tfdata(H_Sys,'v');
      set(uu0{1}(3),'UserData',{1,H_Sys,mat2str(nn),mat2str(dd)});
   end
else, set(uu0{1}(3),'UserData',[]); end   

%display controller and set properties with controllers to enable
ctrllab(0,2); proc_model(1);
