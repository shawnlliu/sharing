%proc_model manipulates system models.  The syntax of the function is 
%
%   W_Sys=proc_model(nTask,g_model,key,arg1,arg2,arg3)
%where 
%   nTask -- the task code for model processing, details of it can be found 
%          in the function
%   g_model -- the model code
%   key -- if there are three input arguments it is used to enter a model 
%          from num, den strings.  In this case, a model W_Sys is returned
%   arg1,arg2,arg3 -- extra auguments, used in display system realizations
%
%The functions available in the module are
%
%  disp_model -- displays the system models.  
%  disp_rattf --- displays transfer function in fractional format
%  zp2disp  --- displays transfer function in factorized format
%  pzeros2str  --- get the string for factorized polynomial
%  get_model -- get the model from the GUI
%  new_model -- displays the new model entering GUI
%  chg_model_type -- allows one to change model format
%  enter_model -- allows one to enter system model
%  get_poly -- converts a polynomial 's' string into a vector
%  poly_evl -- a supporting function for get_poly
%  build_simu -- provide an template of SIMULINK model
%  mk_sim -- process and display the SIMULINK model entered
%  is_delay -- checks whether there is delay in the whole system
%  is_simu -- checks whether there is delay in the whole system
%  clear_model -- clears the current model
%

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%This module is used only with CtrlLAB.
%-----------------------------------------------------------------------------

function W_Sys=proc_model(nTask,g_model,key,arg1,arg2,arg3)

switch nTask
case 0,
   %process system model
   if nargin==3,
      uu0=get(findobj('Tag','CtrlLABMain'),'UserData'); 
      uu=get(uu0{1}(g_model),'UserData');
   else, uu=get(gco,'UserData'); end
   ii=[10:13]; 
   extra_funs(4,3,'Checked',9+g_model,ii(find(ii~=9+g_model))); 
   %check the existance of model of the block
   key=1; 
   if length(uu)==0, key=0; %model dose not exist
   elseif uu{1}==4 & length(uu{2})==0, key=0; %simulink type model dose not exist
   end 
   %if model dose not exist, then enter it
   if key==0, get_model(g_model); %if model dose not exist, then enter it
   else, disp_model(g_model, uu); %otherwise, display it
   end
case 1, %display system model
   switch nargin
      case 1, disp_model;
      case 2, disp_model(g_model);   
      case 6, disp_model(g_model,key,arg1,arg2,arg3); 
   end      
case 2, %call get_model function
   switch nargin
      case 1, get_model;
      case 2, get_model(g_model);   
      case 3, W_Sys=enter_model(g_model,key);
   end      
case 3, mk_sim; %call function to process and display SIMULINK blocks
case 4, disp_model(7); %display the SIMULINK model
case 5, clear_model;
case 6, disp_model(6,g_model); %display the linearized model
case 7, W_Sys=is_delay; %check whether there is delay in the whole system
case 8, W_Sys=is_simu; %check whether there is SIMULINK model in the whole system
case 9, %display error message
   warn_msg=str2mat('              IMPORTANT NOTICE',...
      'Due to the problem in SIMULINK, one should',...
      'not click this button to get the system model.',...
      'Instead, he should type mk_sim in MATLAB',...
      'command window.');
   warndlg(warn_msg,'Warning: SIMULINK bug.  Try this');
end
   
%----------------------------------------------------------------------------------
%disp_model displays the system models.  The syntax of the function is 
%
%   disp_model(g_model,uu,c,d,key)
%where 
%      g_model is the key code of the model to display, if g_model=5 then the 
%         reduced model is displayed.
%      uu is the model itself.
%      c,d is the the c vector and d constant in the state space format, if entered.
%      key is the format for realizations
%-----------------------------------------------------------------------------------
function disp_model(g_model,uu,c,d,key)

h_main=findobj('Tag','CtrlLABMain');
figure(h_main); uu0=get(h_main,'UserData');
g4=get(uu0{1}(4),'UserData');

if nargin==5
   n_disp=2; uu=ss(g_model,uu,c,d); g_model=1;
   switch key
   case 1, str_model='Controllability realization';
   case 2, str_model='Observability realization';
   case 3, str_model='Modal realization';
   case 4, str_model='Minimal realization';   
   case 5, str_model='Balanced realization';   
   end
else   
   if nargin==0, 
      g_model=extra_funs(5,3,'Checked',10:13); uu=get(uu0{1}(g_model),'UserData');
      if length(uu)==0, return; end
   elseif nargin==1
      if g_model==5, uu=g4{4};
      elseif g_model==7,
         %display the SIMULINK model
         g_model=extra_funs(5,3,'Checked',10:13); uu_s=get(uu0{1}(g_model),'UserData');
         if exist(uu_s{3})==4, open_system(uu_s{3})
         else, 
            warndlg('SIMULINK model no longer exist','Warning: Model failed!');
            set(uu0{1}(g_model),'UserData',[]);
         end   
         return;
      else, uu=get(uu0{1}(g_model),'UserData'); end   
   end   
   
   switch g_model
   case 1, str_model='Plant model';
   case 2, str_model='Controller model';
   case 3, str_model='Feedback model';
   case 4, str_model='Delay model';  
   case 5, str_model='Reduced order model';   
   case 6, str_model='Linearized model';   
   end
   vec=get(uu0{3}(20:23),'Checked');
   for n_disp=1:4, if strcmp(vec{n_disp},'on'), break; end, end
   if any([1,2,3,6]==g_model), uu=uu{2}; end
end   
display_str; display_str(0.1,0.9,str_model); 
if g_model==4
   display_str(0.1,0.6,['e^{-' num2str(uu{1}), 's}']);
   display_str(0.1,0.4,['Order of Pade Approximation is ' int2str(uu{2})]);
else   
   switch n_disp
   case 1, g_sys=tf(uu); xL=disp_rattf(0.1,0.61,g_sys);
   case 2, g_sys=ss(uu);
      xL(1)=display_str(0.04,0.7,['A: ',mat2str(g_sys.a,4)]);
      xL(2)=display_str(0.04,0.5,['B^T: ',mat2str(g_sys.b,4)]);   
      xL(3)=display_str(0.04,0.3,['C: ',mat2str(g_sys.c,4)]);   
      display_str(0.04,0.1,['D: ',display_str(g_sys.d,4)]);   
      uu_a=get(gcf,'UserData'); set(uu_a(3),'UserData',g_sys,'Visible','on');
   case 3, xL=[]; [z,p,k]=zpkdata(uu,'v');
      display_str(0.04,0.65,['Gain: ' display_str(k)]);
      display_str(0.04,0.51,'Zeros: '); xL(1)=display_str(0.15,0.51,z,0);
      display_str(0.04,0.36,'Poles: '); xL(2)=display_str(0.15,0.36,p,0);
   case 4, xL=zp2disp(0.1,0.61,uu);
   end
   if g_model==1,
      if g4{1}>0 & any([1,4]==n_disp), 
         display_str(xL,0.61,[' e^{-' display_str(g4{1}) 's}']); 
      end
   elseif g_model==5
      if g_sys.InputDelay>0 & any([1,4]==n_disp),
         display_str(xL,0.61,[' e^{-' display_str(g_sys.InputDelay) 's}']); 
      end
   elseif g_model==6, bb=get(gcf,'UserData'); set(bb(7),'Visible','on');
   end   
   if g_model<=3, g_x=get(uu0{1}(g_model),'UserData');
      if g_x{1}==4, bb=get(gcf,'UserData'); set(bb(7),'Visible','on'); end   
   end   
end

%--------------------------------------------------------------------------------
%disp_rattf displays the system model in rational fraction format.  The syntax of
%the function is
%
%   xL=disp_rattf(a0,b0,tf_mod)
%where a and b are the starting point of display, tf_mod is the model to be 
%displayed wchi should be given in transfer function format.  The variable xL 
%returns the x-coordinate of the display.
%--------------------------------------------------------------------------------
function xL=disp_rattf(a0,b0,tf_mod)
[num,den]=tfdata(tf_mod,'v'); vec_n=display_str(num); vec_d=display_str(den);
width1=extra_funs(7,vec_n)/66; width2=extra_funs(7,vec_d)/66;
xx=0.12; if length(find(vec_d)=='^')==0, xx=0.08; end
maxLength=a0+0.5*max(width1,width2);
xL1=display_str(maxLength-0.5*width1,b0+0.07,vec_n);
xL2=display_str(maxLength-0.5*width2,b0-xx,vec_d);
xL=max(xL1,xL2); h=line([a0,xL],[b0 b0]); set(h,'Color',[0,0,0]);

%----------------------------------------------------------------------------------
%zp2disp displays the system model in factorized transfer functions.  The syntax of
%the function is
%
%   xL=zp2disp(x,y,tf_mod)
%where x and y are the starting point of display, tf_mod is the model to be 
%displayed wchi should be given in pole-zero-gain format.  The variable xL returns 
%the x-coordinate of the display.
%----------------------------------------------------------------------------------
function xL=zp2disp(x,y,tf_mod)
[z,p,k]=zpkdata(tf_mod,'v'); 
xL0=display_str(x,y,display_str(k)); vec_p=pzeros2str(p); a0=xL0;
if length(z)==0, vec_z='1';
else, vec_z=pzeros2str(z); end
width1=extra_funs(7,vec_p)/66; width2=extra_funs(7,vec_z)/66;
maxLength=xL0+0.5*max(width1,width2); xL=maxLength-0.5*width2;
xL1=display_str(xL,y+0.08,vec_z); xL=maxLength-0.5*width1;
xx=0.12; if length(find(vec_p=='^'))==0, xx=0.08; end
xL2=display_str(xL,y-xx,vec_p); xL=max(xL2,xL1);
h=line([a0,xL],[y y]); set(h,'Color',[0,0,0]);

%-------------------------------------------------------------------------------
%pzeros2str converts a factorized polynomial into a string.
%
%   Str_C=pzeros2str(z)
%where z contains all the zeros of the polynomial.  The returned variable Str_C 
%is the string converted.
%-------------------------------------------------------------------------------
function Str_C=pzeros2str(z);
Str_C=[];
if length(z)>0
   [xx,ii]=sort(real(z)); z=z(ii,:); order=ones(length(z),1); vec1=[];  ss1=0;
   for i=1:length(z), 
      ii=find(abs(vec1-z(i,:))<1e-8); 
      if length(ii)>0, order(ii(1))=order(ii(1))+1; order(i)=0; end
      vec1=[vec1, z(i,:)];
   end
   ii=find(imag(z)<0); order(ii)=zeros(size(ii)); k0=find(abs(z)<1e-10); k=length(k0);
   if k>0, 
      Str_C=[Str_C,'s'];
      if k>1, Str_C=[Str_C '^{' int2str(k) '}']; end
      order(k0(1))=0;
   end
   for i=1:length(z), 
      if order(i)>0
         vecc='-'; if real(z(i))<0, vecc='+'; end, Str_C=[Str_C '(s']; 
         if abs(real(z(i)))>1e-8, 
            ssx=display_str(real(z(i)));
            if real(z(i))<0, ssx=ssx(2:end); end
            Str_C=[Str_C vecc ssx];
         end
         if imag(z(i))>1e-8, Str_C=[Str_C '\pm' display_str(imag(z(i))) 'i']; end
         Str_C=[Str_C ')'];
         if order(i)>1, Str_C=[Str_C '^{' int2str(order(i)) '}']; end
      end 
   end 
end

%-------------------------------------------------------
%get_model get the model from the user through the GUI.
%
%   W_Sys=get_model(g_model,arg1)
%-------------------------------------------------------
function W_Sys=get_model(g_model,arg1)

switch nargin
case 0, new_model;
case 1,
   if g_model==0, chg_model_type;
   elseif g_model==-1, enter_model; 
   else, new_model; end
end

%-------------------------------------------------------
%new_model displays the new model entering GUI.
%-------------------------------------------------------
function new_model(keyVis)

if nargin==0, keyVis='on'; end

figure(findobj('Tag','CtrlLABMain')); uu=get(gcf,'UserData');
g_model=extra_funs(5,3,'Checked',10:13); uu0=get(uu{1}(g_model),'UserData');

%set the model entering mode to its original
if length(uu0)==0, u_type=1; else, u_type=uu0{1}; end
key=0;
if u_type==4, if exist(uu0{3})==4, key=1; else, key=-1; end, end   
if key==0
   %enter the system model again
   g_mod=findobj('Name','Enter system model'); k0=g_mod;
   if length(g_mod)==0
      g_mod = figure('Units','normalized','Position',[0.259 0.358 0.435 0.275], ...
         'MenuBar','none','Color',[0.8 0.8 0.8],'Visible',keyVis,'Tag','CtrlLABExtras', ...
         'NumberTitle','off','Name','Enter System Model','Resize','off');
      extra_funs(1);
      b(1)=uicontrol('Style','PushButton','String','Apply',...
         'Units','normalized','Position',[0.80 0.78 0.17 0.14],'CallBack','proc_model(2,-1);');
      b(2)=uicontrol('Style','PushButton','String','Cancel',...
         'Units','normalized','Position',[0.80 0.60 0.17 0.14],'CallBack','delete(gcf)');
      b(3)=uicontrol('Style','PushButton','String','Help',...
         'Units','normalized','Position',[0.80 0.42 0.17 0.14],'Callback','clab_help(1);');
      b(14)=uicontrol('Style','PushButton','String','Clear Model',...
         'Units','normalized','Position',[0.74 0.24 0.23 0.14],'CallBack','proc_model(5);');
      [x,b(4)]=display_str(0.05,0.93,'Numerator Polynomial',[0,0,0],'on',9);
      b(5)=uicontrol('Style','Edit','String','[1]',...
         'Units','normalized','Position',[0.09 0.75 0.63 0.115], ...
  	      'BackgroundColor',[1 1 1],'HorizontalAlignment','left');
      [x,b(6)]=display_str(0.05,0.68,'Denominator Polynomial',[0,0,0],'on',9);
      b(7) = uicontrol('Style','Edit','String','[1,1]',...
         'Units','normalized','Position',[0.09 0.50 0.63 0.115], ...
  	      'BackgroundColor',[1 1 1],'HorizontalAlignment','left');
      [x,b(8)]=display_str(0.52,0.12,'Other Type',[0,0,0],'on',9);
      if g_model==4, u_type=1; end
      b(9) = uicontrol('Style','PopupMenu','Value',u_type, ...
     	   'String','Transfer Function|State Space|Pole-zero-gain|SIMULINK', ...
         'Units','normalized','Position',[0.70 0.05 0.27 0.12], ...
     	   'BackgroundColor',0.8*[1,1,1],'CallBack','proc_model(2,0);');
      [x,b(10)]=display_str(0.05,0.43,'C Matrix',[0,0,0],'off',9);
      b(11) = uicontrol('Style','Edit','String','[1]', ...
         'Units','normalized','Position',[0.09 0.25 0.63 0.115],...
         'BackgroundColor',[1 1 1],'HorizontalAlignment','left','Visible','off');
      [x,b(12)]=display_str(0.05,0.11,'D Constant',[0,0,0],'off',9);
      b(13) = uicontrol('Style','Edit','String','[0]', ...
         'Units','normalized','Position',[0.24 0.05 0.15 0.115], ...
  	      'HorizontalAlignment','left','BackgroundColor',[1 1 1],'Visible','off');
      uu={1,b,g_model};
   else
      %get the code of the model
      figure(g_mod); uu=get(g_mod,'UserData'); uu{3}=g_model; 
   end
   set(g_mod,'UserData',uu); chg_model_type;
   if length(k0)==0
      ii=findobj('Tag','CtrlLABError_E');
      if length(ii)>0, set(ii,'UserData',g_mod); figure(ii); end
   end   
elseif key==1, open_system(uu0{3})   
elseif key==-1
   ii=findobj('Tag','CtrlLABError_E'); close(ii);
   warn_msg=str2mat('Sorry, the SIMLINK model no longer exist now.',...
      'You should start building it again.  To prevent ',...
      'future lose of model, you should save it before ','exiting from SIMULINK.');
   warndlg(warn_msg,'Warning: Model failed!');
   set(uu{1}(g_model),'UserData',[]); new_model('off');
end

%-------------------------------------------------------
%chg_model_type allows one to change model format
%-------------------------------------------------------
function chg_model_type(n)

uu=get(gcf,'UserData'); b=uu{2}; g_model=uu{3}; u_type=get(b(9),'Value'); 
h_main=findobj('Tag','CtrlLABMain'); uu0=get(h_main,'UserData');
ii=1:4; i=find(ii~=u_type);
set(uu0{3}(15+ii(i)),'Checked','off'); set(uu0{3}(15+u_type),'Checked','on');
uu1=get(h_main,'UserData'); u_model=uu1{1}(g_model); u_data=get(u_model,'UserData');
if g_model==4
   %sets the display/model entering to the delay block
   extra_funs(4,2,'Visible',[4:7],[10:13]);
   set(b(4),'String','Delay constant'); set(b(6),'String','Order of Pade Approximation');
   if length(u_data)==0, set(b(5),'String','1'); set(b(7),'String','3');
   else, set(b(5),'String',num2str(u_data{1})); set(b(7),'String',int2str(u_data{2})); end      
else   
   switch u_type
   case 1,  %set the transfer function input boxes
      extra_funs(4,2,'Visible',[4:7],[10:13]);
      set(b(4),'String','Numerator polynomial'); set(b(6),'String','Denominator Polynomial');
      if length(u_data)==0
         %if no model pre-exist, then set defaults
         set(b(5),'String','[1]'); set(b(7),'String','[1,1]');
      else   
         if u_data{1}==1
            %if TF model exists, then fill the data
            set(b(5),'String',u_data{3}); set(b(7),'String',u_data{4});
         else
            %if other model exists, then fill the data
            [num,den]=tfdata(u_data{2},'v');
            set(b(5),'String',mat2str(num)); set(b(7),'String',mat2str(den));
         end   
      end   
   case 2, %set the state space model input boxes
      set(b([4:7,10:13]),'Visible','on'); set(b(4),'String','Coefficient Matrix A');
      set(b(6),'String','Vector B'); set(b(10),'String','Vector C');
      if length(u_data)==0
         set(b(5),'String','[-1]'); set(b(7),'String','[1]');
         set(b(11),'String','[1]'); set(b(13),'String','[0]');
      else   
         if u_data{1}==2
            set(b(5),'String',u_data{3}); set(b(7),'String',u_data{4});
            set(b(11),'String',u_data{5}); set(b(13),'String',u_data{6});
         else
            g_mod=ss(u_data{2});
            set(b(5),'String',mat2str(g_mod.a)); set(b(7),'String',mat2str(g_mod.b));
            set(b(11),'String',mat2str(g_mod.c)); set(b(13),'String',mat2str(g_mod.d));
         end   
      end   
   case 3, %set the pole-zero-gain model input boxes
      extra_funs(4,2,'Visible',[4:7,10:11],[12:13]);
      set(b(4),'String','Zeros of the System'); set(b(6),'String','Poles of the System');
      set(b(10),'String','Gain');
      if length(u_data)==0
         set(b(5),'String','[]'); set(b(7),'String','[-1]'); set(b(11),'String','[1]');
      else   
         if u_data{1}==3
            set(b(5),'String',u_data{3}); set(b(7),'String',u_data{4}); set(b(11),'String',u_data{5});
         else
            [z,p,k]=zpkdata(u_data{2},'v'); set(b(5),'String',mat2str(z)); 
            set(b(7),'String',mat2str(p)); set(b(11),'String',mat2str(k));
         end   
      end   
   case 4, %set the SIMULINK model input boxes
      extra_funs(4,2,'Visible',[4:5],[6:7,10:13]); set(b(4),'String','SIMULINK Model Name');
      %check whether a SIMULINK model is present
      key=0;
      if length(u_data)>0, key=(u_data{1}==4); end
      if key==1, strMod=u_data{3}; %if exists, use the original model name
      else,   
         %if new, create a new model name
         i=0;
         while (1)
            if exist(['my_model',int2str(i)])~=4, break; end
            i=i+1;   
         end
         strMod=['my_model',int2str(i)];  
      end   
      set(b(5),'String',strMod);
   end
   uu{1}=u_type; set(gcf,'UserData',uu);
end

%-------------------------------------------------------
%enter_model allows one to enter system model
%
%   W_sys=enter_model(num_str,den_str)
%-------------------------------------------------------
function W_sys=enter_model(num_str,den_str)

h_main=findobj('Tag','CtrlLABMain');
if nargin==0
   figure(findobj('Name','Enter System Model'));
   uu=get(gcf,'UserData'); b=uu{2}; g_model=uu{3}; 
   uu=get(h_main,'UserData'); u_model=uu{1}(g_model);
   u_data=get(u_model,'UserData'); uu{1}(5)=g_model; set(h_main,'UserData',uu);
   
   key_model=0;
   if g_model==4, %enter the delay model
      Td=eval(get(b(5),'String')); nPade=eval(get(b(7),'String'));
      set(u_model,'UserData',{Td,nPade,[],[]}); u_type=0;
   else   
      u_type=get(b(9),'Value');
      switch u_type
      case 1
         num_str=get(b(5),'String'); den_str=get(b(7),'String');
         i1=find(num_str=='s'); i2=find(den_str=='s');
         if length(i1)==0, num=eval(num_str); 
         else, num=get_poly(num_str); end   
         if length(i2)==0, den=eval(den_str);
         else, den=get_poly(den_str); end
         num=real(num); den=real(den); 
         if nargout==0 & length(num)>length(den)
            key_model=1;
            errordlg('System not realizable, order of num higher than den!','Model enter failed!');
         else   
            g_sys=tf(reshape(num,1,length(num)),reshape(den,1,length(den)));
            set(u_model,'UserData',{1,g_sys,num_str,den_str});
         end   
      case 2
         A_str=get(b(5),'String'); B_str=get(b(7),'String');
         C_str=get(b(11),'String'); D_str=get(b(13),'String');
         A=real(eval(A_str)); B=real(eval(B_str)); 
         C=real(eval(C_str)); D=real(eval(D_str));
         str=abcdchk(A,B,C,D);
         if length(str)>0, 
            key_model=1; errordlg(str,'Model enter failed!');
         else   
            g_sys=ss(A,B,C,D); set(u_model,'UserData',{2,g_sys,A_str,B_str,C_str,D_str});
         end   
      case 3
         z_str=get(b(5),'String'); p_str=get(b(7),'String'); k_str=get(b(11),'String');
         z=eval(z_str); p=eval(p_str); k=eval(k_str);
         g_sys=zpk(reshape(z,length(z),1),reshape(p,length(p),1),k);
         set(u_model,'UserData',{3,g_sys,z_str,p_str,k_str});
      case 4
         sys_str=get(b(5),'String'); build_simu(sys_str);
         set(u_model,'UserData',{4,[],sys_str});
      end
   end  
   if key_model==0
      close(gcf);
      if u_type~=4
         uu{1}(6)=1; set(h_main,'UserData',uu);
         if g_model==1, ctrllab(0,1); elseif g_model==2, ctrllab(0,2); end
         disp_model(g_model, get(u_model,'UserData'));
      end   
   end   
else
   i1=find(num_str=='s'); i2=find(den_str=='s');
   if length(i1)==0, num=eval(num_str); else, num=get_poly(num_str); end   
   if length(i2)==0, den=eval(den_str); else, den=getpoly(den_str); end
   W_sys=tf(reshape(num,1,length(num)),reshape(den,1,length(den)));
end

%-------------------------------------------------------
%get_poly converts a polynomial 's' string into a vector
%
%   [array,ikey]=get_poly(string)
%where 
%  string -- the 's' string representing a polynomial
%  array -- the vector converted
%  ikey -- if 1, then an error occur in conversion.
%-------------------------------------------------------
function [array,ikey]=get_poly(string)

string=string(find(string~=' ')); ikey=1;  nLen=length(string); array=1;
ii=find(string=='('); ij=find(string==')');
if length(ii)~=length(ij),
   warndlg('( and ) mismatching, string error!','Warning: Model failed!'); 
else, ii=[ii length(string)+1]; 
   if (ii(1)~=1), [array,ikey]=poly_evl(string(1:ii(1)-1)); end
   for i=1:length(ii)-1, 
      [array1,ikey]=poly_evl(string(ii(i)+1:ij(i)-1));
      if i~=length(ii), 
         if (ii(i+1)-1~=ij(i)), 
            k0 = str2num(string(ij(i)+1:ii(i+1)-1));
            if length(k0)==0, 
               warndlg(['Error in sub-string ',string(ij(i)+1:ii(i+1)-1)],'Warning: Model failed!'); 
               return;
            end
         else, k0=1; end
         for j=1:k0, array=conv(array,array1); end
      end
   end
end

%-------------------------------------------------------
%poly_evl is a supporting function for get_poly
%
%   [array,key]=poly_evl(string)
%where the arguments see above function.
%-------------------------------------------------------
function [array,key]=poly_evl(string)
str=string(2:length(string)); array=[]; key=0; i0=1; is0=[]; 
is=find(str=='+'|str=='-'); is=is+ones(size(1,length(is)));
for i=1:length(is), if (string(is(i)-1)~='e'), is0=[is0 is(i)]; end, end, 
is0 = [is0 length(string)+1]; 
for i=1:length(is0), 
   if (i0>1), if (string(i0-1)=='-'), i0=i0-1; end, end
   substr=string(i0:is0(i)-1); i0=is0(i)+1; is=find(substr=='s'|substr=='S');
   if length(is)==0, 
      k0=0; v1=str2num(substr);
      if isempty(v1)==1, key=1; end, if key==1, return; end
   elseif length(is)==1, 
      if (is==1), v1=1; 
      elseif (is==2&substr(1)=='-'), v1=-1; 
      else, v1 = str2num(substr(1:is-1));
         if isempty(v1)==1, key=1; end, if key==1, return; end
      end,
      if is==length(substr), k0=1;
      else, k0=str2num(substr(is+1:end));
      if isempty(k0)==1, key=1; end
         if key==1, return; end
         k0=floor(k0); 
      end
   else, 
      warndlg('Too many s''','Transfer function Failure!'); return; 
   end
   if (length(array)<k0+1),  array(k0+1)=v1;
   else, array(k0+1)=array(k0+1)+v1; 
   end, key=0; 
end
array=array(end:-1:1);

%-------------------------------------------------------------------------------
%build_simu is used to provide an template of SIMULINK model for the user to add 
%his own system model.
%-------------------------------------------------------------------------------
function build_simu(strMod)
open_system('simu_modlib'); sys=strMod;
if exist(sys)==4, open_system(sys);
else,
   new_system(sys); open_system(sys);
   set_param(sys,'Location',[197,131,618,343])
   add_block('built-in/Inport',[sys,'/','Input'])
   set_param([sys,'/','Input'],'Position',[65,80,85,100])
   add_block('built-in/Outport',[sys,'/','Output'])
   set_param([sys,'/','Output'],'Position',[355,80,375,100])
   add_line(sys,'Input/1','Output/1')
   new_system([sys,'/To CtrlLAB'])
   set_param([sys,'/To CtrlLAB'],'Mask Display','Return',...
      'OpenFcn','proc_model(9);','Position',[30,135,90,170]);
   %      'Mask Dialogue','eval(''proc_model(3);'')',...
end

%-----------------------------------------------------------------------------------
%mk_sim is used to process the SIMULINK model entered and display the final results.
%
%IMPORTANT NOTICE:-
%Due to the problem in SIMULINK, one should not click the Return block, instead, he 
%should type mk_sim under MATLAB prompt.  It is strange but we can do nothing about it.
%
%This function is not currently used.
%-----------------------------------------------------------------------------------
function mk_sim()

figure(findobj('Tag','CtrlLABMain')); uu0=get(gcf,'UserData'); 
g_model=extra_funs(5,3,'Checked',10:13);   
uu=get(uu0{1}(g_model),'UserData'); %get model name

%getting the linearized model
strMod=uu{3}; [xx,ux,yy,dx]=trim(strMod); 
[a,b,c,d]=linmod2(strMod,xx,ux); uu{2}=ss(a,b,c,d);  

%save system model to the block
set(uu0{1}(g_model),'UserData',uu);

%display the linearized model
disp_model(6,uu);

%----------------------------------------------------------
%is_delay checks whether there is delay in the whole system
%----------------------------------------------------------
function key=is_delay()
key=0; uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
g4=get(uu0{1}(4),'UserData');
if g4{1}>0; key=1; end

%---------------------------------------------------------
%is_simu checks whether there is delay in the whole system
%---------------------------------------------------------
function key=is_simu()
key=0;
uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
for i=1:3
   eval(['g=get(uu0{1}(' int2str(i), '),''UserData'');']);
   if length(g)>0, if g{1}==4, key=1; break; end, end
end

%---------------------------------------------------------
%clear_model clears the current model.
%---------------------------------------------------------
function clear_model()
close(gcf);
uu0=get(findobj('Tag','CtrlLABMain'),'UserData');
g_model=extra_funs(5,3,'Checked',10:13);
switch g_model
case 1
   set(uu0{1}(1),'UserData',[]);  
   set([uu0{3}([5:8,13,15]),uu0{4}(1),uu0{5}(1)],'Enable','off');
case 2, set(uu0{1}(2),'UserData',[]); set(uu0{4}(26),'Enable','off','Checked','off');
case 3, set(uu0{1}(3),'UserData',[]);  
case 4, set(uu0{1}(4),'UserData',{0,3});  
end      
