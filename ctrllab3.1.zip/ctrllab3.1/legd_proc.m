%legd_proc processing legends on a graphics window.
%
%   i_Legends=legd_proc(nTask,arg1)
%where 
%   nTask -- the code for legend processing.  Details can be found in the comments 
%            within the function
%   arg1 -- extra arguments used for certain nTask
%   i_Legends -- when used for get_legend, return handle
%
%The functions available in the module are
%
%  get_exact_point -- get the exact position
%  get_legnd -- get the handle of the specified object
%  set_text_prop -- set the properties of the text object
%  set_color_prop -- set the color of the text/line object
%  set_line_prop -- set the properties of the line object
%  plt_range_box -- display the plot range parameters dialog box
%

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%This module is used either with Graf_Tool or CtrlLAB.
%-----------------------------------------------------

function i_Legends=legd_proc(nTask,arg1)

h_legends=findobj('Tag','CtrlLABLegends');
if length(h_legends)==0,
   uu=get(gcf,'UserData'); g_graphs=gcf;
else
   uu_1=get(gcf,'UserData'); g_graphs=uu_1{2};
end

switch nTask
case 0, i_Legends=get_legnd(arg1);    
case 1, %enable the legend editting box to accept new legends
   [x,y]=ginput(1); set(gcf,'Units','normalized'); 
   xx=get(uu{2}(1),'Position'); xx(1:2)=get(gcf,'CurrentPoint'); 
   set(uu{2}(1),'Position',xx,'Visible','on','UserData',[x,y]);
case 2, %editting legends, add the current legend to edit box
   iLegends=get_legnd(nTask);
   if length(iLegends)>0
      set(uu{2}(1),'Visible','on'); str=get(iLegends,'String');
      xx=get(uu{2}(1),'Position'); xx(1:2)=get(gcf,'CurrentPoint'); 
      set(uu{2}(1),'String',str,'Position',xx); 
      uu{2}(3)=iLegends; set(g_graphs,'UserData',uu);
   end
case 3, %set legend moving enable functions
   iLegends=get_legnd(nTask);
   if length(iLegends)>0
      set(gcf,'Units','normalized','WindowButtonMotionFcn','legd_proc(11);',...
         'WindowButtonDownFcn','legd_proc(12);');
      uu{2}(3)=iLegends; set(g_graphs,'UserData',uu);
   end
case 4, %delete the legends to be selected
   iLegends=get_legnd(nTask);
   if length(iLegends)>0, delete(iLegends); end
case 5, %draw a line
   [x,y,button]=ginput(1);
   set(gcf,'Units','normalized','WindowButtonMotionFcn','legd_proc(19);',...
      'WindowButtonDownFcn','legd_proc(20,1);');
   h=line([x,x],[y,y]); uu{4}=[x,y,h]; set(gcf,'UserData',uu);
case {6,7}, %modify the properties of legends
   gg=get(h_legends,'UserData'); uu=get(gg{2},'UserData');
   if nTask==6, kk=uu{2}(3); 
   else, figure(gg{2}); kk=get(gca,'Children'); end
   for i=1:length(kk)
      if strcmp(get(kk(i),'Type'),'text') 
         if arg1==1, set_text_prop(kk(i)); end
      elseif (length(get(kk(i),'XData'))<=5&arg1==1)|(length(get(kk(i),'XData'))>5&arg1==2)   
         set_line_prop(kk(i));
      end   
      set_color_prop(kk(i));
   end
   close(h_legends);   
case 8, %draw arrows
   [x,y,button]=ginput(1);
   set(gcf,'Units','normalized','WindowButtonMotionFcn','legd_proc(19);',...
      'WindowButtonDownFcn','legd_proc(20,2);');
   h=line([x,x],[y,y]); uu{4}=[x,y,h]; set(gcf,'UserData',uu);
case 9, %delete all the legends
   close(h_legends); figure(g_graphs); hh=extra_funs(2,'axes'); ii=[];
   for i=1:length(hh)
      kk=get(hh(i),'Children'); 
      for j=1:length(kk)
         if strcmp(get(kk(j),'Type'),'line')
            if length(get(kk(j),'XData'))<=5, delete(kk(j)); end
         else, delete(kk(j)); end
      end   
   end   
case 10, %update legends
   hLegd=uu{2}(1); str=get(hLegd(1),'String'); set(hLegd(1),'Visible','off');
   if length(str)>0 & uu{2}(2)==1
      xy=get(uu{2}(1),'UserData'); x=xy(1); y=xy(2); 
      nCol=get(gca,'XColor'); [x,hh]=display_str(x,y,str,nCol);
   elseif uu{2}(2)==2, set(uu{2}(3),'String',str); end;
case 11, %move the legends to new position
   iLegends=uu{2}(3); [x,y]=get_exact_point;
   if strcmp(get(iLegends,'type'),'text')
      Pos=get(iLegends,'Position'); Pos(1)=x; Pos(2)=y; set(iLegends,'Position',Pos);
   else
      x0=get(iLegends,'XData'); y0=get(iLegends,'YData'); xx=get(gco,'UserData');
      dx=x-xx(1); dy=y-xx(2);
      set(iLegends,'XData',x0+dx,'YData',y0+dy); set(iLegends,'UserData',[x,y]);
   end   
case 12, %stop legend moving facilities
   set(g_graphs,'Units','pixels','WindowButtonMotionFcn','','WindowButtonDownFcn','');
case {13,22,30}, %show property dialog box     
   switch nTask
   case 13, iLegends=get_legnd(4);
   case 22, iLegends=get_legnd(5); 
   case 30, iLegends=get_legnd(6);
   end
   if length(iLegends)==0, break; end
   uu{2}(3)=iLegends(1); set(g_graphs,'UserData',uu);
   if length(iLegends)>0,
      g_type=get(iLegends(1),'Type');
      if strcmp(g_type,'line'), keyLine=1; keyText=0;   
      else, keyLine=0; keyText=1; end
   end   
   if length(h_legends)==0 & length(iLegends)>0
      h_legends=figure('Units','normalized','Position',[0.34 0.325 0.4125 0.275],...
         'NumberTitle','off','Name','Legend/Curve Properties',...
         'MenuBar','none','Color',0.8*[1,1,1],'Tag','CtrlLABLegends','Resize','off');         
      extra_funs(1);
      hFF(1)=uicontrol('Style','Pushbutton','String','Change',...
         'Units','normalized','Position',[0.8,0.8,0.18,0.14],'Callback','legd_proc(6,1);');
      hFF(9)=uicontrol('Style','Pushbutton','String','Change All',...
         'Units','normalized','Position',[0.53,0.8,0.25,0.14],'Callback','legd_proc(7,1);');
      if nTask==22
         set(hFF(1),'CallBack','legd_proc(6,2);'); set(hFF(9),'CallBack','legd_proc(7,2);');
      end
      hFF(10)=uicontrol('Style','Pushbutton','String','Delete All',...
         'Units','normalized','Position',[0.53,0.63,0.25,0.14],'Callback','legd_proc(9);');
      hFF(2)=uicontrol('Style','Pushbutton','String','Color','UserData',[],...
         'Units','normalized','Position',[0.8,0.63,0.18,0.14],'Callback','legd_proc(14);');
      hFF(3)=uicontrol('Style','Pushbutton','String','Font','UserData',[],...
         'Units','normalized','Position',[0.8,0.46,0.18,0.14],'Callback','legd_proc(15);',...
         'Enable',extra_funs(6,keyText));
      hFF(4)=uicontrol('Style','Pushbutton','String','Cancel',...
         'Units','normalized','Position',[0.8,0.29,0.18,0.14],'Callback','delete(gcf);');
      hFF(11)=uicontrol('Style','Pushbutton','String','Help',...
         'Units','normalized','Position',[0.8,0.12,0.18,0.14],'CallBack','clab_help(21);');
      [xL,hFF(5)]=display_str(0.04,0.93,'Select Line Type',[0,0,0],extra_funs(6,keyLine),9);
      hFF(6)=uicontrol('Style','Popupmenu','String',['Solid Line |Dash Line |Dotted Line |Dash-dotted Line'],...
         'Value',1,'UserData',[],'Visible',extra_funs(6,keyLine),...
         'Units','normalized','Position',[0.07,0.73,0.35,0.13],...
         'BackgroundColor',[1,1,1],'CallBack','legd_proc(16);');
      [xL,hFF(7)]=display_str(0.04,0.41,'Select Line Width',[0,0,0],extra_funs(6,keyLine),9);
      hFF(8)=uicontrol('Style','Popupmenu','String',['Thinner |Thicker'],...
         'Units','normalized','Position',[0.07,0.23,0.35,0.13],...
         'Value',1,'UserData',[],'Visible',extra_funs(6,keyLine),...
         'BackgroundColor',[1,1,1],'CallBack','legd_proc(17);');
      strMarker=str2mat('+ sign','o sign','* sign','. sign','x sign',...
         'square','diamond','v','^ sign','> sign','< sign',...
         'pentagram','hexagram','remove marker');
      [xL,hFF(14)]=display_str(0.04,0.67,'Select Marker Style',...
         [0,0,0],extra_funs(6,keyLine),9);
      hFF(15)=uicontrol('Style','Popupmenu','String',strMarker,...
         'Units','normalized','Position',[0.07,0.48,0.35,0.13],...
         'Value',1,'UserData',[],'Visible',extra_funs(6,keyLine),...
         'BackgroundColor',[1,1,1],'CallBack','legd_proc(21);');
      [x,hFF(12)]=display_str(0.04,0.10,'Angle for Rotation',[0,0,0],extra_funs(6,keyText),9);
      if keyText==1, strAngle=get(uu{2}(3),'Rotation'); 
      else, strAngle=0; end
      hFF(13)=uicontrol('Style','Edit','String',num2str(strAngle),...
         'Units','normalized','Position',[0.42,0.05,0.18,0.12],...
         'HorizontalAlignment','left','BackgroundColor',[1,1,1],'Visible',extra_funs(6,keyText));
      set(h_legends,'UserData',{hFF,g_graphs}); 
   else, figure(h_legends); end
case 14, %select new color
   gg=get(h_legends,'UserData'); nCol=uisetcolor; set(gg{1}(2),'UserData',nCol);
case 15, %select a new font
   gg=get(h_legends,'UserData'); hFont=uisetfont; set(gg{1}(3),'UserData',hFont);
case 16, %set line style
   gg=get(h_legends,'UserData'); set(gg{1}(6),'UserData',1);
case 17, %set line width
   gg=get(h_legends,'UserData'); set(gg{1}(8),'UserData',1);
case 18, %show cursor
   [x0,y0,but0]=get_legnd(1); 
   if but0==1,
      x=get(gco,'XData'); y=get(gco,'YData');
      cc=(x-x0).^2+(y-y0).^2; [cc,i]=min(cc); ux=get(gco,'UserData'); 
      if length(ux)==0
         x0=x(i); y0=y(i); str=[' (' num2str(x0), ',', num2str(y0) ')'];
      else
         uu=get(gcf,'UserData'); iplot=uu{4};
         switch iplot
         case {2,4}, x0=x(i); y0=y(i); str=['  \omega=' num2str(ux(i))];
         case 5, x0=x(i); y0=y(i); str=['  K=' num2str(ux(i))];
         otherwise, x0=x(i); y0=y(i); str=[' (' num2str(x0), ',', num2str(y0) ')'];
         end            
      end   
      h1=line(x0,y0); set(h1,'Marker','o'); h2=text(x0,y0,str); 
      set([h1,h2],'Color',get(gca,'XColor'));
   end
case 19, %set line drawing
   uu=get(g_graphs,'UserData'); x=uu{4}(1); y=uu{4}(2);
   uu=get(gcf,'UserData'); [x1,y1]=get_exact_point;
   set(uu{4}(3),'XData',[uu{4}(1),x1],'YData',[uu{4}(2),y1]);
case 20, %stop line drawing
   set(g_graphs,'WindowButtonMotionFcn','','WindowButtonDownFcn','');
   if arg1==2    
      uu=get(gcf,'UserData'); [x_e,y_e]=get_exact_point;
      nXAxis=get(gca,'XLim'); nYAxis=get(gca,'YLim');
      x=[uu{4}(1),x_e]; y=[uu{4}(2),y_e]; p1=pi/9; w=0.02; 
      x1=(x-nXAxis(1))/diff(nXAxis); y1=(y-nYAxis(1))/diff(nYAxis);
      theta=atan2(diff(y1),diff(x1)); theta=[theta+p1,theta-p1];
      x2=x1(2)-w*cos(theta); y2=y1(2)-w*sin(theta);
      x2=nXAxis(1)+x2*diff(nXAxis); y2=nYAxis(1)+y2*diff(nYAxis);
      xx1=[x, x2(1) x(2),x2(2)]; yy1=[y, y2(1),y(2),y2(2)]; 
      set(uu{4}(3),'XData',xx1,'YData',yy1);
   end
   set(uu{4}(3),'Color',get(gca,'XColor')); set(g_graphs,'Units','pixels');
case 21, gg=get(h_legends,'UserData'); set(gg{1}(15),'UserData',1);
case 23,
   iLegends=get_legnd(4);
   if length(iLegends)>0, nCol=uisetcolor; set(iLegends,'Color',nCol); end   
case 24, %call sub function to show a dialog box for plot range
   plt_range_box;
case 25
   g_main=findobj('Tag','CtrlLABMain'); uu0=get(gcf,'UserData'); nPlot=uu0{4};
   hRng=uu0{2}; uu=get(g_main,'UserData');
   x1=eval(get(hRng(2),'String')); x2=eval(get(hRng(4),'String'));
   n_points=eval(get(hRng(6),'String')); key_sim=0;
   if strcmp(get(hRng(7),'Enable'),'on'), key_sim=get(hRng(7),'Value'); end
   key_dly=0;
   if strcmp(get(hRng(8),'Enable'),'on'), key_dly=get(hRng(8),'Value'); end
   close(gcf); uu{10}=[x1,x2,n_points,key_sim,nPlot,key_dly]; 
   set(g_main,'UserData',uu); sys_analysis(nPlot);
case 26,
   iLegends=get_legnd(6);
   if length(iLegends)>0, nCol=uisetcolor; set(iLegends,'Color',nCol); end   
end
   
if nTask~=25
   uu=get(g_graphs,'UserData'); if nTask~=10, uu{2}(2)=nTask; end, 
   set(g_graphs,'UserData',uu);
end

%-------------------------------------------------------------------------------
%get_exact_point function is used to get the exact position in the axis when the 
%mouse is moved.  
%
%     [x,y]=get_exact_point
%where 
%  [x,y] returns the exact coordinate of the point
%-------------------------------------------------------------------------------
function [x,y]=get_exact_point()
nXAxis=get(gca,'XLim'); nYAxis=get(gca,'YLim'); ptAxis=get(gca,'Position');
x0=ptAxis(1); y0=ptAxis(2); xyPt=get(gcf,'CurrentPoint');
xyPt(1:2)=xyPt(1:2)-ptAxis(1:2);
x=xyPt(1)*diff(nXAxis)/ptAxis(3)+nXAxis(1); y=xyPt(2)*diff(nYAxis)/ptAxis(4)+nYAxis(1);

%---------------------------------------------------------------------
%get_legnd function is used to get the handle of the specified object.
%
%     [iLegend,y,button]=get_legnd(nTask)
%where 
%  nTask -- the task code, details see the case comments
%---------------------------------------------------------------------
function [iLegend,y,button]=get_legnd(nTask)
ii=extra_funs(2,'axes'); h_lines=[]; h_text=[];
for i=1:length(ii)
   axes(ii(i))
   if nTask==2, h_lines=[]; %In editting mode, exclude the lines/curves
   else, h_lines=[h_lines; extra_funs(2,'line',1)]; %otherwise find the handle of lines
   end
   %find the handle of all the text
   h_text=[h_text; extra_funs(2,'text',1)];
end
y=[]; buttton=[]; key=0; iLegend=[]; ii=[]; 
while key==0
   [x,y,button]=ginput(1);
   if button~=1, iLegend=[]; break; end
   switch nTask
   case {1,5}, %if it is a curve
      for i=1:length(h_lines)
         if length(get(h_lines(i),'XData'))>5, ii=[ii;i]; end
      end
      if length(h_lines(ii))>0
         if any(h_lines(ii)==gco), key=1; 
            if nTask==1, iLegend=x; else, iLegend=gco; end
         end
      else, 
         warndlg('Sorry, there is no curve to be processed!','Warning: Process failed!'), 
         iLegend=[]; break; 
      end   
   case {2,3,4,6},  %if it is a legend
      if nTask==6, hh=[h_lines; h_text];
      else, %make all the handles of legends
         for i=1:length(h_lines)
            if length(get(h_lines(i),'XData'))<=5, 
               ii=[ii,i]; if nTask==3, set(gco,'UserData',[x,y]); end
            end
         end
         hh=[h_lines(ii); h_text];
      end
      if length(hh)>0
         if any(hh==gco), iLegend=gco;  key=1;
            if nTask==4, 
               uu0=get(gco,'UserData'); if length(uu0)==1, iLegend=[iLegend; uu0]; end
            end
         end
      else, 
         warndlg('Sorry, there is no legends to be processed!','Warning: Process failed!'), 
         iLegend=[]; break; 
      end   
   end   
end

%-----------------------------------------------------------------------
%set_text_prop function is used to set the properties of the text object 
%according to users specifications
%
%  set_text_prop(hh)
%where 
%  hh -- the handle to be modified
%-----------------------------------------------------------------------
function set_text_prop(hh)
gg=get(findobj('Tag','CtrlLABLegends'),'UserData');

hFont=get(gg{1}(3),'UserData');
if length(hFont)>0
   [v,d]=version; v1=eval(v(1)); v2=eval(v(3));
   if v2<=1
      if hFont~=0
         set(hh,'FontName',get(hFont,'FontName'),'FontSize',get(hFont,'FontSize'),...
                'FontAngle',get(hFont,'FontAngle'),'FontWeight',get(hFont,'FontWeight'));
      end
   else
      if isa(hFont,'struct')
         set(hh,'FontName',hFont.FontName,'FontSize',hFont.FontSize,...
                'FontAngle',hFont.FontAngle,'FontWeight',hFont.FontWeight);
      end
   end   
end   
if strcmp(get(gg{1}(13),'Visible'),'on')
   set(hh,'Rotation',eval(get(gg{1}(13),'String')));
end

%----------------------------------------------------------------------------
%set_color_prop function is used to set the color properties of the text/line 
%object according to users specifications
%
%  set_color_prop(hh)
%where 
%  hh -- the handle to be modified
%----------------------------------------------------------------------------
function set_color_prop(hh)
uu=get(findobj('Tag','CtrlLABLegends'),'UserData'); 
nColor=get(uu{1}(2),'UserData');
if length(nColor)==3, set(hh,'Color',nColor); end

%---------------------------------------------------------------------------------
%set_line_prop function is used to set the properties of the line object according
%to users specifications
%
%  set_line_prop(hh)
%where 
%  hh -- the handle to be modified
%---------------------------------------------------------------------------------
function set_line_prop(hh)
gg=get(findobj('Tag','CtrlLABLegends'),'UserData'); 
if length(get(gg{1}(6),'UserData'))>0
   keyStyle1=get(gg{1}(6),'Value');
   switch keyStyle1
   case 1, keySign1='-'; 
   case 2, keySign1='--';
   case 3, keySign1=':';
   case 4, keySign1='-.'; 
   end
   set(hh,'LineStyle',keySign1)   
end
if length(get(gg{1}(8),'UserData'))>0
   LineCurrent=get(hh,'LineWidth');
   if get(gg{1}(8),'Value')==0, LineCurrent=LineCurrent*2;
   else, LineCurrent=LineCurrent*0.5; end   
   set(hh,'LineWidth',LineCurrent);
end
if length(get(gg{1}(15),'UserData'))>0
   keyStyle1=get(gg{1}(15),'Value');
   strMarker=str2mat('+ sign','o sign','* sign','. sign','x sign','square','diamond',...
      'v sign','^ sign','> sign','< sign','pentagram','hexagram','remove marker');
   switch keyStyle1
   case 1, keySign1='+'; 
   case 2, keySign1='o';
   case 3, keySign1='*';
   case 4, keySign1='.'; 
   case 5, keySign1='x'; 
   case 6, keySign1='square'; 
   case 7, keySign1='diamond'; 
   case 8, keySign1='v';
   case 9, keySign1='^';
   case 10, keySign1='>'; 
   case 11, keySign1='<'; 
   case 12, keySign1='pentagram'; 
   case 13, keySign1='hexagram'; 
   case 14, keySign1='none'; 
   end
   set(hh,'Marker',keySign1)   
end

%----------------------------------------------------------------------------------
%plt_range_box function is used to display the dialog box for plot range parameters
%----------------------------------------------------------------------------------
function plt_range_box()
g_plot=gcf; uu=get(g_plot,'UserData'); nPlot=uu{3};
if length(extra_funs(2))>0
   xx=get(gca,'XLim'); h_lines=extra_funs(2,'line',1); n_points=0;
   for i=1:length(h_lines)
      xd=get(h_lines(i),'XData'); 
      if length(xd)>5, 
         if n_points<length(xd); n_points=length(xd); end
         g_dat=get(h_lines(i),'UserData');
         if length(g_dat)>0, xx=[g_dat(1),g_dat(length(g_dat))]; break; end
      end   
   end   
   x1=xx(1); x2=xx(2); 
else, xx=[]; end   

h_win=findobj('Tag','CtrlLABPlots');
if length(h_win)==0
   h_win=figure('Units','normalized','Position',[0.24875 0.3 0.375 0.25],...
      'NumberTitle','off','Name','Change Plot Range','Tag','CtrlLABPlots',...
      'MenuBar','none','Color',0.8*[1,1,1],'Resize','off');         
   extra_funs(1);
   hFF(1)=uicontrol('Style','Pushbutton','String','Change',...
      'Units','normalized','Position',[0.8,0.8,0.18,0.16],'Callback','legd_proc(25);');
   hFF(2)=uicontrol('Style','Pushbutton','String','Cancel',...
      'Units','normalized','Position',[0.8,0.6,0.18,0.16],'Callback','close(gcf);');
   hFF(3)=uicontrol('Style','Pushbutton','String','Help',...
      'Units','normalized','Position',[0.8,0.4,0.18,0.16],'Callback','clab_help(31);');
   [xL,hRng(1)]=display_str(0.05,0.8,'Simulation Start Time',[0,0,0],'on',9);
   hRng(2)=uicontrol('Style','Edit','BackgroundColor',[1,1,1],...
      'Units','normalized','Position',[0.45,0.73,0.15,0.14]);
   [xL,hRng(3)]=display_str(0.05,0.6,'Simulation Stop Time',[0,0,0],'on',9);
   hRng(4)=uicontrol('Style','Edit','BackgroundColor',[1,1,1],...
      'Units','normalized','Position',[0.45,0.53,0.15,0.14]);
   [xL,hRng(5)]=display_str(0.05,0.40,'Number of Points',[0,0,0],'on',9);
   hRng(6)=uicontrol('Style','Edit','BackgroundColor',[1,1,1],...
      'Units','normalized','Position',[0.45,0.33,0.15,0.14]);
   [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
   if v2==2 & v3==0, strCheck='ToggleButton'; else, strCheck='CheckBox'; end 
   hRng(7)=uicontrol('Style',strCheck,'String','Use SIMULINK',...
      'Units','normalized','Position',[0.08,0.15,0.45,0.14],...
      'Enable','off','BackgroundColor',0.8*[1,1,1]);
   hRng(8)=uicontrol('Style',strCheck,'String','Use Pade Approximation',...
      'Units','normalized','Position',[0.48,0.15,0.45,0.14],...
      'Enable','off','BackgroundColor',0.8*[1,1,1]);
   set(h_win,'UserData',{hFF,hRng,g_plot,nPlot})
else, 
   figure(h_win); 
   uu0=get(gcf,'UserData'); hFF=uu0{1}; hRng=uu0{2}; g_plot=uu0{3};
end
switch nPlot
case {1,2,3,4}
   set(hRng(1),'String','Starting Frequency'); set(hRng(3),'String','Stopping Frequency');
   set(hRng(7),'String','Use Pade Approximation');
   if length(xx)==0, x1=0.1; x2=100; n_points=100; end
case 5,    
   set(hRng(1),'String','Smallest Gain'); set(hRng(3),'String','Highest Gain');
   set(hRng(7),'Visible','off');
   if length(xx)==0, x1=0; x2=10; n_points=100; end
case {6,7}
   if length(xx)==0, x1=0; x2=10; n_points=100; end
end
set(hRng(2),'String',num2str(x1)); set(hRng(4),'String',num2str(x2));
set(hRng(6),'String',int2str(n_points));
key_dly=proc_model(7); key_sim=proc_model(8);

set(hRng(8),'Enable',extra_funs(6,key_dly));
if nPlot>5, set(hRng(7),'Enable',extra_funs(6,key_sim)); end   
