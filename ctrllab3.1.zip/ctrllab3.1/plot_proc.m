%plot_proc is used to change properties of a user selected curves
%
%  plot_proc(nTask,arg1,arg2)
%where 
%  nTask -- curve manipulation code
%        1 display dialog box for preference
%        2 select background color
%        3 select axis color
%        4 select plot color
%        5 change the properties of plots
%        6 for set defaults specifications
%  arg1 -- invoke the curv_proc function
%  arg2 -- invoke the zoom_proc function
%
%The functions available in the module are
%
%  property_box -- create a dialog box for changing
%  chg_plt_property -- change the properties of selected objects
%  curv_proc -- change properties of a user selected curve.
%  zoom_proc -- changes the zooming facility
%

%Copyright (c) 1997-1999 by Professor Dingyu Xue
%School of Information Science and Engineering, Northeastern University
%Shenyang 110006, P R China
%Email: xue_dy@hotmail.com
%
%This module is used only with CtrlLAB.
%-------------------------------------------------------------------------

function plot_proc(nTask, arg1, arg2)

switch nargin
case 1
   uu=get(gcf,'UserData');
   if any([2,3,4,6]==nTask), bbCtrl=uu{1}; end      
   switch nTask
   case 1, property_box;
   case 2, set(bbCtrl(8),'UserData',uisetcolor);
   case 3, set(bbCtrl(10),'UserData',uisetcolor);
   case 4, set(bbCtrl(16),'UserData',uisetcolor);
   case 5, chg_plt_property;
   case 6
      extra_funs(4,1,'Value',[1,4,6],[2,3,5]); set(bbCtrl(6),'UserData',0.8*[1,1,1]);
      set(bbCtrl(10),'UserData',[0,0,0]); set(bbCtrl(16),'UserData',[1,1,1]);
   case 7, extra_funs(4,1,'Value',11,12); ctrllab(6,5);
   case 8, extra_funs(4,1,'Value',12,11); ctrllab(6,6);
   case 9, ctrllab(3,5);
   case 10, ctrllab(3,6);
   end   
case 2, curv_proc(nTask); %call curve processing routine
case 3, zoom_proc(nTask); %call the zooming mode processing routine
end

%---------------------------------------------------------------------------------
%property_box is used to create a dialog box for changing the properties of plots.
%---------------------------------------------------------------------------------
function property_box()
g_0=gcf; uu=get(g_0,'UserData'); g_main=findobj('Tag','CtrlLABMain'); 
if length(g_main)>0, 
   figure(g_main); 
   vvv=extra_funs(5,4,'Checked',24:27,[]); vv=zeros(1,4); vv(vvv)=1;
end   
g_win=findobj('Tag','CtrlLABPltPref');
if length(g_win)==0
   %if the graphics properties window does not exist create a new one
   g_win=figure('Units','normalized','Position',[0.2425 0.232 0.5 0.45],...
      'NumberTitle','off','Name','Plot Preference Options',...
      'MenuBar','none','Color',0.8*[1,1,1],...
      'Tag','CtrlLABPltPref','Resize','off');
   extra_funs(1);

   %  Define Grid on/off
   [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
   if v2==2 & v3==0, strRadio='ToggleButton'; strCheck=strRadio;
   else, strRadio='RadioButton'; strCheck='CheckBox'; end 
   extra_funs(10,[0.05,0.75],[0.22,0.95]);
   uicontrol('Style','Text','String','Grid',...
      'Units','normalized','Position',[0.07,0.92,0.1,0.06],'BackgroundColor',0.8*[1,1,1]);
   bbCtrl(1)=uicontrol('Style',strRadio,'String','On',...
      'Units','normalized','Position',[0.09,0.85,0.1,0.07],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','extra_funs(4,1,''Value'',1,2);;');
   bbCtrl(2)=uicontrol('Style',strRadio,'String','Off',...
      'Units','normalized','Position',[0.09,0.77,0.1,0.07],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','extra_funs(4,1,''Value'',2,1);');
      
   %%  Define Box on/off
   extra_funs(10,[0.26,0.75],[0.44,0.95]);
   uicontrol('Style','Text','String','Box',...
      'Units','normalized','Position',[0.28,0.92,0.1,0.06],'BackgroundColor',0.8*[1,1,1]);
   bbCtrl(3)=uicontrol('Style',strRadio,'String','On',...
      'Units','normalized','Position',[0.30,0.85,0.1,0.07],'BackgroundColor',0.8*[1,1,1],...
      'CallBack','extra_funs(4,1,''Value'',3,4);');
   bbCtrl(4)=uicontrol('Style',strRadio,'String','Off',...
      'Units','normalized','Position',[0.30,0.77,0.1,0.07],'BackgroundColor',0.8*[1,1,1],...
      'CallBack','extra_funs(4,1,''Value'',4,3);');
      
%%  Apply All/Current Figure
   extra_funs(10,[0.47,0.75],[0.77,0.95]);
   uicontrol('Style','Text','String','Apply',...
      'Units','normalized','Position',[0.49,0.92,0.12,0.06],'BackgroundColor',0.8*[1,1,1]);
   bbCtrl(5)=uicontrol('Style',strRadio,'String','All Figures',...
      'Units','normalized','Position',[0.51,0.85,0.22,0.07],'BackgroundColor',0.8*[1,1,1],...
      'CallBack','extra_funs(4,1,''Value'',5,6);');
   bbCtrl(6)=uicontrol('Style',strRadio,'String','Current Figure',...
      'Units','normalized','Position',[0.51,0.77,0.25,0.07],'BackgroundColor',0.8*[1,1,1],...
      'CallBack','extra_funs(4,1,''Value'',6,5);');
       
%%  Plot Color Definition
   extra_funs(10,[0.05,0.30],[0.73,0.69]);
   uicontrol('Style','Text','String','Modify Color',...
      'Units','normalized','Position',[0.32,0.64,0.20,0.08],...
      'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1]);
   bbCtrl(7)=uicontrol('Style','PushButton','String','Background Color Pallete',...
      'Units','normalized','Position',[0.08,0.56,0.4,0.09],'CallBack','plot_proc(2);');
   bbCtrl(8)=uicontrol('Style','PushButton','String','Default Color',...
      'Units','normalized','Position',[0.51,0.56,0.2,0.09],'CallBack','set(gco,''UserData'',0.8*[1,1,1]);');
   bbCtrl(9)=uicontrol('Style','PushButton','String','Plot Axis Color',...
      'Units','normalized','Position',[0.08,0.45,0.4,0.09],'CallBack','plot_proc(3);');
   bbCtrl(10)=uicontrol('Style','PushButton','String','Default Color',...
      'Units','normalized','Position',[0.51,0.45,0.2,0.09],'CallBack','set(gco,''UserData'',[0,0,0]);');
   bbCtrl(15)=uicontrol('Style','PushButton','String','Plot Color Pallete',...
      'Units','normalized','Position',[0.08,0.34,0.4,0.09],'CallBack','plot_proc(4);');
   bbCtrl(16)=uicontrol('Style','PushButton','String','Default Color',...
      'Units','normalized','Position',[0.51,0.34,0.2,0.09],'CallBack','set(gco,''UserData'',[1,1,1]);');
   
   if length(g_main)>0
      %  Define Model Combination
      extra_funs(10,[0.05,0.024],[0.40,0.24]);
      uicontrol('Style','Text','String',' Loops',...
         'Units','normalized','Position',[0.07,0.18,0.11,0.08],...
         'HorizontalAlignment','left','BackgroundColor',0.8*[1,1,1]);
      bbCtrl(11)=uicontrol('Style',strRadio,'String','Open Loop',...
         'Units','normalized','Position',[0.13,0.13,0.25,0.07],'Value',vv(1),...
         'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(7);');
      bbCtrl(12)=uicontrol('Style',strRadio,'String','Closed Loop',...
         'Units','normalized','Position',[0.13,0.05,0.25,0.07],'Value',vv(2),...
         'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(8);');

      extra_funs(10,[0.45,0.024],[0.85,0.24]);
      uicontrol('Style','Text','String',' Combinations',...
         'Units','normalized','Position',[0.47,0.18,0.21,0.08],...
         'BackgroundColor',0.8*[1,1,1],'HorizontalAlignment','left');
      bbCtrl(13)=uicontrol('Style',strCheck,'String','Uncompensated',...
         'Units','normalized','Position',[0.53,0.13,0.28,0.07],'Value',vv(3),...
         'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(9);');
      bbCtrl(14)=uicontrol('Style',strCheck,'String','Compensated',...
         'Units','normalized','Position',[0.53,0.05,0.25,0.07],'Value',vv(4),...
         'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(10);');
   end
   
   %  Execute and Close Window
   uicontrol('Style','PushButton','String','Change',...
      'Units','normalized','Position',[0.80,0.88,0.18,0.09],'CallBack','plot_proc(5);');
   uicontrol('Style','PushButton','String','Default',...
      'Units','normalized','Position',[0.80,0.77,0.18,0.09],'CallBack','plot_proc(6); ');
   uicontrol('Style','PushButton','String','Cancel',...
      'Units','normalized','Position',[0.80,0.66,0.18,0.09],'CallBack','delete(gcf);');
   uicontrol('Style','PushButton','String','Help',...
      'Units','normalized','Position',[0.80,0.55,0.18,0.09],'CallBack','clab_help(19);');
   set(g_win,'UserData',{bbCtrl,g_0});
else, figure(g_win); uu0=get(g_win,'UserData'); bbCtrl=uu0{1}; end  

%set grid and box properties
bAxis=extra_funs(11,uu{1}(3),'Checked'); bBox=extra_funs(11,uu{1}(4),'Checked');
set(bbCtrl(1),'Value',bAxis); set(bbCtrl(2),'Value',~bAxis);
set(bbCtrl(3),'Value',bBox); set(bbCtrl(4),'Value',~bBox);
set(bbCtrl(5),'Value',0); set(bbCtrl(6),'Value',1);

%----------------------------------------------------------------------
%chg_plt_property is used to change the properties of selected objects.
%----------------------------------------------------------------------
function chg_plt_property()

uu=get(gcf,'UserData'); bbCtrl=uu{1}; g_wins=uu{2};
bGrid=extra_funs(6,get(bbCtrl(1),'Value')); bBox=extra_funs(6,get(bbCtrl(3),'Value'));
bAll=get(bbCtrl(5),'Value'); nCol1=get(bbCtrl(8),'UserData');
nCol2=get(bbCtrl(10),'UserData'); nCol3=get(bbCtrl(16),'UserData'); delete(gcf);

if bAll==1, g_wins=findobj('Tag','CtrlLABFigs'); 
elseif ~ishandle(g_wins),
   errordlg('The figure window to be modified no longer exist','Error: Figure Modifying failed');
   return;
end

for i=1:length(g_wins)
   hh=g_wins(i); figure(hh); uu=get(gcf,'UserData'); ii=extra_funs(2);
   set(ii,'Box',bBox,'XGrid',bGrid,'YGrid',bGrid);
   if length(nCol1)==3, set(hh,'Color',nCol1); end
   if length(nCol2)==3, set(ii,'XColor',nCol2,'YColor',nCol2); end
   if length(nCol3)==3, set(ii,'Color',nCol3); end
   set(uu{1}(3),'Checked',bGrid); set(uu{1}(4),'Checked',bBox);
end

%----------------------------------------------------------------
%curv_proc is used to change properties of a user selected curve.
%
%  curv_proc(nTask,nStyle)
%where 
%  nTask -- curve manipulation code
%        1 for delete curve, 2 for change colour
%        3-6 for different line styles
%        {7,8,9,10,11,12} for different marks
%        13-14 for line width
%        15 for save as EPS files
%----------------------------------------------------------------
function curv_proc(nTask)

%get the handle of a curve
if nTask==20, hG=legd_proc(0,6); %select all 
elseif nTask<=14, hG=legd_proc(0,5); else, hG=1; end

if length(hG)>0
   %if such a handle exists, then process it
   switch nTask
   case 1, delete(hG); %delete current curve
   case 2, %get a new color and set the color of it
      nColor=uisetcolor;
      if length(nColor)==3, set(hG,'Color',nColor); end
   case {3,4,5,6} %set line styles of the curve
      ii=26:29; i=find(ii~=nTask+23); extra_funs(4,1,'Checked',nTask+23,ii(i));
      switch nTask
      case 3, nStyle='-';
      case 4, nStyle='--';
      case 5, nStyle=':';
      case 6, nStyle='-.';
      end, 
      set(hG,'LineStyle',nStyle);   
   case {7,8,9,10,11,12} %set markers of the curve
      ii=31:35; i=find(ii~=nTask+24); extra_funs(4,1,'Checked',nTask+24,ii(i));
      switch nTask
      case 7, nStyle='*';
      case 8, nStyle='+';
      case 9, nStyle='o';
      case 10, nStyle='x';
      case 11, nStyle='.';
      case 12, nStyle='none';   
      end, 
      set(hG,'Marker',nStyle);   
   case {13,14}
      h_Width=get(hG,'LineWidth');
      if nTask==13, kk=2; else, kk=0.5; end
      set(hG,'LineWidth',kk*h_Width);
   case {15,16,17,18,19}
      %save the figure to Encaptulated PS file
      graf_tool(3,1); g_graf=gcf;
      switch nTask
      case {15,16}
         u_prompt='*.eps'; uu=get(gcf,'UserData'); 
         if length(uu)>=5, u_prompt=[uu{5},u_prompt]; end
         [filename,filepath]=uiputfile(u_prompt,'Please Specify the an EPF File Name');
         if ~isa(filename,'double')
            uu{6}=[filepath,filename]; uu{5}=filepath; str=uu{6}; set(gcf,'UserData',uu);
            if nTask==15, eval(['print(''-deps2'', ''-adobecset'', ''' str ''');']); 
            else, eval(['print(''-deps2c'', ''-adobecset'', ''' str ''');']); end   
         end      
      case 17, print -dmeta;
      case 18, print -dbitmap;   
      case 19, [a,b]=printopt; eval(['print ' b]) %print figure on current printer   
      end
      figure(g_graf); graf_tool(3,[]);
   case 20, delete(hG); %delete current curve
   case 21, delete(hG); %delete current curve
   end
end

%----------------------------------------------------------------
%zoom_proc is used to implement zoom facilities.
%
%  zoom_proc(nTask)
%where 
%  nTask -- curve manipulation code
%        1 for zooming on/off
%        2 for x axis zoom on/off
%        3 for y axis zoom on/off
%        4 for full axis mode
%----------------------------------------------------------------
function zoom_proc(nTask)

%find the list of all existing axes on the current window
uu=get(gcf,'UserData'); g_axes=extra_funs(2,'axes');

switch nTask
case {1,2,3,4}
   b_zooms=findobj(gcf,'Tag','Toolz'); b_zooms=b_zooms(end:-1:1);
   ii=[17:20]; i1=find(ii~=nTask+16); extra_funs(4,1,'Checked',nTask+16,ii(i1)); 
   if length(b_zooms)>0, set(b_zooms,'Value',0); end
   if length(b_zooms)>0
      set(b_zooms,'Value',0); if nTask<=3, set(b_zooms(nTask),'Value',1); end
   end   
   for i=1:length(g_axes),
      switch nTask
      case 1, axes(g_axes(i)); zoom on; %set full zooming facilities
      case 2, axes(g_axes(i)); zoom xon; %set zooming facilities on x axis
      case 3, axes(g_axes(i)); zoom yon; %set zooming facilities on y axis
      case 4,   
         %automatic selecting axis ranges based on data
         set(g_axes(i),'XLimMode','auto','YLimMode','auto'); zoom off
      end      
   end   
case 5
   %display a zoom changing dialog box
   hAxis=gca;
   hAxisSet=figure('Units','normalized','Position',[0.1863 0.198 0.4375 0.333],...
      'NumberTitle','off','Name','Axis Range Select',...
      'MenuBar','none','Color',0.8*[1,1,1],'Resize','off','Tag','CtrlLABExtras');
   extra_funs(1); extra_funs(10,[0.1,0.93],[0.75,0.52]);
   uicontrol('Style','Text','String','X Axis','BackgroundColor',0.8*[1,1,1],...
      'Units','normalized','Position',[0.05 0.70 0.12 0.1]);
   [x,h(1)]=display_str(0.22,0.59,'Lower',[0,0,0],'off',9);
   [x,h(3)]=display_str(0.46,0.59,'Upper',[0,0,0],'off',9);
   h(2)=uicontrol('Style','Edit','String','','Visible','off',...
      'Units','normalized','Position',[0.34 0.54 0.1 0.1],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
   h(4)=uicontrol('Style','Edit','String','','Visible','off',...
      'Units','normalized','Position',[0.58 0.54 0.1 0.1],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1]);
   [v,d]=version; v1=eval(v(1)); v2=eval(v(3)); v3=eval(v(5));
   if v2==2 & v3==0, strRadio='ToggleButton'; else, strRadio='RadioButton'; end 
   bXAxis(1)=uicontrol('Style',strRadio,'String','Current','Value',1,...
      'Units','normalized','Position',[0.22,0.79,0.22,0.1],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(6,0,0);');
   bXAxis(2)=uicontrol('Style',strRadio,'String','Define','Value',0,...
      'Units','normalized','Position',[0.22,0.66,0.22,0.1],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(7,0,0);');

   extra_funs(10,[0.1,0.45],[0.75,0.04]);
   uicontrol('Style','Text','String','Y Axis','BackgroundColor',0.8*[1,1,1],...
      'Units','normalized','Position',[0.05 0.20 0.12 0.1]);
   [x,h(5)]=display_str(0.22,0.14,'Lower',[0,0,0],'off',9);
   [x,h(7)]=display_str(0.46,0.14,'Upper',[0,0,0],'off',9);
   h(6)=uicontrol('Style','Edit','String','',...
      'Units','normalized','Position',[0.35 0.08 0.1 0.1],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1],'Visible','off');
   h(8)=uicontrol('Style','Edit','String','',...
      'Units','normalized','Position',[0.58 0.08 0.1 0.1],...
      'HorizontalAlignment','left','BackgroundColor',[1,1,1],'Visible','off');
   bYAxis(1)=uicontrol('Style',strRadio,'String','Current','Value',1,...
      'Units','normalized','Position',[0.22,0.32,0.22,0.1],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(8,0,0);');
   bYAxis(2)=uicontrol('Style',strRadio,'String','Define','Value',0,...
      'Units','normalized','Position',[0.22,0.19,0.22,0.1],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(9,0,0);');
   uicontrol('Style','Pushbutton','String','OK',...
      'Units','normalized','Position',[0.80,0.8,0.17,0.12],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','plot_proc(10,0,0);');
   uicontrol('Style','Pushbutton','String','Cancel',...
      'Units','normalized','Position',[0.80,0.65,0.17,0.12],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','close(gcf);');
   uicontrol('Style','Pushbutton','String','Help',...
      'Units','normalized','Position',[0.80,0.50,0.17,0.12],...
      'BackgroundColor',0.8*[1,1,1],'CallBack','clab_help(20);');
   set(gcf,'UserData',{h,bXAxis,bYAxis,hAxis});
case 6
   h=uu{1}; bXAxis=uu{2}; kk=get(bXAxis(1),'Value');
   set(bXAxis(2),'Value',~kk); set(h(1:4),'Visible',extra_funs(6,~kk));
case 7
   h=uu{1}; bXAxis=uu{2}; kk=get(bXAxis(2),'Value');
   set(bXAxis(1),'Value',~kk); set(h(1:4),'Visible',extra_funs(6,kk));
   if kk==1,
      xL=get(uu{4},'XLim'); set(h(2),'String',num2str(xL(1)));
      set(h(4),'String',num2str(xL(2)));
   end; 
case 8
   h=uu{1}; bYAxis=uu{3}; kk=get(bYAxis(1),'Value');
   set(h(5:8),'Visible',extra_funs(6,~kk)); set(bYAxis(2),'Value',~kk);
case 9
   h=uu{1}; bYAxis=uu{3}; kk=get(bYAxis(2),'Value');
   set(h(5:8),'Visible',extra_funs(6,kk)); set(bYAxis(1),'Value',~kk);
   if kk==1,
      yL=get(uu{4},'YLim'); set(h(6),'String',num2str(yL(1))); set(h(8),'String',num2str(yL(2)));
   end
case 10
   h=uu{1}; bXAxis=uu{2}; bYAxis=uu{3}; hAxis=uu{4};
   if get(bXAxis(2),'Value')==1,
      %if x axis range specified, change it
      x1=eval(get(h(2),'String')); x2=eval(get(h(4),'String')); set(hAxis,'XLim',[x1,x2]);
   end,
   if get(bYAxis(2),'Value')==1,
      %if y axis range specified, change it
      y1=eval(get(h(6),'String')); y2=eval(get(h(8),'String')); set(hAxis,'YLim',[y1,y2]);
   end
   close(gcf);
end      
